<?php
require __DIR__ . '/student_init.php';
$user = require_student($db);
$uid  = (int)$user['user_id'];

$q = trim($_GET['q'] ?? '');
$where  = 'd.is_public = 1';
$types  = '';
$params = [];
if ($q !== '') {
    $where .= ' AND (d.name LIKE ? OR u.username LIKE ?)';
    $like = '%' . $q . '%';
    $types = 'ss';
    $params = [$like, $like];
}

$decks = fetch_all($db, 'SELECT d.deck_id, d.name, d.created_at, d.user_id, u.username,
        (SELECT COUNT(*) FROM deck_flashcards df WHERE df.deck_id = d.deck_id) AS cards
    FROM decks d JOIN users u ON u.user_id = d.user_id
    WHERE ' . $where . ' ORDER BY d.created_at DESC, d.deck_id DESC LIMIT 100', $types, $params);

student_header('Public decks', 'public', $user);
?>
    <div class="page-head">
      <h2 class="page-title">Public decks</h2>
    </div>

    <form class="toolbar" method="get" action="public_decks.php">
      <input type="text" name="q" value="<?= e($q) ?>" placeholder="Search deck name or owner">
      <button class="btn" type="submit">Search</button>
      <?php if ($q !== ''): ?><a class="btn ghost" href="public_decks.php">Clear</a><?php endif; ?>
    </form>

    <section class="panel">
      <h3>Shared by students <span class="count"><?= count($decks) ?><?= count($decks) === 100 ? '+ (latest 100)' : '' ?></span></h3>
      <?php if (!$decks): ?>
        <p class="empty"><?= $q !== '' ? 'No public decks match your search.' : 'No public decks yet. Make one of your decks public from My decks to share it here.' ?></p>
      <?php else: ?>
        <div class="table-wrap">
          <table class="data">
            <thead><tr><th>Deck</th><th>Owner</th><th>Cards</th><th>Created</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($decks as $d): $own = ((int)$d['user_id'] === $uid); ?>
              <tr>
                <td><a class="link" href="deck.php?id=<?= (int)$d['deck_id'] ?>"><?= e($d['name']) ?></a></td>
                <td><?= $own ? '<span class="badge badge-student">You</span>' : e($d['username']) ?></td>
                <td><?= (int)$d['cards'] ?></td>
                <td class="nowrap"><?= e(fmt_date($d['created_at'])) ?></td>
                <td class="nowrap row-actions">
                  <a class="btn ghost sm" href="deck.php?id=<?= (int)$d['deck_id'] ?>"><?= $own ? 'Manage' : 'View' ?></a>
                  <?php if (!$own): ?>
                    <form method="post" action="deck.php?id=<?= (int)$d['deck_id'] ?>" style="display:inline">
                      <?= csrf_field() ?>
                      <input type="hidden" name="id" value="<?= (int)$d['deck_id'] ?>">
                      <input type="hidden" name="action" value="copy">
                      <button class="btn sm" type="submit">Save copy</button>
                    </form>
                  <?php endif; ?>
                </td>
              </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </section>
<?php student_footer(); ?>
