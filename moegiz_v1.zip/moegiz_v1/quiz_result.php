<?php
require __DIR__ . '/student_init.php';
$user = require_student($db);
$uid  = (int)$user['user_id'];
$id   = (int)($_GET['id'] ?? 0);

// You can only open your own attempts
$a = fetch_one($db, 'SELECT q.attempt_id, q.deck_id, q.quiz_score, q.correct_answers, q.total_questions, q.game_points,
        q.completion_time_seconds, q.quiz_mode, q.created_at, d.name AS deck_name
    FROM quiz_attempts q LEFT JOIN decks d ON d.deck_id = q.deck_id
    WHERE q.attempt_id = ? AND q.user_id = ?', 'ii', [$id, $uid]);

if (!$a) {
    http_response_code(404);
    student_header('Result not found', 'quiz', $user);
    echo '<div class="panel"><p class="empty">Quiz result not found.</p><a class="link" href="quiz.php">&larr; Back to Quiz</a></div>';
    student_footer();
    exit;
}

// The question-by-question review is only kept in the session right after finishing
$review = null;
if (!empty($_SESSION['quiz_review']) && (int)$_SESSION['quiz_review']['attempt_id'] === $id) {
    $review = $_SESSION['quiz_review']['items'];
}

$score = (int)$a['quiz_score'];
if ($score === 100)      $msg = 'Perfect score! 🎉';
elseif ($score >= 80)    $msg = 'Great job!';
elseif ($score >= 50)    $msg = 'Good effort. Keep practicing!';
else                     $msg = 'Keep going, practice makes progress.';

student_header('Quiz result', 'quiz', $user);
?>
    <div class="page-head">
      <div>
        <div class="crumb"><a class="link" href="quiz.php">&larr; Quiz</a></div>
        <h2 class="page-title">Quiz result</h2>
      </div>
    </div>

    <section class="panel result">
      <div class="big-score"><?= $score ?>%</div>
      <p class="result-msg"><?= e($msg) ?></p>
      <p class="muted" style="margin:0 0 18px">
        <?= $a['deck_name'] !== null ? e($a['deck_name']) : '(deleted deck)' ?>
        &middot; <span class="badge <?= $a['quiz_mode'] === 'Gamified' ? 'badge-game' : 'badge-plain' ?>"><?= e($a['quiz_mode']) ?></span>
        &middot; <?= e(fmt_date($a['created_at'])) ?>
      </p>

      <div class="stat-grid" style="margin-bottom:0">
        <div class="tile"><div class="num"><?= (int)$a['correct_answers'] ?>/<?= (int)$a['total_questions'] ?></div><div class="lbl">Correct</div></div>
        <?php if ($a['quiz_mode'] === 'Gamified'): ?>
          <div class="tile"><div class="num"><?= (int)$a['game_points'] ?></div><div class="lbl">Points</div></div>
        <?php endif; ?>
        <div class="tile"><div class="num"><?= e(fmt_time((int)$a['completion_time_seconds'])) ?></div><div class="lbl">Answering time</div></div>
      </div>

      <div class="actions-row" style="display:flex;gap:10px;margin-top:20px;flex-wrap:wrap">
        <?php if ($a['deck_id'] !== null): ?>
          <a class="btn" href="quiz.php?deck=<?= (int)$a['deck_id'] ?>">Play again</a>
        <?php endif; ?>
        <a class="btn ghost" href="quiz.php">Back to Quiz</a>
        <a class="btn ghost" href="dashboard.php">Home</a>
      </div>
    </section>

    <?php if ($review): ?>
      <section class="panel">
        <h3>Review <span class="count"><?= count($review) ?> questions</span></h3>
        <div class="fc-list">
          <?php foreach ($review as $i => $r): ?>
            <div class="fc review <?= $r['ok'] ? 'ok' : 'bad' ?>">
              <div class="meta">#<?= $i + 1 ?> &middot; <?= $r['ok'] ? 'Correct' : ($r['chosen'] === null ? 'No answer' : 'Incorrect') ?></div>
              <div class="q"><?= e($r['q']) ?></div>
              <?php if (!$r['ok'] && $r['chosen'] !== null): ?>
                <div class="h">Your answer: <?= e($r['chosen']) ?></div>
              <?php endif; ?>
              <div class="a">Answer: <?= e($r['correct']) ?></div>
            </div>
          <?php endforeach; ?>
        </div>
      </section>
    <?php endif; ?>
<?php student_footer(); ?>
