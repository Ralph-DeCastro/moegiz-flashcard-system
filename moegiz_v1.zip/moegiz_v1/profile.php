<?php
require __DIR__ . '/student_init.php';
$user = require_student($db);
$uid  = (int)$user['user_id'];

$stats = fetch_one($db, 'SELECT
        (SELECT COUNT(*) FROM decks WHERE user_id = ?) AS decks,
        (SELECT COUNT(*) FROM flashcards WHERE created_by = ?) AS cards,
        (SELECT COUNT(*) FROM quiz_attempts WHERE user_id = ?) AS quizzes,
        (SELECT COALESCE(SUM(correct_answers), 0) FROM quiz_attempts WHERE user_id = ?) AS correct,
        (SELECT COALESCE(SUM(total_questions), 0) FROM quiz_attempts WHERE user_id = ?) AS total_q',
    'iiiii', [$uid, $uid, $uid, $uid, $uid]);
$accuracy = ((int)$stats['total_q'] > 0) ? round(100 * (int)$stats['correct'] / (int)$stats['total_q']) . '%' : '—';
$initial  = mb_strtoupper(mb_substr($user['username'], 0, 1));

student_header('Profile', 'profile', $user);
?>
    <div class="page-head">
      <h2 class="page-title">Profile</h2>
      <a class="btn ghost" href="settings.php">Settings</a>
    </div>

    <section class="panel">
      <div class="profile-head">
        <span class="avatar"><?= e($initial) ?></span>
        <div class="info">
          <h2><?= e($user['username']) ?> <?= role_badge($user['role']) ?></h2>
          <p><?= e($user['email']) ?></p>
          <p>Joined <?= e(fmt_date($user['created_at'])) ?></p>
        </div>
      </div>
    </section>

    <section class="stat-grid">
      <a class="tile" href="my_decks.php"><div class="num"><?= (int)$stats['decks'] ?></div><div class="lbl">Decks</div></a>
      <a class="tile" href="flashcards.php"><div class="num"><?= (int)$stats['cards'] ?></div><div class="lbl">Flashcards created</div></a>
      <a class="tile" href="quiz.php"><div class="num"><?= (int)$stats['quizzes'] ?></div><div class="lbl">Quizzes taken</div></a>
      <div class="tile"><div class="num"><?= e($accuracy) ?></div><div class="lbl">Accuracy</div></div>
    </section>
<?php student_footer(); ?>
