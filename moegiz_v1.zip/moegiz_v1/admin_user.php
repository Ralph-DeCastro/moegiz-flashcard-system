<?php
require __DIR__ . '/admin_init.php';
$admin = require_admin($db);

$id    = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$error = '';

$user = fetch_one($db, 'SELECT user_id, username, email, role, created_at, updated_at FROM users WHERE user_id = ?', 'i', [$id]);

// Delete account (POST only)
if ($user && $_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete_user') {
    if (!csrf_ok()) {
        $error = 'Invalid request. Please refresh and try again.';
    } elseif ((int)$user['user_id'] === (int)$admin['user_id']) {
        $error = 'You cannot delete your own account.';
    } elseif ($user['role'] === 'Admin') {
        $error = 'Admin accounts cannot be deleted from here.';
    } else {
        $stmt = $db->prepare('DELETE FROM users WHERE user_id = ?');
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $stmt->close();
        log_admin((int)$admin['user_id'], $admin['username'], 'Delete', 'user ' . $user['username']);
        header('Location: admin_users.php?msg=deleted');
        exit;
    }
}

if (!$user) {
    http_response_code(404);
    admin_header('User not found', 'users', $admin);
    echo '<div class="panel"><p class="empty">User not found.</p><a class="link" href="admin_users.php">&larr; Back to users</a></div>';
    admin_footer();
    exit;
}

$decks = fetch_all($db, 'SELECT d.deck_id, d.name, d.is_public, d.created_at,
        (SELECT COUNT(*) FROM deck_flashcards df WHERE df.deck_id = d.deck_id) AS cards,
        (SELECT COUNT(*) FROM quiz_attempts q WHERE q.deck_id = d.deck_id) AS attempts
    FROM decks d WHERE d.user_id = ? ORDER BY d.created_at DESC, d.deck_id DESC', 'i', [$id]);

$attempts = fetch_all($db, 'SELECT q.attempt_id, q.quiz_mode, q.quiz_score, q.correct_answers, q.total_questions,
        q.game_points, q.completion_time_seconds, q.created_at, q.deck_id,
        u.user_id, u.username, d.name AS deck_name
    FROM quiz_attempts q
    JOIN users u ON u.user_id = q.user_id
    LEFT JOIN decks d ON d.deck_id = q.deck_id
    WHERE q.user_id = ?
    ORDER BY q.created_at DESC, q.attempt_id DESC LIMIT 100', 'i', [$id]);

$stats = fetch_one($db, 'SELECT
        (SELECT COUNT(*) FROM flashcards WHERE created_by = ?) AS cards_created,
        (SELECT COUNT(*) FROM quiz_attempts WHERE user_id = ?) AS attempts,
        (SELECT COALESCE(SUM(correct_answers), 0) FROM quiz_attempts WHERE user_id = ?) AS correct,
        (SELECT COALESCE(SUM(total_questions), 0) FROM quiz_attempts WHERE user_id = ?) AS total_q',
    'iiii', [$id, $id, $id, $id]);
$accuracy = ((int)$stats['total_q'] > 0) ? round(100 * (int)$stats['correct'] / (int)$stats['total_q']) . '%' : '—';

$initial   = mb_strtoupper(mb_substr($user['username'], 0, 1));
$canDelete = ($user['role'] === 'Student' && (int)$user['user_id'] !== (int)$admin['user_id']);

admin_header($user['username'], 'users', $admin);
?>
    <div class="page-head">
      <div>
        <div class="crumb"><a class="link" href="admin_users.php">&larr; Users</a></div>
        <h2 class="page-title"><?= e($user['username']) ?></h2>
      </div>
      <?php if ($canDelete): ?>
        <form method="post" action="admin_user.php?id=<?= (int)$user['user_id'] ?>"
              onsubmit="return confirm('Delete this account and all of their decks, flashcards and quiz history? This cannot be undone.');">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="delete_user">
          <input type="hidden" name="id" value="<?= (int)$user['user_id'] ?>">
          <button class="btn danger" type="submit">Delete account</button>
        </form>
      <?php endif; ?>
    </div>

    <?php if ($error): ?><div class="notice error"><?= e($error) ?></div><?php endif; ?>

    <section class="panel">
      <div class="profile-head">
        <span class="avatar"><?= e($initial) ?></span>
        <div class="info">
          <h2><?= e($user['username']) ?> <?= role_badge($user['role']) ?></h2>
          <p><?= e($user['email']) ?></p>
          <p>Joined <?= e(fmt_date($user['created_at'])) ?> &middot; Last updated <?= e(fmt_date($user['updated_at'])) ?></p>
        </div>
      </div>
    </section>

    <section class="stat-grid">
      <div class="tile"><div class="num"><?= count($decks) ?></div><div class="lbl">Decks</div></div>
      <div class="tile"><div class="num"><?= (int)$stats['cards_created'] ?></div><div class="lbl">Flashcards created</div></div>
      <div class="tile"><div class="num"><?= (int)$stats['attempts'] ?></div><div class="lbl">Quizzes taken</div></div>
      <div class="tile"><div class="num"><?= e($accuracy) ?></div><div class="lbl">Accuracy</div></div>
    </section>

    <section class="panel">
      <h3>Decks <span class="count"><?= count($decks) ?></span></h3>
      <?php if (!$decks): ?>
        <p class="empty">This user hasn't created any decks.</p>
      <?php else: ?>
        <div class="table-wrap">
          <table class="data">
            <thead><tr><th>Deck</th><th>Visibility</th><th>Cards</th><th>Quiz attempts</th><th>Created</th></tr></thead>
            <tbody>
            <?php foreach ($decks as $d): ?>
              <tr>
                <td><a class="link" href="admin_deck.php?id=<?= (int)$d['deck_id'] ?>"><?= e($d['name']) ?></a></td>
                <td><span class="badge <?= $d['is_public'] ? 'badge-public' : 'badge-private' ?>"><?= $d['is_public'] ? 'Public' : 'Private' ?></span></td>
                <td><?= (int)$d['cards'] ?></td>
                <td><?= (int)$d['attempts'] ?></td>
                <td class="nowrap"><?= e(fmt_date($d['created_at'])) ?></td>
              </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </section>

    <section class="panel">
      <h3>Quiz history <span class="count"><?= count($attempts) ?><?= count($attempts) === 100 ? '+ (latest 100)' : '' ?></span></h3>
      <?php render_attempts($attempts, false, true); ?>
    </section>
<?php admin_footer(); ?>
