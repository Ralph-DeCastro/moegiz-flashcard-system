<?php
require __DIR__ . '/student_init.php';
$user = require_student($db);
$uid  = (int)$user['user_id'];

$errors = [];
$notice = '';
$name   = '';
$public = false;

if (($_GET['msg'] ?? '') === 'deleted') {
    $notice = 'Deck deleted.';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if (!csrf_ok()) {
        $errors[] = 'Invalid request. Please refresh and try again.';

    // ---------- Create deck ----------
    } elseif ($action === 'create') {
        $name   = trim($_POST['name'] ?? '');
        $public = !empty($_POST['is_public']);
        $len    = mb_strlen($name);

        if ($len < 1 || $len > 100) {
            $errors[] = 'Enter a deck name (up to 100 characters).';
        } else {
            $isPublic = $public ? 1 : 0;
            $stmt = $db->prepare('INSERT INTO decks (user_id, name, is_public) VALUES (?, ?, ?)');
            $stmt->bind_param('isi', $uid, $name, $isPublic);
            $stmt->execute();
            $newId = (int)$db->insert_id;
            $stmt->close();
            header('Location: deck.php?id=' . $newId . '&msg=created');
            exit;
        }

    // ---------- Delete deck ----------
    } elseif ($action === 'delete') {
        $deckId = (int)($_POST['deck_id'] ?? 0);
        // Only the owner can delete; the flashcards themselves are kept
        $stmt = $db->prepare('DELETE FROM decks WHERE deck_id = ? AND user_id = ?');
        $stmt->bind_param('ii', $deckId, $uid);
        $stmt->execute();
        $deleted = $stmt->affected_rows;
        $stmt->close();
        if ($deleted > 0) {
            header('Location: my_decks.php?msg=deleted');
            exit;
        }
        $errors[] = 'Deck not found.';
    }
}

$decks = fetch_all($db, 'SELECT d.deck_id, d.name, d.is_public, d.created_at,
        (SELECT COUNT(*) FROM deck_flashcards df WHERE df.deck_id = d.deck_id) AS cards
    FROM decks d WHERE d.user_id = ? ORDER BY d.created_at DESC, d.deck_id DESC', 'i', [$uid]);

student_header('My decks', 'decks', $user);
?>
    <div class="page-head">
      <h2 class="page-title">My decks</h2>
    </div>

    <?php if ($notice): ?><div class="notice ok"><?= e($notice) ?></div><?php endif; ?>
    <?php if ($errors): ?>
      <div class="notice error"><?php foreach ($errors as $err): ?><div><?= e($err) ?></div><?php endforeach; ?></div>
    <?php endif; ?>

    <section class="panel">
      <h3>New deck</h3>
      <form class="form inline-form" method="post" action="my_decks.php">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="create">
        <div class="grow">
          <label for="name">Deck name</label>
          <input type="text" id="name" name="name" maxlength="100" required value="<?= e($name) ?>" placeholder="e.g. Biology: Cells">
        </div>
        <label class="check compact">
          <input type="checkbox" name="is_public" value="1" <?= $public ? 'checked' : '' ?>>
          Public
        </label>
        <button class="btn" type="submit">Create deck</button>
      </form>
      <p class="hint muted" style="margin:10px 0 0;font-size:0.8rem">Public decks can be viewed and copied by other students. Private decks are only visible to you.</p>
    </section>

    <section class="panel">
      <h3>Your decks <span class="count"><?= count($decks) ?></span></h3>
      <?php if (!$decks): ?>
        <p class="empty">You don't have any decks yet. Create one above, then add your flashcards to it.</p>
      <?php else: ?>
        <div class="table-wrap">
          <table class="data">
            <thead><tr><th>Deck</th><th>Visibility</th><th>Cards</th><th>Created</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($decks as $d): ?>
              <tr>
                <td><a class="link" href="deck.php?id=<?= (int)$d['deck_id'] ?>"><?= e($d['name']) ?></a></td>
                <td><span class="badge <?= $d['is_public'] ? 'badge-public' : 'badge-private' ?>"><?= $d['is_public'] ? 'Public' : 'Private' ?></span></td>
                <td><?= (int)$d['cards'] ?></td>
                <td class="nowrap"><?= e(fmt_date($d['created_at'])) ?></td>
                <td class="nowrap row-actions">
                  <a class="btn ghost sm" href="deck.php?id=<?= (int)$d['deck_id'] ?>">Open</a>
                  <form method="post" action="my_decks.php" style="display:inline"
                        onsubmit="return confirm('Delete this deck? Your flashcards are kept, but quiz history for this deck will lose its deck link.');">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="deck_id" value="<?= (int)$d['deck_id'] ?>">
                    <button class="btn danger sm" type="submit">Delete</button>
                  </form>
                </td>
              </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </section>
<?php student_footer(); ?>
