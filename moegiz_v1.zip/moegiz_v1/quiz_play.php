<?php
require __DIR__ . '/student_init.php';
$user = require_student($db);
$uid  = (int)$user['user_id'];

const GAME_SECONDS   = 15;   // time per question in Gamified mode
const GRACE_SECONDS  = 3;    // network slack before an answer counts as timed out
const MAX_QUESTIONS  = 50;

function norm(string $s): string {
    return mb_strtolower(trim(preg_replace('/\s+/u', ' ', $s)));
}

// ================================================================== POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_ok()) {
        header('Location: quiz.php?err=invalid');
        exit;
    }
    $action = $_POST['action'] ?? '';

    // ---------------------------------------------------------- start a quiz
    if ($action === 'start') {
        $deckId = (int)($_POST['deck_id'] ?? 0);
        $mode   = $_POST['mode'] ?? '';
        $count  = (int)($_POST['count'] ?? 10);
        if (!in_array($mode, ['Standard', 'Gamified'], true) || !in_array($count, [0, 5, 10, 20], true)) {
            header('Location: quiz.php?err=invalid');
            exit;
        }

        // Only your own decks or public ones
        $deck = fetch_one($db, 'SELECT deck_id, name FROM decks WHERE deck_id = ? AND (user_id = ? OR is_public = 1)', 'ii', [$deckId, $uid]);
        if (!$deck) {
            header('Location: quiz.php?err=invalid');
            exit;
        }

        $cards = fetch_all($db, 'SELECT f.flashcard_id, f.question_text, f.answer_text, f.hint_text
            FROM deck_flashcards df JOIN flashcards f ON f.flashcard_id = df.flashcard_id
            WHERE df.deck_id = ?', 'i', [$deckId]);

        // Pool of distinct answers (used for the multiple-choice options)
        $pool = [];
        foreach ($cards as $c) {
            $pool[norm($c['answer_text'])] = $c['answer_text'];
        }
        if (count($cards) < 2 || count($pool) < 2) {
            header('Location: quiz.php?err=few');
            exit;
        }

        shuffle($cards);
        $limit = ($count === 0) ? MAX_QUESTIONS : min($count, MAX_QUESTIONS);
        $cards = array_slice($cards, 0, $limit);

        $questions = [];
        foreach ($cards as $c) {
            $correctKey = norm($c['answer_text']);
            $wrong = [];
            foreach ($pool as $k => $text) {
                if ($k !== $correctKey) $wrong[] = $text;
            }
            shuffle($wrong);
            $options = array_merge([$c['answer_text']], array_slice($wrong, 0, 3));
            shuffle($options);
            $questions[] = [
                'q'       => $c['question_text'],
                'hint'    => $c['hint_text'],
                'options' => $options,
                'correct' => array_search($c['answer_text'], $options, true),
            ];
        }

        $_SESSION['quiz'] = [
            'deck_id'    => (int)$deck['deck_id'],
            'deck_name'  => $deck['name'],
            'mode'       => $mode,
            'questions'  => $questions,
            'idx'        => 0,
            'correct'    => 0,
            'points'     => 0,
            'streak'     => 0,
            'time_spent' => 0,
            'q_started'  => time(),
            'phase'      => 'asking',   // 'asking' or 'feedback'
            'feedback'   => null,
            'review'     => [],
        ];
        header('Location: quiz_play.php');
        exit;
    }

    // Everything below needs a quiz in progress
    $quiz = $_SESSION['quiz'] ?? null;
    if (!$quiz) {
        header('Location: quiz.php');
        exit;
    }

    // ---------------------------------------------------------- quit
    if ($action === 'quit') {
        unset($_SESSION['quiz']);
        header('Location: quiz.php');
        exit;
    }

    // ---------------------------------------------------------- answer
    if ($action === 'answer' && $quiz['phase'] === 'asking') {
        $q       = $quiz['questions'][$quiz['idx']];
        $elapsed = max(0, time() - (int)$quiz['q_started']);
        $choice  = (isset($_POST['choice']) && $_POST['choice'] !== '') ? (int)$_POST['choice'] : -1;

        $timedOut = false;
        if ($quiz['mode'] === 'Gamified' && $elapsed > GAME_SECONDS + GRACE_SECONDS) {
            $choice   = -1;      // too slow: counts as wrong
            $timedOut = true;
        }
        if ($choice < 0 || $choice >= count($q['options'])) {
            $choice = -1;
        }

        $isCorrect = ($choice === $q['correct']);
        $earned    = 0;
        if ($isCorrect) {
            $quiz['correct']++;
            $quiz['streak']++;
            if ($quiz['mode'] === 'Gamified') {
                $remaining = max(0, GAME_SECONDS - $elapsed);
                $earned = 100
                        + (int)floor(50 * $remaining / GAME_SECONDS)   // speed bonus
                        + min(50, ($quiz['streak'] - 1) * 10);         // streak bonus
            }
        } else {
            $quiz['streak'] = 0;
        }
        $quiz['points']    += $earned;
        $quiz['time_spent'] += min($elapsed, 3600);

        $quiz['review'][] = [
            'q'        => $q['q'],
            'chosen'   => $choice >= 0 ? $q['options'][$choice] : null,
            'correct'  => $q['options'][$q['correct']],
            'ok'       => $isCorrect,
            'timedOut' => $timedOut || ($choice === -1 && $quiz['mode'] === 'Gamified'),
        ];
        $quiz['phase']    = 'feedback';
        $quiz['feedback'] = [
            'ok'       => $isCorrect,
            'chosen'   => $choice >= 0 ? $q['options'][$choice] : null,
            'correct'  => $q['options'][$q['correct']],
            'earned'   => $earned,
            'timedOut' => $timedOut || ($choice === -1 && $quiz['mode'] === 'Gamified'),
        ];
        $_SESSION['quiz'] = $quiz;
        header('Location: quiz_play.php');
        exit;
    }

    // ---------------------------------------------------------- next question / finish
    if ($action === 'next' && $quiz['phase'] === 'feedback') {
        $quiz['idx']++;
        if ($quiz['idx'] >= count($quiz['questions'])) {
            $total   = count($quiz['questions']);
            $correct = (int)$quiz['correct'];
            $score   = (int)round(100 * $correct / $total);
            $points  = (int)$quiz['points'];
            $time    = (int)min($quiz['time_spent'], 16777215);
            $mode    = $quiz['mode'];
            $deckId  = (int)$quiz['deck_id'];

            $sql = 'INSERT INTO quiz_attempts
                (user_id, deck_id, quiz_score, correct_answers, total_questions, game_points, completion_time_seconds, quiz_mode)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)';
            try {
                $stmt = $db->prepare($sql);
                $stmt->bind_param('iiiiiiis', $uid, $deckId, $score, $correct, $total, $points, $time, $mode);
                $stmt->execute();
            } catch (mysqli_sql_exception $ex) {
                // The deck was deleted while the quiz was running: save the attempt without a deck link
                $deckId = null;
                $stmt = $db->prepare($sql);
                $stmt->bind_param('iiiiiiis', $uid, $deckId, $score, $correct, $total, $points, $time, $mode);
                $stmt->execute();
            }
            $attemptId = (int)$db->insert_id;
            $stmt->close();

            // Keep the question-by-question review for the results page (this session only)
            $_SESSION['quiz_review'] = ['attempt_id' => $attemptId, 'items' => $quiz['review']];
            unset($_SESSION['quiz']);
            header('Location: quiz_result.php?id=' . $attemptId);
            exit;
        }
        $quiz['phase']     = 'asking';
        $quiz['feedback']  = null;
        $quiz['q_started'] = time();
        $_SESSION['quiz']  = $quiz;
        header('Location: quiz_play.php');
        exit;
    }

    header('Location: quiz_play.php');
    exit;
}

// ================================================================== GET: show the quiz
$quiz = $_SESSION['quiz'] ?? null;
if (!$quiz) {
    header('Location: quiz.php');
    exit;
}

$total    = count($quiz['questions']);
$idx      = (int)$quiz['idx'];
$q        = $quiz['questions'][$idx];
$gamified = ($quiz['mode'] === 'Gamified');
$isLast   = ($idx === $total - 1);
$fb       = $quiz['feedback'];
$remaining = $gamified ? max(0, GAME_SECONDS - (time() - (int)$quiz['q_started'])) : null;
$progress  = (int)round(100 * ($idx + ($quiz['phase'] === 'feedback' ? 1 : 0)) / $total);

student_header('Quiz', 'quiz', $user);
?>
    <div class="page-head">
      <div>
        <div class="crumb"><?= e($quiz['deck_name']) ?> &middot; <span class="badge <?= $gamified ? 'badge-game' : 'badge-plain' ?>"><?= e($quiz['mode']) ?></span></div>
        <h2 class="page-title">Question <?= $idx + 1 ?> of <?= $total ?></h2>
      </div>
      <form method="post" action="quiz_play.php" onsubmit="return confirm('Quit this quiz? Your progress will not be saved.');">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="quit">
        <button class="btn ghost sm" type="submit">Quit quiz</button>
      </form>
    </div>

    <div class="progress"><div class="bar" style="width: <?= $progress ?>%"></div></div>

    <section class="panel quiz-card">
      <div class="quiz-meta">
        <span><?= (int)$quiz['correct'] ?> correct so far</span>
        <?php if ($gamified): ?>
          <span><strong><?= (int)$quiz['points'] ?></strong> pts<?= $quiz['streak'] >= 2 ? ' &middot; 🔥 ' . (int)$quiz['streak'] . ' streak' : '' ?></span>
        <?php endif; ?>
      </div>

      <p class="q-text"><?= e($q['q']) ?></p>

      <?php if ($quiz['phase'] === 'asking'): ?>

        <?php if ($gamified): ?>
          <div class="timer"><div class="timer-bar" id="timer-bar"></div></div>
          <div class="timer-text"><span id="timer-num"><?= (int)$remaining ?></span>s left</div>
        <?php endif; ?>

        <?php if ($q['hint'] !== null && $q['hint'] !== ''): ?>
          <details class="hint-box"><summary>Show hint</summary><?= e($q['hint']) ?></details>
        <?php endif; ?>

        <form class="quiz-form" method="post" action="quiz_play.php" id="answer-form">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="answer">
          <div class="options">
            <?php foreach ($q['options'] as $i => $opt): ?>
              <label class="opt">
                <input type="radio" name="choice" value="<?= (int)$i ?>" <?= $gamified ? '' : 'required' ?>>
                <span><?= e($opt) ?></span>
              </label>
            <?php endforeach; ?>
          </div>
          <?php if (!$gamified): ?>
            <div class="actions-row"><button class="btn" type="submit">Check answer</button></div>
          <?php endif; ?>
        </form>

        <?php if ($gamified): ?>
        <script>
          (function () {
            const form = document.getElementById('answer-form');
            const total = <?= GAME_SECONDS ?>;
            let left = <?= (int)$remaining ?>;
            const num = document.getElementById('timer-num');
            const bar = document.getElementById('timer-bar');
            let sent = false;
            function send() { if (!sent) { sent = true; form.submit(); } }
            function paint() {
              num.textContent = left;
              bar.style.width = (100 * left / total) + '%';
              bar.classList.toggle('low', left <= 5);
            }
            paint();
            // Gamified: picking an answer submits straight away
            form.querySelectorAll('input[name="choice"]').forEach(r => r.addEventListener('change', send));
            const t = setInterval(() => {
              left--;
              if (left <= 0) { left = 0; paint(); clearInterval(t); send(); return; }
              paint();
            }, 1000);
            if (left <= 0) send();
          })();
        </script>
        <?php endif; ?>

      <?php else: /* feedback */ ?>

        <div class="options">
          <?php foreach ($q['options'] as $i => $opt):
              $cls = '';
              if ($i === $q['correct']) $cls = 'right';
              elseif ($fb['chosen'] !== null && $opt === $fb['chosen']) $cls = 'wrong';
          ?>
            <div class="opt static <?= $cls ?>"><span><?= e($opt) ?></span>
              <?php if ($cls === 'right'): ?><em>Correct answer</em><?php elseif ($cls === 'wrong'): ?><em>Your answer</em><?php endif; ?>
            </div>
          <?php endforeach; ?>
        </div>

        <div class="notice <?= $fb['ok'] ? 'ok' : 'error' ?>" style="margin-top:16px">
          <?php if ($fb['ok']): ?>
            Correct!<?= $gamified ? ' +' . (int)$fb['earned'] . ' points' : '' ?>
          <?php elseif ($fb['timedOut'] && $fb['chosen'] === null): ?>
            Time's up! The answer was: <?= e($fb['correct']) ?>
          <?php else: ?>
            Not quite. The answer was: <?= e($fb['correct']) ?>
          <?php endif; ?>
        </div>

        <form method="post" action="quiz_play.php">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="next">
          <div class="actions-row"><button class="btn" type="submit" autofocus><?= $isLast ? 'See results' : 'Next question' ?></button></div>
        </form>

      <?php endif; ?>
    </section>
<?php student_footer(); ?>
