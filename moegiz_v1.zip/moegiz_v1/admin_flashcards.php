<?php
require __DIR__ . '/admin_init.php';
$admin = require_admin($db);

$q = trim($_GET['q'] ?? '');
$where  = [];
$types  = '';
$params = [];
if ($q !== '') {
    $where[] = '(f.question_text LIKE ? OR f.answer_text LIKE ? OR t.name LIKE ? OR s.name LIKE ? OR u.username LIKE ?)';
    $like = '%' . $q . '%';
    $types = 'sssss';
    $params = [$like, $like, $like, $like, $like];
}

$cards = fetch_all($db, 'SELECT f.flashcard_id, f.question_text, f.answer_text, f.hint_text, f.created_at,
        t.name AS topic, s.name AS subject, u.user_id, u.username,
        (SELECT COUNT(*) FROM deck_flashcards df WHERE df.flashcard_id = f.flashcard_id) AS in_decks
    FROM flashcards f
    JOIN topics t ON t.topic_id = f.topic_id
    JOIN subjects s ON s.subject_id = t.subject_id
    JOIN users u ON u.user_id = f.created_by '
    . ($where ? 'WHERE ' . implode(' AND ', $where) : '')
    . ' ORDER BY f.created_at DESC, f.flashcard_id DESC LIMIT 200', $types, $params);

admin_header('Flashcards', 'flashcards', $admin);
?>
    <div class="page-head">
      <h2 class="page-title">Flashcards</h2>
    </div>

    <form class="toolbar" method="get" action="admin_flashcards.php">
      <input type="text" name="q" value="<?= e($q) ?>" placeholder="Search question, answer, subject, topic or creator">
      <button class="btn" type="submit">Search</button>
      <?php if ($q !== ''): ?><a class="btn ghost" href="admin_flashcards.php">Clear</a><?php endif; ?>
    </form>

    <section class="panel">
      <h3>All flashcards <span class="count"><?= count($cards) ?> shown<?= count($cards) === 200 ? ' (limit 200)' : '' ?></span></h3>
      <?php if (!$cards): ?>
        <p class="empty">No flashcards found.</p>
      <?php else: ?>
        <div class="table-wrap">
          <table class="data">
            <thead><tr><th>Question</th><th>Answer</th><th>Subject / topic</th><th>Created by</th><th>In decks</th><th>Created</th></tr></thead>
            <tbody>
            <?php foreach ($cards as $f): ?>
              <tr>
                <td><?= e($f['question_text']) ?><?php if ($f['hint_text']): ?><div class="muted">Hint: <?= e($f['hint_text']) ?></div><?php endif; ?></td>
                <td><?= e($f['answer_text']) ?></td>
                <td><?= e($f['subject']) ?> <span class="muted">&rsaquo; <?= e($f['topic']) ?></span></td>
                <td><a class="link" href="admin_user.php?id=<?= (int)$f['user_id'] ?>"><?= e($f['username']) ?></a></td>
                <td><?= (int)$f['in_decks'] ?></td>
                <td class="nowrap"><?= e(fmt_date($f['created_at'])) ?></td>
              </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </section>
<?php admin_footer(); ?>
