<?php
require __DIR__ . '/student_init.php';
$user = require_student($db);
$uid  = (int)$user['user_id'];
$id   = (int)($_GET['id'] ?? $_POST['id'] ?? 0);

$errors = [];
$msgs = [
    'created' => 'Deck created. Add some flashcards below.',
    'saved'   => 'Deck settings saved.',
    'added'   => 'Flashcards added to the deck.',
    'removed' => 'Flashcard removed from the deck.',
    'copied'  => 'Deck copied to your decks. It is private until you make it public.',
];
$notice = $msgs[$_GET['msg'] ?? ''] ?? '';

/** Re-number a deck's cards 1..n in the given order (display_order is SMALLINT UNSIGNED). */
function set_order(mysqli $db, int $deckId, array $cardIds): void {
    $stmt = $db->prepare('UPDATE deck_flashcards SET display_order = ? WHERE deck_id = ? AND flashcard_id = ?');
    foreach (array_values($cardIds) as $i => $cid) {
        $order = min(65535, $i + 1);
        $stmt->bind_param('iii', $order, $deckId, $cid);
        $stmt->execute();
    }
    $stmt->close();
}
function deck_card_ids(mysqli $db, int $deckId): array {
    $rows = fetch_all($db, 'SELECT flashcard_id FROM deck_flashcards WHERE deck_id = ? ORDER BY display_order, flashcard_id', 'i', [$deckId]);
    return array_map(fn($r) => (int)$r['flashcard_id'], $rows);
}

// Visible if it's yours or it's public
$deck = fetch_one($db, 'SELECT d.deck_id, d.name, d.is_public, d.user_id, d.created_at, u.username
    FROM decks d JOIN users u ON u.user_id = d.user_id
    WHERE d.deck_id = ? AND (d.user_id = ? OR d.is_public = 1)', 'ii', [$id, $uid]);

if (!$deck) {
    http_response_code(404);
    student_header('Deck not found', 'decks', $user);
    echo '<div class="panel"><p class="empty">Deck not found, or it is private.</p>'
       . '<a class="link" href="my_decks.php">&larr; My decks</a> &middot; <a class="link" href="public_decks.php">Public decks</a></div>';
    student_footer();
    exit;
}

$mine = ((int)$deck['user_id'] === $uid);

// ------------------------------------------------------------------ actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if (!csrf_ok()) {
        $errors[] = 'Invalid request. Please refresh and try again.';

    // Copy someone else's public deck
    } elseif ($action === 'copy' && !$mine) {
        $copyName = mb_substr($deck['name'], 0, 93) . ' (copy)';
        try {
            $db->begin_transaction();
            $stmt = $db->prepare('INSERT INTO decks (user_id, name, is_public) VALUES (?, ?, 0)');
            $stmt->bind_param('is', $uid, $copyName);
            $stmt->execute();
            $newId = (int)$db->insert_id;
            $stmt->close();

            $stmt = $db->prepare('INSERT INTO deck_flashcards (deck_id, flashcard_id, display_order)
                SELECT ?, flashcard_id, display_order FROM deck_flashcards WHERE deck_id = ?');
            $stmt->bind_param('ii', $newId, $id);
            $stmt->execute();
            $stmt->close();
            $db->commit();

            header('Location: deck.php?id=' . $newId . '&msg=copied');
            exit;
        } catch (mysqli_sql_exception $ex) {
            $db->rollback();
            $errors[] = 'Could not copy the deck. Please try again.';
        }

    // Everything below is owner-only
    } elseif (!$mine) {
        $errors[] = 'You can only change your own decks.';

    } elseif ($action === 'save') {
        $newName  = trim($_POST['name'] ?? '');
        $isPublic = !empty($_POST['is_public']) ? 1 : 0;
        $len      = mb_strlen($newName);
        if ($len < 1 || $len > 100) {
            $errors[] = 'Enter a deck name (up to 100 characters).';
        } else {
            $stmt = $db->prepare('UPDATE decks SET name = ?, is_public = ? WHERE deck_id = ? AND user_id = ?');
            $stmt->bind_param('siii', $newName, $isPublic, $id, $uid);
            $stmt->execute();
            $stmt->close();
            header('Location: deck.php?id=' . $id . '&msg=saved');
            exit;
        }

    } elseif ($action === 'delete') {
        $stmt = $db->prepare('DELETE FROM decks WHERE deck_id = ? AND user_id = ?');
        $stmt->bind_param('ii', $id, $uid);
        $stmt->execute();
        $stmt->close();
        header('Location: my_decks.php?msg=deleted');
        exit;

    } elseif ($action === 'add') {
        $wanted = array_unique(array_map('intval', (array)($_POST['card_ids'] ?? [])));
        // Only your own flashcards that aren't already in this deck
        $allowed = fetch_all($db, 'SELECT f.flashcard_id FROM flashcards f
            WHERE f.created_by = ?
              AND f.flashcard_id NOT IN (SELECT flashcard_id FROM deck_flashcards WHERE deck_id = ?)', 'ii', [$uid, $id]);
        $allowedIds = array_map(fn($r) => (int)$r['flashcard_id'], $allowed);
        $toAdd = array_values(array_intersect($wanted, $allowedIds));

        if (!$toAdd) {
            $errors[] = 'Select at least one flashcard to add.';
        } else {
            try {
                $db->begin_transaction();
                $next = fetch_one($db, 'SELECT COALESCE(MAX(display_order), 0) AS m FROM deck_flashcards WHERE deck_id = ?', 'i', [$id]);
                $order = (int)$next['m'];
                $stmt = $db->prepare('INSERT INTO deck_flashcards (deck_id, flashcard_id, display_order) VALUES (?, ?, ?)');
                foreach ($toAdd as $cid) {
                    $order = min(65535, $order + 1);
                    $stmt->bind_param('iii', $id, $cid, $order);
                    $stmt->execute();
                }
                $stmt->close();
                $db->commit();
                header('Location: deck.php?id=' . $id . '&msg=added');
                exit;
            } catch (mysqli_sql_exception $ex) {
                $db->rollback();
                $errors[] = 'Could not add the flashcards. Please try again.';
            }
        }

    } elseif ($action === 'remove') {
        $cid = (int)($_POST['card_id'] ?? 0);
        $stmt = $db->prepare('DELETE FROM deck_flashcards WHERE deck_id = ? AND flashcard_id = ?');
        $stmt->bind_param('ii', $id, $cid);
        $stmt->execute();
        $stmt->close();
        set_order($db, $id, deck_card_ids($db, $id));
        header('Location: deck.php?id=' . $id . '&msg=removed');
        exit;

    } elseif ($action === 'move') {
        $cid = (int)($_POST['card_id'] ?? 0);
        $dir = ($_POST['dir'] ?? '') === 'up' ? -1 : 1;
        $ids = deck_card_ids($db, $id);
        $pos = array_search($cid, $ids, true);
        if ($pos !== false && isset($ids[$pos + $dir])) {
            [$ids[$pos], $ids[$pos + $dir]] = [$ids[$pos + $dir], $ids[$pos]];
            set_order($db, $id, $ids);
        }
        header('Location: deck.php?id=' . $id);
        exit;
    }

    // Keep whatever the user typed if validation failed
    if ($mine && $action === 'save') {
        $deck['name']      = trim($_POST['name'] ?? '');
        $deck['is_public'] = !empty($_POST['is_public']) ? 1 : 0;
    }
}

// ------------------------------------------------------------------ data
$cards = fetch_all($db, 'SELECT f.flashcard_id, f.question_text, f.answer_text, f.hint_text, t.name AS topic, s.name AS subject
    FROM deck_flashcards df
    JOIN flashcards f ON f.flashcard_id = df.flashcard_id
    JOIN topics t ON t.topic_id = f.topic_id
    JOIN subjects s ON s.subject_id = t.subject_id
    WHERE df.deck_id = ?
    ORDER BY df.display_order, f.flashcard_id', 'i', [$id]);

$available = [];
if ($mine) {
    $available = fetch_all($db, 'SELECT f.flashcard_id, f.question_text, f.answer_text, t.name AS topic, s.name AS subject
        FROM flashcards f
        JOIN topics t ON t.topic_id = f.topic_id
        JOIN subjects s ON s.subject_id = t.subject_id
        WHERE f.created_by = ?
          AND f.flashcard_id NOT IN (SELECT flashcard_id FROM deck_flashcards WHERE deck_id = ?)
        ORDER BY f.created_at DESC, f.flashcard_id DESC LIMIT 200', 'ii', [$uid, $id]);
}

student_header($deck['name'], $mine ? 'decks' : 'public', $user);
?>
    <div class="page-head">
      <div>
        <div class="crumb">
          <?php if ($mine): ?><a class="link" href="my_decks.php">&larr; My decks</a>
          <?php else: ?><a class="link" href="public_decks.php">&larr; Public decks</a><?php endif; ?>
        </div>
        <h2 class="page-title"><?= e($deck['name']) ?></h2>
      </div>
      <?php if (!$mine): ?>
        <form method="post" action="deck.php?id=<?= (int)$id ?>">
          <?= csrf_field() ?>
          <input type="hidden" name="id" value="<?= (int)$id ?>">
          <input type="hidden" name="action" value="copy">
          <button class="btn" type="submit">Save a copy to my decks</button>
        </form>
      <?php endif; ?>
    </div>

    <?php if ($notice): ?><div class="notice ok"><?= e($notice) ?></div><?php endif; ?>
    <?php if ($errors): ?>
      <div class="notice error"><?php foreach ($errors as $err): ?><div><?= e($err) ?></div><?php endforeach; ?></div>
    <?php endif; ?>

    <?php if ($mine): ?>
      <section class="panel">
        <h3>Deck settings</h3>
        <form class="form inline-form" method="post" action="deck.php?id=<?= (int)$id ?>">
          <?= csrf_field() ?>
          <input type="hidden" name="id" value="<?= (int)$id ?>">
          <input type="hidden" name="action" value="save">
          <div class="grow">
            <label for="name">Deck name</label>
            <input type="text" id="name" name="name" maxlength="100" required value="<?= e($deck['name']) ?>">
          </div>
          <label class="check compact">
            <input type="checkbox" name="is_public" value="1" <?= $deck['is_public'] ? 'checked' : '' ?>>
            Public
          </label>
          <button class="btn" type="submit">Save</button>
        </form>
        <form method="post" action="deck.php?id=<?= (int)$id ?>" style="margin-top:14px"
              onsubmit="return confirm('Delete this deck? Your flashcards are kept, but quiz history for this deck will lose its deck link.');">
          <?= csrf_field() ?>
          <input type="hidden" name="id" value="<?= (int)$id ?>">
          <input type="hidden" name="action" value="delete">
          <button class="btn danger sm" type="submit">Delete deck</button>
        </form>
      </section>
    <?php else: ?>
      <section class="panel">
        <p style="margin:0 0 6px">By <strong><?= e($deck['username']) ?></strong>
          &middot; <span class="badge badge-public">Public</span></p>
        <p class="muted" style="margin:0">Created <?= e(fmt_date($deck['created_at'])) ?></p>
      </section>
    <?php endif; ?>

    <section class="panel">
      <h3>Flashcards <span class="count"><?= count($cards) ?></span></h3>
      <?php if (!$cards): ?>
        <p class="empty">This deck has no flashcards yet.<?= $mine ? ' Add some below, or <a class="link" href="create_flashcard.php?deck=' . (int)$id . '">create a new one</a>.' : '' ?></p>
      <?php else: ?>
        <div class="fc-list">
          <?php foreach ($cards as $i => $f): ?>
            <div class="fc">
              <div class="fc-top">
                <div class="meta">#<?= $i + 1 ?> &middot; <?= e($f['subject']) ?> &rsaquo; <?= e($f['topic']) ?></div>
                <?php if ($mine): ?>
                  <div class="row-actions">
                    <form method="post" action="deck.php?id=<?= (int)$id ?>" style="display:inline">
                      <?= csrf_field() ?>
                      <input type="hidden" name="id" value="<?= (int)$id ?>">
                      <input type="hidden" name="action" value="move">
                      <input type="hidden" name="card_id" value="<?= (int)$f['flashcard_id'] ?>">
                      <button class="btn ghost sm" name="dir" value="up" type="submit" <?= $i === 0 ? 'disabled' : '' ?> aria-label="Move up">&uarr;</button>
                      <button class="btn ghost sm" name="dir" value="down" type="submit" <?= $i === count($cards) - 1 ? 'disabled' : '' ?> aria-label="Move down">&darr;</button>
                    </form>
                    <form method="post" action="deck.php?id=<?= (int)$id ?>" style="display:inline"
                          onsubmit="return confirm('Remove this flashcard from the deck? The flashcard itself is kept.');">
                      <?= csrf_field() ?>
                      <input type="hidden" name="id" value="<?= (int)$id ?>">
                      <input type="hidden" name="action" value="remove">
                      <input type="hidden" name="card_id" value="<?= (int)$f['flashcard_id'] ?>">
                      <button class="btn danger sm" type="submit">Remove</button>
                    </form>
                  </div>
                <?php endif; ?>
              </div>
              <div class="q">Q: <?= e($f['question_text']) ?></div>
              <div class="a">A: <?= e($f['answer_text']) ?></div>
              <?php if ($f['hint_text'] !== null && $f['hint_text'] !== ''): ?>
                <div class="h">Hint: <?= e($f['hint_text']) ?></div>
              <?php endif; ?>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </section>

    <?php if ($mine): ?>
      <section class="panel">
        <h3>Add flashcards <span class="count"><a class="link" href="create_flashcard.php?deck=<?= (int)$id ?>">+ Create a new flashcard</a></span></h3>
        <?php if (!$available): ?>
          <p class="empty">All your flashcards are already in this deck, or you haven't created any yet.</p>
        <?php else: ?>
          <form class="form" method="post" action="deck.php?id=<?= (int)$id ?>" style="max-width:none">
            <?= csrf_field() ?>
            <input type="hidden" name="id" value="<?= (int)$id ?>">
            <input type="hidden" name="action" value="add">
            <div class="checks" style="margin-top:0">
              <?php foreach ($available as $f): ?>
                <label class="check">
                  <input type="checkbox" name="card_ids[]" value="<?= (int)$f['flashcard_id'] ?>">
                  <span><?= e($f['question_text']) ?> <span class="muted">&rarr; <?= e($f['answer_text']) ?></span></span>
                  <span class="muted"><?= e($f['subject']) ?> &rsaquo; <?= e($f['topic']) ?></span>
                </label>
              <?php endforeach; ?>
            </div>
            <div class="actions-row">
              <button class="btn" type="submit">Add selected</button>
            </div>
          </form>
        <?php endif; ?>
      </section>
    <?php endif; ?>
<?php student_footer(); ?>
