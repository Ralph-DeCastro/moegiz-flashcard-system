<?php
// Shared bootstrap used by every page after login (student and admin).
require __DIR__ . '/security.php';   // hardened session_start + idle timeout + do_logout()
require __DIR__ . '/db.php';
require __DIR__ . '/admin_helpers.php'; // announcements + admin activity log

function e($s): string {
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}

// Logout (works from any page: ?logout=1)
if (isset($_GET['logout'])) {
    do_logout();
    header('Location: index.php');
    exit;
}

// CSRF helpers
if (empty($_SESSION['csrf'])) {
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
}
function csrf_field(): string {
    return '<input type="hidden" name="csrf" value="' . e($_SESSION['csrf']) . '">';
}
function csrf_ok(): bool {
    return hash_equals($_SESSION['csrf'], $_POST['csrf'] ?? '');
}

// Query helpers (prepared statements)
function fetch_all(mysqli $db, string $sql, string $types = '', array $params = []): array {
    $stmt = $db->prepare($sql);
    if ($params) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    return $rows;
}
function fetch_one(mysqli $db, string $sql, string $types = '', array $params = []): ?array {
    $rows = fetch_all($db, $sql, $types, $params);
    return $rows[0] ?? null;
}

// Formatting helpers
function fmt_date($d): string {
    return $d ? date('M j, Y g:i A', strtotime($d)) : '—';
}
function fmt_time(int $s): string {
    return floor($s / 60) . ':' . str_pad((string)($s % 60), 2, '0', STR_PAD_LEFT);
}
function role_badge(string $role): string {
    $cls = $role === 'Admin' ? 'badge-admin' : 'badge-student';
    return '<span class="badge ' . $cls . '">' . e($role) . '</span>';
}

/** Load the logged-in user from the database, or send them to the login page. */
function current_user(mysqli $db): array {
    if (empty($_SESSION['user_id'])) {
        header('Location: index.php');
        exit;
    }
    $u = fetch_one($db, 'SELECT user_id, username, email, role, created_at FROM users WHERE user_id = ?', 'i', [(int)$_SESSION['user_id']]);
    if (!$u) { // account deleted while logged in
        do_logout();
        header('Location: index.php');
        exit;
    }
    $_SESSION['role'] = $u['role']; // keep the session in sync with the database
    return $u;
}

function access_denied(string $title, string $message, string $homeHref, string $homeLabel): void {
    http_response_code(403);
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Moegiz &middot; Access denied</title>
  <link rel="stylesheet" href="dashboard.css">
</head>
<body>
  <div class="denied">
    <h1><?= e($title) ?></h1>
    <p><?= e($message) ?></p>
    <a href="<?= e($homeHref) ?>"><?= e($homeLabel) ?></a> &middot; <a href="?logout=1">Log out</a>
  </div>
</body>
</html>
    <?php
    exit;
}
