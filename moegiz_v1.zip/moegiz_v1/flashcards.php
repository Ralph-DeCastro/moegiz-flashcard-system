<?php
require __DIR__ . '/student_init.php';
$user = require_student($db);
$uid  = (int)$user['user_id'];

$q = trim($_GET['q'] ?? '');
$where  = 'f.created_by = ?';
$types  = 'i';
$params = [$uid];
if ($q !== '') {
    $where .= ' AND (f.question_text LIKE ? OR f.answer_text LIKE ? OR t.name LIKE ? OR s.name LIKE ?)';
    $like = '%' . $q . '%';
    $types .= 'ssss';
    array_push($params, $like, $like, $like, $like);
}

$cards = fetch_all($db, 'SELECT f.flashcard_id, f.question_text, f.answer_text, f.hint_text, f.created_at,
        t.name AS topic, s.name AS subject
    FROM flashcards f
    JOIN topics t ON t.topic_id = f.topic_id
    JOIN subjects s ON s.subject_id = t.subject_id
    WHERE ' . $where . '
    ORDER BY f.created_at DESC, f.flashcard_id DESC LIMIT 200', $types, $params);

// Which decks each of these flashcards is in
$deckNames = [];
foreach (fetch_all($db, 'SELECT df.flashcard_id, d.name
    FROM deck_flashcards df
    JOIN decks d ON d.deck_id = df.deck_id
    JOIN flashcards f ON f.flashcard_id = df.flashcard_id
    WHERE f.created_by = ? ORDER BY d.name', 'i', [$uid]) as $r) {
    $deckNames[(int)$r['flashcard_id']][] = $r['name'];
}

student_header('My flashcards', 'flashcards', $user);
?>
    <div class="page-head">
      <h2 class="page-title">My flashcards</h2>
      <a class="btn" href="create_flashcard.php">+ Create flashcard</a>
    </div>

    <form class="toolbar" method="get" action="flashcards.php">
      <input type="text" name="q" value="<?= e($q) ?>" placeholder="Search question, answer, subject or topic">
      <button class="btn" type="submit">Search</button>
      <?php if ($q !== ''): ?><a class="btn ghost" href="flashcards.php">Clear</a><?php endif; ?>
    </form>

    <section class="panel">
      <h3>Your flashcards <span class="count"><?= count($cards) ?> shown<?= count($cards) === 200 ? ' (limit 200)' : '' ?></span></h3>
      <?php if (!$cards): ?>
        <p class="empty"><?= $q !== '' ? 'No flashcards match your search.' : 'You haven\'t created any flashcards yet.' ?>
          <?php if ($q === ''): ?><a class="link" href="create_flashcard.php">Create your first one</a>.<?php endif; ?></p>
      <?php else: ?>
        <div class="fc-list">
          <?php foreach ($cards as $f): ?>
            <div class="fc">
              <div class="meta"><?= e($f['subject']) ?> &rsaquo; <?= e($f['topic']) ?> &middot; <?= e(fmt_date($f['created_at'])) ?></div>
              <div class="q">Q: <?= e($f['question_text']) ?></div>
              <div class="a">A: <?= e($f['answer_text']) ?></div>
              <?php if ($f['hint_text'] !== null && $f['hint_text'] !== ''): ?>
                <div class="h">Hint: <?= e($f['hint_text']) ?></div>
              <?php endif; ?>
              <div class="decks">
                <?php if (!empty($deckNames[(int)$f['flashcard_id']])): ?>
                  <?php foreach ($deckNames[(int)$f['flashcard_id']] as $n): ?>
                    <span class="badge badge-student"><?= e($n) ?></span>
                  <?php endforeach; ?>
                <?php else: ?>
                  <span class="badge badge-plain">Not in a deck</span>
                <?php endif; ?>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </section>
<?php student_footer(); ?>
