<?php
require __DIR__ . '/student_init.php';
$user = require_student($db);
$uid  = (int)$user['user_id'];

$errs = [
    'few'     => 'That deck needs at least 2 flashcards with different answers to make a quiz.',
    'invalid' => 'Please choose a deck and a quiz mode.',
];
$error = $errs[$_GET['err'] ?? ''] ?? '';

$preselect = (int)($_GET['deck'] ?? 0);

// Decks you can quiz on: your own, plus public ones. Need 2+ cards to build multiple choice.
$decks = fetch_all($db, 'SELECT d.deck_id, d.name, d.user_id, u.username,
        (SELECT COUNT(*) FROM deck_flashcards df WHERE df.deck_id = d.deck_id) AS cards
    FROM decks d JOIN users u ON u.user_id = d.user_id
    WHERE (d.user_id = ? OR d.is_public = 1)
      AND (SELECT COUNT(*) FROM deck_flashcards df2 WHERE df2.deck_id = d.deck_id) >= 2
    ORDER BY (d.user_id = ?) DESC, d.name', 'ii', [$uid, $uid]);

$mine   = array_filter($decks, fn($d) => (int)$d['user_id'] === $uid);
$others = array_filter($decks, fn($d) => (int)$d['user_id'] !== $uid);

$activeQuiz = !empty($_SESSION['quiz']);

$attempts = fetch_all($db, 'SELECT q.attempt_id, q.quiz_mode, q.quiz_score, q.correct_answers, q.total_questions,
        q.game_points, q.completion_time_seconds, q.created_at, q.deck_id, d.name AS deck_name
    FROM quiz_attempts q
    LEFT JOIN decks d ON d.deck_id = q.deck_id
    WHERE q.user_id = ?
    ORDER BY q.created_at DESC, q.attempt_id DESC LIMIT 20', 'i', [$uid]);

student_header('Quiz', 'quiz', $user);
?>
    <div class="page-head">
      <h2 class="page-title">Quiz</h2>
    </div>

    <?php if ($error): ?><div class="notice error"><?= e($error) ?></div><?php endif; ?>

    <?php if ($activeQuiz): ?>
      <div class="notice ok">You have a quiz in progress. <a class="link" href="quiz_play.php">Continue it</a> &middot; or start a new one below (this discards the old one).</div>
    <?php endif; ?>

    <section class="panel">
      <h3>Start a quiz</h3>
      <?php if (!$decks): ?>
        <p class="empty">You need a deck with at least 2 flashcards first.
          <a class="link" href="my_decks.php">Go to My decks</a> or browse <a class="link" href="public_decks.php">Public decks</a>.</p>
      <?php else: ?>
        <form class="form" method="post" action="quiz_play.php" style="max-width:none">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="start">

          <div class="row" style="max-width:560px">
            <div>
              <label for="deck_id">Deck</label>
              <select id="deck_id" name="deck_id" required>
                <option value="">Choose a deck…</option>
                <?php if ($mine): ?>
                  <optgroup label="My decks">
                    <?php foreach ($mine as $d): ?>
                      <option value="<?= (int)$d['deck_id'] ?>" <?= $preselect === (int)$d['deck_id'] ? 'selected' : '' ?>><?= e($d['name']) ?> (<?= (int)$d['cards'] ?> cards)</option>
                    <?php endforeach; ?>
                  </optgroup>
                <?php endif; ?>
                <?php if ($others): ?>
                  <optgroup label="Public decks">
                    <?php foreach ($others as $d): ?>
                      <option value="<?= (int)$d['deck_id'] ?>" <?= $preselect === (int)$d['deck_id'] ? 'selected' : '' ?>><?= e($d['name']) ?> by <?= e($d['username']) ?> (<?= (int)$d['cards'] ?> cards)</option>
                    <?php endforeach; ?>
                  </optgroup>
                <?php endif; ?>
              </select>
            </div>
            <div>
              <label for="count">Questions</label>
              <select id="count" name="count">
                <option value="5">5</option>
                <option value="10" selected>10</option>
                <option value="20">20</option>
                <option value="0">All cards (max 50)</option>
              </select>
            </div>
          </div>

          <label>Mode</label>
          <div class="mode-grid">
            <label class="mode">
              <input type="radio" name="mode" value="Standard" checked>
              <strong>Standard</strong>
              <span>Relaxed multiple choice with no timer. Your score is the percentage you get right.</span>
            </label>
            <label class="mode">
              <input type="radio" name="mode" value="Gamified">
              <strong>Gamified</strong>
              <span>15 seconds per question. Earn points for correct answers, speed and streaks.</span>
            </label>
          </div>

          <div class="actions-row">
            <button class="btn" type="submit">Start quiz</button>
          </div>
        </form>
      <?php endif; ?>
    </section>

    <section class="panel">
      <h3>Your recent attempts <span class="count"><?= count($attempts) ?></span></h3>
      <?php if (!$attempts): ?>
        <p class="empty">No quiz attempts yet. Your results will show up here.</p>
      <?php else: ?>
        <div class="table-wrap">
          <table class="data">
            <thead><tr><th>Deck</th><th>Mode</th><th>Score</th><th>Correct</th><th>Points</th><th>Time</th><th>Taken</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($attempts as $r): ?>
              <tr>
                <td><?= $r['deck_name'] !== null ? '<a class="link" href="deck.php?id=' . (int)$r['deck_id'] . '">' . e($r['deck_name']) . '</a>' : '<span class="muted">(deleted deck)</span>' ?></td>
                <td><span class="badge <?= $r['quiz_mode'] === 'Gamified' ? 'badge-game' : 'badge-plain' ?>"><?= e($r['quiz_mode']) ?></span></td>
                <td><?= (int)$r['quiz_score'] ?>%</td>
                <td><?= (int)$r['correct_answers'] ?>/<?= (int)$r['total_questions'] ?></td>
                <td><?= $r['quiz_mode'] === 'Gamified' ? (int)$r['game_points'] : '<span class="muted">—</span>' ?></td>
                <td><?= e(fmt_time((int)$r['completion_time_seconds'])) ?></td>
                <td class="nowrap"><?= e(fmt_date($r['created_at'])) ?></td>
                <td><a class="link" href="quiz_result.php?id=<?= (int)$r['attempt_id'] ?>">Details</a></td>
              </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </section>
<?php student_footer(); ?>
