<?php
require __DIR__ . '/student_init.php';
$user = require_student($db);
$uid  = (int)$user['user_id'];

$stats = fetch_one($db, 'SELECT
        (SELECT COUNT(*) FROM decks WHERE user_id = ?) AS decks,
        (SELECT COUNT(*) FROM flashcards WHERE created_by = ?) AS cards,
        (SELECT COUNT(*) FROM quiz_attempts WHERE user_id = ?) AS quizzes',
    'iii', [$uid, $uid, $uid]);

$announcements = list_announcements(3);

student_header('Home', 'home', $user);
?>
    <h2 class="page-title">Home</h2>

    <?php if ($announcements): ?>
    <section class="announce">
      <h3>Announcements</h3>
      <?php foreach ($announcements as $a): ?>
        <div class="item">
          <?php if (!empty($a['is_pinned'])): ?><span class="pin">PINNED</span><?php endif; ?><?= e($a['message']) ?>
          <div class="when"><?= e(time_ago(max(0, time() - (int)$a['ts']))) ?></div>
        </div>
      <?php endforeach; ?>
    </section>
    <?php endif; ?>

    <section class="action-cards">
      <a class="action-card" href="create_flashcard.php">
        <p class="label">Create flashcard</p>
        <p class="desc">Enter a question and answer for any topic</p>
      </a>
      <a class="action-card" href="quiz.php">
        <p class="label">Quiz</p>
        <p class="desc">Pick a deck and answer a quiz</p>
      </a>
    </section>

    <section class="welcome">
      <h2>Welcome back, <?= e($user['username']) ?>!</h2>
      <p>Ready to learn something new today? Create flashcards or jump into a quiz to keep your streak going.</p>
      <div class="stats">
        <a class="stat" href="my_decks.php">
          <div class="num"><?= (int)$stats['decks'] ?></div>
          <div class="lbl">My decks</div>
        </a>
        <a class="stat" href="flashcards.php">
          <div class="num"><?= (int)$stats['cards'] ?></div>
          <div class="lbl">My flashcards</div>
        </a>
        <a class="stat" href="quiz.php">
          <div class="num"><?= (int)$stats['quizzes'] ?></div>
          <div class="lbl">Quizzes taken</div>
        </a>
      </div>
    </section>
<?php student_footer(); ?>
