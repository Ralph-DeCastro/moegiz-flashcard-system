<?php
require __DIR__ . '/student_init.php';
$user = require_student($db);
$uid  = (int)$user['user_id'];

$errors = [];
$notice = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_ok()) {
        $errors[] = 'Invalid request. Please refresh and try again.';
    } else {
        $current = $_POST['current'] ?? '';
        $new     = $_POST['new'] ?? '';
        $confirm = $_POST['confirm'] ?? '';

        $row = fetch_one($db, 'SELECT password_hash FROM users WHERE user_id = ?', 'i', [$uid]);

        if (!$row || !password_verify($current, $row['password_hash'])) {
            $errors[] = 'Your current password is incorrect.';
        }
        if (strlen($new) < 8) {
            $errors[] = 'New password must be at least 8 characters.';
        }
        if ($new !== $confirm) {
            $errors[] = 'New passwords do not match.';
        }

        if (!$errors) {
            $hash = password_hash($new, PASSWORD_DEFAULT);
            $stmt = $db->prepare('UPDATE users SET password_hash = ? WHERE user_id = ?');
            $stmt->bind_param('si', $hash, $uid);
            $stmt->execute();
            $stmt->close();
            session_regenerate_id(true);
            $notice = 'Password updated.';
        }
    }
}

student_header('Settings', 'profile', $user);
?>
    <div class="page-head">
      <div>
        <div class="crumb"><a class="link" href="profile.php">&larr; Profile</a></div>
        <h2 class="page-title">Settings</h2>
      </div>
    </div>

    <section class="panel">
      <h3>Change password</h3>

      <?php if ($notice): ?><div class="notice ok"><?= e($notice) ?></div><?php endif; ?>
      <?php if ($errors): ?>
        <div class="notice error">
          <?php foreach ($errors as $err): ?><div><?= e($err) ?></div><?php endforeach; ?>
        </div>
      <?php endif; ?>

      <form class="form" method="post" action="settings.php">
        <?= csrf_field() ?>

        <label for="current">Current password</label>
        <input type="password" id="current" name="current" required autocomplete="current-password">

        <label for="new">New password</label>
        <input type="password" id="new" name="new" required minlength="8" autocomplete="new-password">

        <label for="confirm">Confirm new password</label>
        <input type="password" id="confirm" name="confirm" required minlength="8" autocomplete="new-password">

        <div class="actions-row">
          <button class="btn" type="submit">Update password</button>
        </div>
      </form>
    </section>
<?php student_footer(); ?>
