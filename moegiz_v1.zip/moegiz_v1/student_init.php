<?php
// Shared bootstrap + layout for all student pages.
require __DIR__ . '/common.php';

/**
 * Students only. Admins are sent to the admin area. The role is re-checked in
 * the database on every request.
 */
function require_student(mysqli $db): array {
    $user = current_user($db);
    if ($user['role'] === 'Admin') {
        header('Location: admin.php');
        exit;
    }
    if ($user['role'] !== 'Student') {
        access_denied('Students only', 'This area is for student accounts.', 'index.php', 'Back to login');
    }
    return $user;
}

function student_header(string $title, string $active, array $user): void {
    $nav = [
        'home'       => ['dashboard.php', 'Home'],
        'decks'      => ['my_decks.php', 'My decks'],
        'public'     => ['public_decks.php', 'Public decks'],
        'flashcards' => ['flashcards.php', 'My flashcards'],
        'quiz'       => ['quiz.php', 'Quiz'],
        'profile'    => ['profile.php', 'Profile'],
    ];
    $initial = mb_strtoupper(mb_substr($user['username'], 0, 1));
    $since   = date('M Y', strtotime($user['created_at']));
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Moegiz &middot; <?= e($title) ?></title>
  <link rel="stylesheet" href="dashboard.css">
  <link rel="stylesheet" href="admin.css">
  <link rel="stylesheet" href="student.css">
</head>
<body>
<div class="layout">

  <aside class="sidebar">
    <h1 class="brand"><a href="dashboard.php">Moe<span>Giz</span></a></h1>
    <nav class="nav">
      <?php foreach ($nav as $key => [$href, $label]): ?>
        <a href="<?= e($href) ?>" class="<?= $key === $active ? 'active' : '' ?>"><?= e($label) ?></a>
      <?php endforeach; ?>
    </nav>
  </aside>

  <div class="main">
    <header class="topbar">
      <a class="user-info" href="profile.php">
        <span class="avatar"><?= e($initial) ?></span>
        <div class="meta">
          <div class="name"><?= e($user['username']) ?></div>
          <div class="sub"><?= e($user['email']) ?> &middot; Student since <?= e($since) ?></div>
        </div>
      </a>

      <div class="actions">
        <div class="dropdown">
          <button class="icon-btn" type="button" aria-label="Notifications" data-toggle="notif-menu">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
              <path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/>
              <path d="M13.7 21a2 2 0 0 1-3.4 0"/>
            </svg>
          </button>
          <div class="menu" id="notif-menu">
            <div class="empty">No new notifications</div>
          </div>
        </div>

        <div class="dropdown">
          <button class="icon-btn avatar" type="button" aria-label="Account menu" data-toggle="profile-menu"><?= e($initial) ?></button>
          <div class="menu" id="profile-menu">
            <div class="who">Signed in as <strong><?= e($user['username']) ?></strong></div>
            <hr>
            <a href="profile.php">Profile</a>
            <a href="settings.php">Settings</a>
            <hr>
            <a href="?logout=1" class="logout">Logout</a>
          </div>
        </div>
      </div>
    </header>
    <?php
}

function student_footer(): void {
    ?>
  </div>
</div>
<script>
  const menus = document.querySelectorAll('.menu');
  document.querySelectorAll('[data-toggle]').forEach(btn => {
    btn.addEventListener('click', e => {
      e.stopPropagation();
      const target = document.getElementById(btn.dataset.toggle);
      const wasOpen = target.classList.contains('open');
      menus.forEach(m => m.classList.remove('open'));
      if (!wasOpen) target.classList.add('open');
    });
  });
  document.addEventListener('click', e => {
    if (!e.target.closest('.menu')) menus.forEach(m => m.classList.remove('open'));
  });
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') menus.forEach(m => m.classList.remove('open'));
  });
</script>
</body>
</html>
    <?php
}

/** Reusable deck table (rows need deck_id, name, is_public, cards, created_at; owner optional). */
function render_deck_table(array $rows, bool $showOwner = false): void {
    ?>
    <div class="table-wrap">
      <table class="data">
        <thead>
          <tr>
            <th>Deck</th>
            <?php if ($showOwner): ?><th>Owner</th><?php endif; ?>
            <th>Visibility</th><th>Cards</th><th>Created</th>
          </tr>
        </thead>
        <tbody>
        <?php foreach ($rows as $d): ?>
          <tr>
            <td><a class="link" href="deck.php?id=<?= (int)$d['deck_id'] ?>"><?= e($d['name']) ?></a></td>
            <?php if ($showOwner): ?><td><?= e($d['username']) ?></td><?php endif; ?>
            <td><span class="badge <?= $d['is_public'] ? 'badge-public' : 'badge-private' ?>"><?= $d['is_public'] ? 'Public' : 'Private' ?></span></td>
            <td><?= (int)$d['cards'] ?></td>
            <td class="nowrap"><?= e(fmt_date($d['created_at'])) ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php
}
