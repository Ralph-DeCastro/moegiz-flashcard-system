<?php
require __DIR__ . '/admin_init.php';
$admin = require_admin($db);

$q    = trim($_GET['q'] ?? '');
$role = $_GET['role'] ?? '';
if (!in_array($role, ['Student', 'Admin'], true)) {
    $role = '';
}

$where  = [];
$types  = '';
$params = [];
if ($q !== '') {
    $where[] = '(u.username LIKE ? OR u.email LIKE ?)';
    $like = '%' . $q . '%';
    $types .= 'ss';
    $params[] = $like;
    $params[] = $like;
}
if ($role !== '') {
    $where[] = 'u.role = ?';
    $types .= 's';
    $params[] = $role;
}

$sql = 'SELECT u.user_id, u.username, u.email, u.role, u.created_at,
        (SELECT COUNT(*) FROM decks d WHERE d.user_id = u.user_id) AS decks,
        (SELECT COUNT(*) FROM quiz_attempts qa WHERE qa.user_id = u.user_id) AS quizzes
    FROM users u '
    . ($where ? 'WHERE ' . implode(' AND ', $where) : '')
    . ' ORDER BY u.created_at DESC, u.user_id DESC LIMIT 200';

$users = fetch_all($db, $sql, $types, $params);

function role_link(string $label, string $value, string $current, string $q): string {
    $qs = http_build_query(array_filter(['q' => $q, 'role' => $value], fn($v) => $v !== ''));
    return '<a href="admin_users.php' . ($qs ? '?' . $qs : '') . '" class="' . ($value === $current ? 'active' : '') . '">' . e($label) . '</a>';
}

admin_header('Users', 'users', $admin);
?>
    <div class="page-head">
      <h2 class="page-title">Users</h2>
    </div>

    <?php if (($_GET['msg'] ?? '') === 'deleted'): ?>
      <div class="notice ok">Account deleted.</div>
    <?php endif; ?>

    <form class="toolbar" method="get" action="admin_users.php">
      <input type="text" name="q" value="<?= e($q) ?>" placeholder="Search username or email">
      <?php if ($role !== ''): ?><input type="hidden" name="role" value="<?= e($role) ?>"><?php endif; ?>
      <button class="btn" type="submit">Search</button>
      <div class="seg">
        <?= role_link('All', '', $role, $q) ?>
        <?= role_link('Students', 'Student', $role, $q) ?>
        <?= role_link('Admins', 'Admin', $role, $q) ?>
      </div>
    </form>

    <section class="panel">
      <h3>Accounts <span class="count"><?= count($users) ?> shown<?= count($users) === 200 ? ' (limit 200)' : '' ?></span></h3>
      <?php if (!$users): ?>
        <p class="empty">No users match your search.</p>
      <?php else: ?>
        <div class="table-wrap">
          <table class="data">
            <thead>
              <tr><th>ID</th><th>Username</th><th>Email</th><th>Role</th><th>Decks</th><th>Quizzes</th><th>Joined</th><th></th></tr>
            </thead>
            <tbody>
            <?php foreach ($users as $u): ?>
              <tr>
                <td class="muted"><?= (int)$u['user_id'] ?></td>
                <td><a class="link" href="admin_user.php?id=<?= (int)$u['user_id'] ?>"><?= e($u['username']) ?></a></td>
                <td><?= e($u['email']) ?></td>
                <td><?= role_badge($u['role']) ?></td>
                <td><?= (int)$u['decks'] ?></td>
                <td><?= (int)$u['quizzes'] ?></td>
                <td class="nowrap"><?= e(fmt_date($u['created_at'])) ?></td>
                <td><a class="link" href="admin_user.php?id=<?= (int)$u['user_id'] ?>">View</a></td>
              </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </section>
<?php admin_footer(); ?>
