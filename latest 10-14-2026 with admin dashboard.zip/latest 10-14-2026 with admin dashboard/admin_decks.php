<?php
require __DIR__ . '/admin_init.php';
$admin = require_admin($db);

$q   = trim($_GET['q'] ?? '');
$vis = $_GET['vis'] ?? '';
if (!in_array($vis, ['public', 'private'], true)) {
    $vis = '';
}

$where  = [];
$types  = '';
$params = [];
if ($q !== '') {
    $where[] = '(d.name LIKE ? OR u.username LIKE ?)';
    $like = '%' . $q . '%';
    $types .= 'ss';
    $params[] = $like;
    $params[] = $like;
}
if ($vis !== '') {
    $where[] = 'd.is_public = ' . ($vis === 'public' ? '1' : '0');
}

$sql = 'SELECT d.deck_id, d.name, d.is_public, d.created_at, u.user_id, u.username,
        (SELECT COUNT(*) FROM deck_flashcards df WHERE df.deck_id = d.deck_id) AS cards,
        (SELECT COUNT(*) FROM quiz_attempts qa WHERE qa.deck_id = d.deck_id) AS attempts
    FROM decks d JOIN users u ON u.user_id = d.user_id '
    . ($where ? 'WHERE ' . implode(' AND ', $where) : '')
    . ' ORDER BY d.created_at DESC, d.deck_id DESC LIMIT 200';

$decks = fetch_all($db, $sql, $types, $params);

function vis_link(string $label, string $value, string $current, string $q): string {
    $qs = http_build_query(array_filter(['q' => $q, 'vis' => $value], fn($v) => $v !== ''));
    return '<a href="admin_decks.php' . ($qs ? '?' . $qs : '') . '" class="' . ($value === $current ? 'active' : '') . '">' . e($label) . '</a>';
}

admin_header('Decks', 'decks', $admin);
?>
    <div class="page-head">
      <h2 class="page-title">Decks</h2>
    </div>

    <?php if (($_GET['msg'] ?? '') === 'deleted'): ?>
      <div class="notice ok">Deck deleted.</div>
    <?php endif; ?>

    <form class="toolbar" method="get" action="admin_decks.php">
      <input type="text" name="q" value="<?= e($q) ?>" placeholder="Search deck name or owner">
      <?php if ($vis !== ''): ?><input type="hidden" name="vis" value="<?= e($vis) ?>"><?php endif; ?>
      <button class="btn" type="submit">Search</button>
      <div class="seg">
        <?= vis_link('All', '', $vis, $q) ?>
        <?= vis_link('Public', 'public', $vis, $q) ?>
        <?= vis_link('Private', 'private', $vis, $q) ?>
      </div>
    </form>

    <section class="panel">
      <h3>All decks <span class="count"><?= count($decks) ?> shown<?= count($decks) === 200 ? ' (limit 200)' : '' ?></span></h3>
      <?php if (!$decks): ?>
        <p class="empty">No decks found.</p>
      <?php else: ?>
        <div class="table-wrap">
          <table class="data">
            <thead><tr><th>Deck</th><th>Owner</th><th>Visibility</th><th>Cards</th><th>Quiz attempts</th><th>Created</th></tr></thead>
            <tbody>
            <?php foreach ($decks as $d): ?>
              <tr>
                <td><a class="link" href="admin_deck.php?id=<?= (int)$d['deck_id'] ?>"><?= e($d['name']) ?></a></td>
                <td><a class="link" href="admin_user.php?id=<?= (int)$d['user_id'] ?>"><?= e($d['username']) ?></a></td>
                <td><span class="badge <?= $d['is_public'] ? 'badge-public' : 'badge-private' ?>"><?= $d['is_public'] ? 'Public' : 'Private' ?></span></td>
                <td><?= (int)$d['cards'] ?></td>
                <td><?= (int)$d['attempts'] ?></td>
                <td class="nowrap"><?= e(fmt_date($d['created_at'])) ?></td>
              </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </section>
<?php admin_footer(); ?>
