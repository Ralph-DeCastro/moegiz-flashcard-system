<?php
require __DIR__ . '/admin_init.php';
$admin = require_admin($db);

$id    = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$error = '';

$deck = fetch_one($db, 'SELECT d.deck_id, d.name, d.is_public, d.created_at, d.updated_at, u.user_id, u.username
    FROM decks d JOIN users u ON u.user_id = d.user_id WHERE d.deck_id = ?', 'i', [$id]);

// Delete deck (POST only)
if ($deck && $_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete_deck') {
    if (!csrf_ok()) {
        $error = 'Invalid request. Please refresh and try again.';
    } else {
        $stmt = $db->prepare('DELETE FROM decks WHERE deck_id = ?');
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $stmt->close();
        header('Location: admin_decks.php?msg=deleted');
        exit;
    }
}

if (!$deck) {
    http_response_code(404);
    admin_header('Deck not found', 'decks', $admin);
    echo '<div class="panel"><p class="empty">Deck not found.</p><a class="link" href="admin_decks.php">&larr; Back to decks</a></div>';
    admin_footer();
    exit;
}

$cards = fetch_all($db, 'SELECT f.flashcard_id, f.question_text, f.answer_text, f.hint_text,
        t.name AS topic, s.name AS subject, df.display_order
    FROM deck_flashcards df
    JOIN flashcards f ON f.flashcard_id = df.flashcard_id
    JOIN topics t ON t.topic_id = f.topic_id
    JOIN subjects s ON s.subject_id = t.subject_id
    WHERE df.deck_id = ?
    ORDER BY df.display_order, f.flashcard_id', 'i', [$id]);

$attempts = fetch_all($db, 'SELECT q.attempt_id, q.quiz_mode, q.quiz_score, q.correct_answers, q.total_questions,
        q.game_points, q.completion_time_seconds, q.created_at, q.deck_id,
        u.user_id, u.username, d.name AS deck_name
    FROM quiz_attempts q
    JOIN users u ON u.user_id = q.user_id
    LEFT JOIN decks d ON d.deck_id = q.deck_id
    WHERE q.deck_id = ?
    ORDER BY q.created_at DESC, q.attempt_id DESC LIMIT 100', 'i', [$id]);

admin_header($deck['name'], 'decks', $admin);
?>
    <div class="page-head">
      <div>
        <div class="crumb"><a class="link" href="admin_decks.php">&larr; Decks</a></div>
        <h2 class="page-title"><?= e($deck['name']) ?></h2>
      </div>
      <form method="post" action="admin_deck.php?id=<?= (int)$deck['deck_id'] ?>"
            onsubmit="return confirm('Delete this deck and its quiz links? The flashcards themselves are kept. This cannot be undone.');">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="delete_deck">
        <input type="hidden" name="id" value="<?= (int)$deck['deck_id'] ?>">
        <button class="btn danger" type="submit">Delete deck</button>
      </form>
    </div>

    <?php if ($error): ?><div class="notice error"><?= e($error) ?></div><?php endif; ?>

    <section class="panel">
      <p style="margin:0 0 6px">
        Owner: <a class="link" href="admin_user.php?id=<?= (int)$deck['user_id'] ?>"><?= e($deck['username']) ?></a>
        &middot; <span class="badge <?= $deck['is_public'] ? 'badge-public' : 'badge-private' ?>"><?= $deck['is_public'] ? 'Public' : 'Private' ?></span>
      </p>
      <p class="muted" style="margin:0">
        Created <?= e(fmt_date($deck['created_at'])) ?> &middot; Updated <?= e(fmt_date($deck['updated_at'])) ?>
      </p>
    </section>

    <section class="panel">
      <h3>Flashcards <span class="count"><?= count($cards) ?></span></h3>
      <?php if (!$cards): ?>
        <p class="empty">This deck has no flashcards.</p>
      <?php else: ?>
        <div class="fc-list">
          <?php foreach ($cards as $i => $f): ?>
            <div class="fc">
              <div class="meta">#<?= $i + 1 ?> &middot; <?= e($f['subject']) ?> &rsaquo; <?= e($f['topic']) ?></div>
              <div class="q">Q: <?= e($f['question_text']) ?></div>
              <div class="a">A: <?= e($f['answer_text']) ?></div>
              <?php if ($f['hint_text'] !== null && $f['hint_text'] !== ''): ?>
                <div class="h">Hint: <?= e($f['hint_text']) ?></div>
              <?php endif; ?>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </section>

    <section class="panel">
      <h3>Quiz attempts on this deck <span class="count"><?= count($attempts) ?></span></h3>
      <?php render_attempts($attempts, true, false); ?>
    </section>
<?php admin_footer(); ?>
