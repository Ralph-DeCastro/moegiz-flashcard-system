<?php
require __DIR__ . '/admin_init.php';
$admin = require_admin($db);

$q    = trim($_GET['q'] ?? '');
$mode = $_GET['mode'] ?? '';
if (!in_array($mode, ['Standard', 'Gamified'], true)) {
    $mode = '';
}

$where  = [];
$types  = '';
$params = [];
if ($q !== '') {
    $where[] = '(u.username LIKE ? OR d.name LIKE ?)';
    $like = '%' . $q . '%';
    $types .= 'ss';
    $params[] = $like;
    $params[] = $like;
}
if ($mode !== '') {
    $where[] = 'q.quiz_mode = ?';
    $types .= 's';
    $params[] = $mode;
}

$sql = 'SELECT q.attempt_id, q.quiz_mode, q.quiz_score, q.correct_answers, q.total_questions,
        q.game_points, q.completion_time_seconds, q.created_at, q.deck_id,
        u.user_id, u.username, d.name AS deck_name
    FROM quiz_attempts q
    JOIN users u ON u.user_id = q.user_id
    LEFT JOIN decks d ON d.deck_id = q.deck_id '
    . ($where ? 'WHERE ' . implode(' AND ', $where) : '')
    . ' ORDER BY q.created_at DESC, q.attempt_id DESC LIMIT 200';

$attempts = fetch_all($db, $sql, $types, $params);

function mode_link(string $label, string $value, string $current, string $q): string {
    $qs = http_build_query(array_filter(['q' => $q, 'mode' => $value], fn($v) => $v !== ''));
    return '<a href="admin_quizzes.php' . ($qs ? '?' . $qs : '') . '" class="' . ($value === $current ? 'active' : '') . '">' . e($label) . '</a>';
}

admin_header('Quiz attempts', 'quizzes', $admin);
?>
    <div class="page-head">
      <h2 class="page-title">Quiz attempts</h2>
    </div>

    <form class="toolbar" method="get" action="admin_quizzes.php">
      <input type="text" name="q" value="<?= e($q) ?>" placeholder="Search student or deck">
      <?php if ($mode !== ''): ?><input type="hidden" name="mode" value="<?= e($mode) ?>"><?php endif; ?>
      <button class="btn" type="submit">Search</button>
      <div class="seg">
        <?= mode_link('All', '', $mode, $q) ?>
        <?= mode_link('Standard', 'Standard', $mode, $q) ?>
        <?= mode_link('Gamified', 'Gamified', $mode, $q) ?>
      </div>
    </form>

    <section class="panel">
      <h3>All attempts <span class="count"><?= count($attempts) ?> shown<?= count($attempts) === 200 ? ' (limit 200)' : '' ?></span></h3>
      <?php render_attempts($attempts, true, true); ?>
    </section>
<?php admin_footer(); ?>
