<?php
require __DIR__ . '/admin_init.php';
$admin = require_admin($db);

$c = fetch_one($db, "SELECT
    (SELECT COUNT(*) FROM users WHERE role = 'Student') AS students,
    (SELECT COUNT(*) FROM users WHERE role = 'Admin') AS admins,
    (SELECT COUNT(*) FROM decks) AS decks,
    (SELECT COUNT(*) FROM decks WHERE is_public = 1) AS public_decks,
    (SELECT COUNT(*) FROM flashcards) AS flashcards,
    (SELECT COUNT(*) FROM quiz_attempts) AS attempts,
    (SELECT COALESCE(SUM(correct_answers), 0) FROM quiz_attempts) AS correct,
    (SELECT COALESCE(SUM(total_questions), 0) FROM quiz_attempts) AS total_q");

$accuracy = ((int)$c['total_q'] > 0) ? round(100 * (int)$c['correct'] / (int)$c['total_q']) . '%' : '—';

$recentUsers = fetch_all($db, 'SELECT user_id, username, email, role, created_at FROM users ORDER BY created_at DESC, user_id DESC LIMIT 6');

$recentAttempts = fetch_all($db, 'SELECT q.attempt_id, q.quiz_mode, q.quiz_score, q.correct_answers, q.total_questions,
        q.game_points, q.completion_time_seconds, q.created_at, q.deck_id,
        u.user_id, u.username, d.name AS deck_name
    FROM quiz_attempts q
    JOIN users u ON u.user_id = q.user_id
    LEFT JOIN decks d ON d.deck_id = q.deck_id
    ORDER BY q.created_at DESC, q.attempt_id DESC
    LIMIT 8');

admin_header('Overview', 'overview', $admin);
?>
    <div class="page-head">
      <h2 class="page-title">Overview</h2>
    </div>

    <section class="stat-grid">
      <div class="tile"><div class="num"><?= (int)$c['students'] ?></div><div class="lbl">Students</div></div>
      <div class="tile"><div class="num"><?= (int)$c['admins'] ?></div><div class="lbl">Admins</div></div>
      <div class="tile"><div class="num"><?= (int)$c['decks'] ?></div><div class="lbl">Decks (<?= (int)$c['public_decks'] ?> public)</div></div>
      <div class="tile"><div class="num"><?= (int)$c['flashcards'] ?></div><div class="lbl">Flashcards</div></div>
      <div class="tile"><div class="num"><?= (int)$c['attempts'] ?></div><div class="lbl">Quiz attempts</div></div>
      <div class="tile"><div class="num"><?= e($accuracy) ?></div><div class="lbl">Overall accuracy</div></div>
    </section>

    <div class="two-col">
      <section class="panel">
        <h3>Newest accounts <a class="link count" href="admin_users.php">View all</a></h3>
        <?php if (!$recentUsers): ?>
          <p class="empty">No accounts yet.</p>
        <?php else: ?>
          <div class="table-wrap">
            <table class="data">
              <thead><tr><th>User</th><th>Role</th><th>Joined</th></tr></thead>
              <tbody>
              <?php foreach ($recentUsers as $u): ?>
                <tr>
                  <td>
                    <a class="link" href="admin_user.php?id=<?= (int)$u['user_id'] ?>"><?= e($u['username']) ?></a>
                    <div class="muted"><?= e($u['email']) ?></div>
                  </td>
                  <td><?= role_badge($u['role']) ?></td>
                  <td class="nowrap"><?= e(fmt_date($u['created_at'])) ?></td>
                </tr>
              <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        <?php endif; ?>
      </section>

      <section class="panel">
        <h3>Latest quiz attempts <a class="link count" href="admin_quizzes.php">View all</a></h3>
        <?php render_attempts($recentAttempts, true, true); ?>
      </section>
    </div>
<?php admin_footer(); ?>
