<?php
// Shared bootstrap + layout for all admin pages.
session_start();
require __DIR__ . '/db.php';

function e($s): string {
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}

// Logout (works from any admin page)
if (isset($_GET['logout'])) {
    $_SESSION = [];
    session_destroy();
    header('Location: index.php');
    exit;
}

// CSRF helpers
if (empty($_SESSION['csrf'])) {
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
}
function csrf_field(): string {
    return '<input type="hidden" name="csrf" value="' . e($_SESSION['csrf']) . '">';
}
function csrf_ok(): bool {
    return hash_equals($_SESSION['csrf'], $_POST['csrf'] ?? '');
}

// Query helpers (prepared statements)
function fetch_all(mysqli $db, string $sql, string $types = '', array $params = []): array {
    $stmt = $db->prepare($sql);
    if ($params) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    return $rows;
}
function fetch_one(mysqli $db, string $sql, string $types = '', array $params = []): ?array {
    $rows = fetch_all($db, $sql, $types, $params);
    return $rows[0] ?? null;
}

/**
 * Only Admin accounts may pass. The role is re-checked in the database on
 * every request, so a demoted or deleted account loses access immediately.
 */
function require_admin(mysqli $db): array {
    if (empty($_SESSION['user_id'])) {
        header('Location: index.php');
        exit;
    }
    $admin = fetch_one($db, 'SELECT user_id, username, email, role FROM users WHERE user_id = ?', 'i', [(int)$_SESSION['user_id']]);
    if (!$admin) {
        $_SESSION = [];
        session_destroy();
        header('Location: index.php');
        exit;
    }
    if ($admin['role'] !== 'Admin') {
        http_response_code(403);
        ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Moegiz &middot; Access denied</title>
  <link rel="stylesheet" href="dashboard.css">
</head>
<body>
  <div class="denied">
    <h1>Admins only</h1>
    <p>You don't have permission to view this page.</p>
    <a href="dashboard.php">Go to my dashboard</a> &middot; <a href="admin.php?logout=1">Log out</a>
  </div>
</body>
</html>
        <?php
        exit;
    }
    return $admin;
}

// Formatting helpers
function fmt_date($d): string {
    return $d ? date('M j, Y g:i A', strtotime($d)) : '—';
}
function fmt_time(int $s): string {
    return floor($s / 60) . ':' . str_pad((string)($s % 60), 2, '0', STR_PAD_LEFT);
}
function role_badge(string $role): string {
    $cls = $role === 'Admin' ? 'badge-admin' : 'badge-student';
    return '<span class="badge ' . $cls . '">' . e($role) . '</span>';
}

// Reusable quiz attempts table
function render_attempts(array $rows, bool $showUser = true, bool $showDeck = true): void {
    if (!$rows) {
        echo '<p class="empty">No quiz attempts yet.</p>';
        return;
    }
    ?>
    <div class="table-wrap">
      <table class="data">
        <thead>
          <tr>
            <?php if ($showUser): ?><th>Student</th><?php endif; ?>
            <?php if ($showDeck): ?><th>Deck</th><?php endif; ?>
            <th>Mode</th><th>Score</th><th>Correct</th><th>Points</th><th>Time</th><th>Taken</th>
          </tr>
        </thead>
        <tbody>
        <?php foreach ($rows as $r): ?>
          <tr>
            <?php if ($showUser): ?>
              <td><a class="link" href="admin_user.php?id=<?= (int)$r['user_id'] ?>"><?= e($r['username']) ?></a></td>
            <?php endif; ?>
            <?php if ($showDeck): ?>
              <td>
                <?php if ($r['deck_id'] !== null && $r['deck_name'] !== null): ?>
                  <a class="link" href="admin_deck.php?id=<?= (int)$r['deck_id'] ?>"><?= e($r['deck_name']) ?></a>
                <?php else: ?>
                  <span class="muted">(deleted deck)</span>
                <?php endif; ?>
              </td>
            <?php endif; ?>
            <td><span class="badge <?= $r['quiz_mode'] === 'Gamified' ? 'badge-game' : 'badge-plain' ?>"><?= e($r['quiz_mode']) ?></span></td>
            <td><?= (int)$r['quiz_score'] ?></td>
            <td><?= (int)$r['correct_answers'] ?>/<?= (int)$r['total_questions'] ?></td>
            <td><?= $r['quiz_mode'] === 'Gamified' ? (int)$r['game_points'] : '<span class="muted">—</span>' ?></td>
            <td><?= e(fmt_time((int)$r['completion_time_seconds'])) ?></td>
            <td class="nowrap"><?= e(fmt_date($r['created_at'])) ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php
}

// Page chrome
function admin_header(string $title, string $active, array $admin): void {
    $nav = [
        'overview' => ['admin.php', 'Overview'],
        'users'    => ['admin_users.php', 'Users'],
        'decks'    => ['admin_decks.php', 'Decks'],
        'quizzes'  => ['admin_quizzes.php', 'Quiz attempts'],
    ];
    $initial = mb_strtoupper(mb_substr($admin['username'], 0, 1));
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Moegiz Admin &middot; <?= e($title) ?></title>
  <link rel="stylesheet" href="dashboard.css">
  <link rel="stylesheet" href="admin.css">
</head>
<body>
<div class="layout">
  <aside class="sidebar">
    <h1 class="brand">Moe<span>Giz</span> <small class="tag">Admin</small></h1>
    <nav class="nav">
      <?php foreach ($nav as $key => [$href, $label]): ?>
        <a href="<?= e($href) ?>" class="<?= $key === $active ? 'active' : '' ?>"><?= e($label) ?></a>
      <?php endforeach; ?>
    </nav>
  </aside>

  <div class="main">
    <header class="topbar">
      <div class="user-info">
        <span class="avatar"><?= e($initial) ?></span>
        <div class="meta">
          <div class="name"><?= e($admin['username']) ?></div>
          <div class="sub">Administrator &middot; <?= e($admin['email']) ?></div>
        </div>
      </div>
      <div class="actions">
        <div class="dropdown">
          <button class="icon-btn avatar" type="button" aria-label="Account menu" data-toggle="profile-menu"><?= e($initial) ?></button>
          <div class="menu" id="profile-menu">
            <div class="who">Signed in as <strong><?= e($admin['username']) ?></strong></div>
            <hr>
            <a href="admin.php?logout=1" class="logout">Logout</a>
          </div>
        </div>
      </div>
    </header>
    <?php
}

function admin_footer(): void {
    ?>
  </div>
</div>
<script>
  const menus = document.querySelectorAll('.menu');
  document.querySelectorAll('[data-toggle]').forEach(btn => {
    btn.addEventListener('click', e => {
      e.stopPropagation();
      const target = document.getElementById(btn.dataset.toggle);
      const wasOpen = target.classList.contains('open');
      menus.forEach(m => m.classList.remove('open'));
      if (!wasOpen) target.classList.add('open');
    });
  });
  document.addEventListener('click', e => {
    if (!e.target.closest('.menu')) menus.forEach(m => m.classList.remove('open'));
  });
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') menus.forEach(m => m.classList.remove('open'));
  });
</script>
</body>
</html>
    <?php
}
