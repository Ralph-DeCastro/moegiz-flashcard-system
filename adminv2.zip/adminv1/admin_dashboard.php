<?php
require __DIR__ . '/security.php';
require __DIR__ . '/db.php';
require __DIR__ . '/admin_helpers.php';

function e(string $s): string {
    return htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
}

// Must be logged in
if (empty($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

// Logout
if (isset($_GET['logout'])) {
    do_logout();
    header('Location: index.php');
    exit;
}

// Admins only (role is re-checked against the database, not just the session)
$adminId = (int)$_SESSION['user_id'];
$stmt = $db->prepare('SELECT username, email, role FROM users WHERE user_id = ?');
$stmt->bind_param('i', $adminId);
$stmt->execute();
$admin = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$admin) { // account deleted while logged in
    do_logout();
    header('Location: index.php');
    exit;
}

if ($admin['role'] !== 'Admin') {
    http_response_code(403);
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Moegiz &middot; Access denied</title>
  <link rel="stylesheet" href="dashboard.css">
</head>
<body>
  <div class="denied">
    <h1>Admins only</h1>
    <p>This dashboard is for administrator accounts.</p>
    <a href="dashboard.php">Go to student dashboard</a> &middot;
    <a href="admin_dashboard.php?logout=1">Log out</a>
  </div>
</body>
</html>
    <?php
    exit;
}
$_SESSION['role'] = $admin['role'];
$adminName = $admin['username'];

// CSRF token
if (empty($_SESSION['csrf'])) {
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
}

// Optional columns are detected, so nothing crashes if your table uses different names
$quizTime  = pick_column($db, 'quiz_attempts', ['created_at', 'attempted_at', 'taken_at', 'completed_at', 'finished_at', 'submitted_at', 'started_at', 'date_taken']);
$deckTime  = pick_column($db, 'decks', ['created_at', 'date_created']);
$deckTitle = pick_column($db, 'decks', ['title', 'name', 'deck_name', 'deck_title']);

$roles   = ['Student', 'Admin'];
$flash   = '';
$flashOk = true;

// ---------- Actions (POST) ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $anchor = '';
    if (!hash_equals($_SESSION['csrf'], $_POST['csrf'] ?? '')) {
        $flash = 'Invalid request. Please refresh and try again.';
        $flashOk = false;
    } else {
        $action   = $_POST['action'] ?? '';
        $targetId = (int)($_POST['user_id'] ?? 0);

        if ($action === 'post_announcement') {
            $anchor  = '#announcements';
            $message = trim($_POST['message'] ?? '');
            $pinned  = !empty($_POST['pin']) ? 1 : 0;
            if ($message === '' || mb_strlen($message) > 500) {
                $flash = 'Announcement must be 1-500 characters.';
                $flashOk = false;
            } else {
                add_announcement($adminId, $message, (bool)$pinned);
                log_admin($adminId, $adminName, 'Announcement', 'posted');
                $flash = 'Announcement posted.';
            }
        } elseif ($action === 'delete_announcement') {
            $anchor = '#announcements';
            if (delete_announcement((string)($_POST['announcement_id'] ?? ''))) {
                log_admin($adminId, $adminName, 'Announcement', 'deleted');
                $flash = 'Announcement deleted.';
            } else {
                $flash = 'Announcement not found.';
                $flashOk = false;
            }
        } elseif ($targetId === $adminId) {
            $flash = 'You cannot change or delete your own account from here.';
            $flashOk = false;
        } elseif ($action === 'set_role') {
            $newRole = $_POST['role'] ?? '';
            if (!in_array($newRole, $roles, true)) {
                $flash = 'Unknown role.';
                $flashOk = false;
            } else {
                $targetName = username_of($db, $targetId);
                $stmt = $db->prepare('UPDATE users SET role = ? WHERE user_id = ?');
                $stmt->bind_param('si', $newRole, $targetId);
                $stmt->execute();
                $changed = $stmt->affected_rows > 0;
                $stmt->close();
                if ($changed) log_admin($adminId, $adminName, 'Role', $targetName . ' → ' . $newRole);
                $flash = $changed ? 'Role updated.' : 'No changes made.';
            }
        } elseif ($action === 'delete_user') {
            $targetName = username_of($db, $targetId);
            try {
                $stmt = $db->prepare('DELETE FROM users WHERE user_id = ?');
                $stmt->bind_param('i', $targetId);
                $stmt->execute();
                $deleted = $stmt->affected_rows > 0;
                $stmt->close();
                if ($deleted) log_admin($adminId, $adminName, 'Delete', 'user ' . $targetName);
                $flash = $deleted ? 'User deleted.' : 'User not found.';
                $flashOk = $deleted;
            } catch (mysqli_sql_exception $ex) {
                $flash = 'Could not delete this user (they may still have decks or quiz data linked to them).';
                $flashOk = false;
            }
        }
    }
    // Post/Redirect/Get, keep the current search + page
    $_SESSION['flash'] = [$flash, $flashOk];
    $back = 'admin_dashboard.php?' . http_build_query([
        'q'    => $_POST['q'] ?? '',
        'page' => max(1, (int)($_POST['page'] ?? 1)),
    ]) . ($anchor ?? '');
    header('Location: ' . $back);
    exit;
}

if (!empty($_SESSION['flash'])) {
    [$flash, $flashOk] = $_SESSION['flash'];
    unset($_SESSION['flash']);
}

// ---------- Stats ----------
function scalar(mysqli $db, string $sql): int {
    $res = $db->query($sql);
    $row = $res->fetch_row();
    return (int)($row[0] ?? 0);
}

$totalUsers    = scalar($db, 'SELECT COUNT(*) FROM users');
$totalStudents = scalar($db, "SELECT COUNT(*) FROM users WHERE role = 'Student'");
$totalAdmins   = scalar($db, "SELECT COUNT(*) FROM users WHERE role = 'Admin'");
$newThisWeek   = scalar($db, 'SELECT COUNT(*) FROM users WHERE created_at >= (NOW() - INTERVAL 7 DAY)');
$totalDecks    = scalar($db, 'SELECT COUNT(*) FROM decks');
$totalQuizzes  = scalar($db, 'SELECT COUNT(*) FROM quiz_attempts');

// Sign-ups per month, last 6 months (including empty months)
$signups = [];
for ($i = 5; $i >= 0; $i--) {
    $key = date('Y-m', strtotime("first day of -$i month"));
    $signups[$key] = 0;
}
$res = $db->query("SELECT DATE_FORMAT(created_at, '%Y-%m') AS ym, COUNT(*) AS n
                   FROM users
                   WHERE created_at >= DATE_FORMAT(NOW() - INTERVAL 5 MONTH, '%Y-%m-01')
                   GROUP BY ym");
while ($r = $res->fetch_assoc()) {
    if (isset($signups[$r['ym']])) $signups[$r['ym']] = (int)$r['n'];
}
$maxSignup = max(1, max($signups));

// Most active learners
$topLearners = $db->query(
    "SELECT u.username,
            (SELECT COUNT(*) FROM decks d WHERE d.user_id = u.user_id)         AS decks,
            (SELECT COUNT(*) FROM quiz_attempts q WHERE q.user_id = u.user_id) AS quizzes
     FROM users u
     ORDER BY quizzes DESC, decks DESC, u.username ASC
     LIMIT 5"
)->fetch_all(MYSQLI_ASSOC);

// ---------- NEW: Activity over time (quizzes per day, last 30 days) ----------
$perDay = [];
for ($i = 29; $i >= 0; $i--) {
    $perDay[date('Y-m-d', strtotime("-$i day"))] = 0;
}
if ($quizTime) {
    $res = $db->query("SELECT DATE(`$quizTime`) AS d, COUNT(*) AS n
                       FROM quiz_attempts
                       WHERE `$quizTime` >= (CURDATE() - INTERVAL 29 DAY)
                       GROUP BY d");
    while ($r = $res->fetch_assoc()) {
        if (isset($perDay[$r['d']])) $perDay[$r['d']] = (int)$r['n'];
    }
}
$dayKeys  = array_keys($perDay);
$dayVals  = array_values($perDay);
$chartMax = max(4, (int)(ceil(max($dayVals) / 4) * 4));   // multiple of 4 so the 4 grid steps are whole numbers
$cw = 620; $ch = 200; $cl = 34; $cb = 26; $ct = 10; $cr = 10;
$cx = fn(int $i): float => $cl + $i * ($cw - $cl - $cr) / (count($dayVals) - 1);
$cy = fn(float $v): float => $ct + ($ch - $ct - $cb) * (1 - $v / $chartMax);
$linePts = [];
foreach ($dayVals as $i => $v) $linePts[] = round($cx($i), 1) . ',' . round($cy($v), 1);
$linePts  = implode(' ', $linePts);
$areaPts  = round($cx(0), 1) . ',' . round($cy(0), 1) . ' ' . $linePts . ' ' . round($cx(count($dayVals) - 1), 1) . ',' . round($cy(0), 1);

// ---------- NEW: Active vs. inactive users (students + guests, not admins) ----------
$activeN = $inactiveN = $neverN = 0;
if ($quizTime) {
    $nonAdmin  = scalar($db, "SELECT COUNT(*) FROM users WHERE role <> 'Admin'");
    $everQuiz  = scalar($db, "SELECT COUNT(DISTINCT u.user_id) FROM users u JOIN quiz_attempts q ON q.user_id = u.user_id WHERE u.role <> 'Admin'");
    $activeN   = scalar($db, "SELECT COUNT(DISTINCT u.user_id) FROM users u JOIN quiz_attempts q ON q.user_id = u.user_id
                              WHERE u.role <> 'Admin' AND q.`$quizTime` >= (NOW() - INTERVAL 7 DAY)");
    $inactiveN = max(0, $everQuiz - $activeN);
    $neverN    = max(0, $nonAdmin - $everQuiz);
}
$donutTotal = $activeN + $inactiveN + $neverN;
$activePct  = $donutTotal > 0 ? (int)round($activeN / $donutTotal * 100) : 0;
$circ       = 2 * M_PI * 48;

// ---------- NEW: Recent activity feed (joins + decks + quizzes, newest first) ----------
$feed = [];
$res = $db->query("SELECT username AS who, role AS info, TIMESTAMPDIFF(SECOND, created_at, NOW()) AS secs
                   FROM users WHERE role <> 'Admin' ORDER BY created_at DESC LIMIT 8");
while ($r = $res->fetch_assoc()) $feed[] = ['kind' => 'join'] + $r;
if ($deckTime) {
    $titleSel = $deckTitle ? "d.`$deckTitle`" : "''";
    $res = $db->query("SELECT u.username AS who, $titleSel AS info, TIMESTAMPDIFF(SECOND, d.`$deckTime`, NOW()) AS secs
                       FROM decks d JOIN users u ON u.user_id = d.user_id ORDER BY d.`$deckTime` DESC LIMIT 8");
    while ($r = $res->fetch_assoc()) $feed[] = ['kind' => 'deck'] + $r;
}
if ($quizTime) {
    $res = $db->query("SELECT u.username AS who, '' AS info, TIMESTAMPDIFF(SECOND, q.`$quizTime`, NOW()) AS secs
                       FROM quiz_attempts q JOIN users u ON u.user_id = q.user_id ORDER BY q.`$quizTime` DESC LIMIT 8");
    while ($r = $res->fetch_assoc()) $feed[] = ['kind' => 'quiz'] + $r;
}
usort($feed, fn($a, $b) => (int)$a['secs'] <=> (int)$b['secs']);
$feed = array_slice($feed, 0, 8);

// ---------- NEW: Admin activity log (latest 8) ----------
$logs = read_admin_log(8);

// ---------- NEW: Announcements (pinned first, latest 5) ----------
$announcements = list_announcements(5);

// ---------- Users table (search + pagination) ----------
$q       = trim($_GET['q'] ?? '');
$perPage = 10;
$page    = max(1, (int)($_GET['page'] ?? 1));

$where  = '';
$params = [];
$types  = '';
if ($q !== '') {
    $where  = 'WHERE u.username LIKE ? OR u.email LIKE ?';
    $like   = '%' . addcslashes($q, '%_\\') . '%';
    $params = [$like, $like];
    $types  = 'ss';
}

$stmt = $db->prepare("SELECT COUNT(*) FROM users u $where");
if ($params) $stmt->bind_param($types, ...$params);
$stmt->execute();
$stmt->bind_result($matchCount);
$stmt->fetch();
$stmt->close();

$pages  = max(1, (int)ceil($matchCount / $perPage));
$page   = min($page, $pages);
$offset = ($page - 1) * $perPage;

$sql = "SELECT u.user_id, u.username, u.email, u.role, u.created_at,
               (SELECT COUNT(*) FROM decks d WHERE d.user_id = u.user_id)         AS decks,
               (SELECT COUNT(*) FROM quiz_attempts a WHERE a.user_id = u.user_id) AS quizzes
        FROM users u $where
        ORDER BY u.created_at DESC, u.user_id DESC
        LIMIT ? OFFSET ?";
$stmt = $db->prepare($sql);
$bindTypes  = $types . 'ii';
$bindParams = array_merge($params, [$perPage, $offset]);
$stmt->bind_param($bindTypes, ...$bindParams);
$stmt->execute();
$users = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$username = $admin['username'];
$initial  = mb_strtoupper(mb_substr($username, 0, 1));

function pageUrl(int $p, string $q): string {
    return 'admin_dashboard.php?' . http_build_query(['q' => $q, 'page' => $p]);
}
function logClass(string $action): string {
    return ['Role' => 'role', 'Delete' => 'del', 'Announcement' => 'ann2'][$action] ?? '';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Moegiz &middot; Admin</title>
  <link rel="stylesheet" href="dashboard.css">
  <link rel="stylesheet" href="admin.css">
</head>
<body>
<div class="layout">

  <!-- Sidebar -->
  <aside class="sidebar">
    <h1 class="brand">Moe<span>Giz</span></h1>
    <nav class="nav">
      <a href="admin_dashboard.php" class="active">Overview</a>
      <a href="admin_users.php">Users</a>
      <a href="admin_announcements.php">Announcements</a>
      <a href="admin_activity_log.php">Activity log</a>
    </nav>
    <span class="role-pill">Admin</span>
  </aside>

  <div class="main">

    <!-- Top bar: notification + account circles (top right) -->
    <header class="topbar topbar-right">
      <div class="actions">
        <div class="dropdown">
          <button class="icon-btn" type="button" aria-label="Notifications" data-toggle="notif-menu">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
              <path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/>
              <path d="M13.7 21a2 2 0 0 1-3.4 0"/>
            </svg>
          </button>
          <div class="menu" id="notif-menu">
            <div class="empty"><?= $newThisWeek ?> new user<?= $newThisWeek === 1 ? '' : 's' ?> this week</div>
          </div>
        </div>
        <div class="dropdown">
          <button class="icon-btn avatar" type="button" aria-label="Account menu" data-toggle="profile-menu"><?= e($initial) ?></button>
          <div class="menu" id="profile-menu">
            <div class="who">Signed in as <strong><?= e($username) ?></strong><br><?= e($admin['email']) ?></div>
            <hr>
            <a href="admin_dashboard.php?logout=1" class="logout">Logout</a>
          </div>
        </div>
      </div>
    </header>

    <div class="content">

      <?php if ($flash): ?>
        <div class="flash <?= $flashOk ? 'ok' : 'error' ?>" role="status"><?= e($flash) ?></div>
      <?php endif; ?>

      <!-- Welcome remarks -->
      <section class="panel welcome-card">
        <h2>Welcome back, <?= e($username) ?>!</h2>
        <p>Here&rsquo;s how Moegiz is doing today, <?= e(date('l, F j')) ?>.</p>
      </section>

      <!-- Three cards: overview / most active learners / sign-ups -->
      <section class="trio">
        <div class="panel">
          <h3>Admin overview</h3>
          <div class="mini-tiles">
            <div class="tile"><div class="num"><?= $totalUsers ?></div><div class="lbl">Total users</div></div>
            <div class="tile"><div class="num"><?= $totalStudents ?></div><div class="lbl">Students</div></div>
            <div class="tile"><div class="num"><?= $totalAdmins ?></div><div class="lbl">Admins</div></div>
            <div class="tile"><div class="num"><?= $newThisWeek ?></div><div class="lbl">New this week</div></div>
            <div class="tile"><div class="num"><?= $totalDecks ?></div><div class="lbl">Decks created</div></div>
            <div class="tile"><div class="num"><?= $totalQuizzes ?></div><div class="lbl">Quizzes taken</div></div>
          </div>
        </div>

        <div class="panel">
          <h3>Most active learners</h3>
          <?php if (!$topLearners): ?>
            <p class="muted">No activity yet.</p>
          <?php else: ?>
            <table class="mini">
              <thead><tr><th>User</th><th class="r">Decks</th><th class="r">Quizzes</th></tr></thead>
              <tbody>
              <?php foreach ($topLearners as $t): ?>
                <tr>
                  <td><?= e($t['username']) ?></td>
                  <td class="r"><?= (int)$t['decks'] ?></td>
                  <td class="r"><?= (int)$t['quizzes'] ?></td>
                </tr>
              <?php endforeach; ?>
              </tbody>
            </table>
          <?php endif; ?>
        </div>

        <div class="panel">
          <h3>Sign-ups</h3>
          <div class="bars" role="img" aria-label="Monthly sign-ups bar chart">
            <?php foreach ($signups as $ym => $n): ?>
              <div class="bar-col">
                <div class="bar-val"><?= $n ?></div>
                <div class="bar-track"><div class="bar" style="height: <?= max(2, round($n / $maxSignup * 100)) ?>%"></div></div>
                <div class="bar-lbl"><?= e(date('M', strtotime($ym . '-01'))) ?></div>
              </div>
            <?php endforeach; ?>
          </div>
        </div>
      </section>

      <!-- NEW: Activity over time + Active vs. inactive -->
      <section class="duo">
        <div class="panel">
          <div class="ph"><h3>Activity over time</h3><small>Quizzes taken per day &middot; last 30 days</small></div>
          <?php if (!$quizTime): ?>
            <p class="muted">No date column was found in <code>quiz_attempts</code>, so this chart can&rsquo;t be drawn.</p>
          <?php else: ?>
            <svg viewBox="0 0 <?= $cw ?> <?= $ch ?>" width="100%" role="img" aria-label="Quizzes taken per day, last 30 days">
              <?php foreach ([0, 1, 2, 3, 4] as $g): $gv = $chartMax / 4 * $g; ?>
                <line x1="<?= $cl ?>" x2="<?= $cw - $cr ?>" y1="<?= round($cy($gv), 1) ?>" y2="<?= round($cy($gv), 1) ?>" stroke="#e3e6ee"/>
                <text x="<?= $cl - 8 ?>" y="<?= round($cy($gv) + 4, 1) ?>" text-anchor="end" font-size="11" fill="#6b7280"><?= round($gv) ?></text>
              <?php endforeach; ?>
              <polygon points="<?= $areaPts ?>" fill="#4f6bed" opacity=".10"/>
              <polyline points="<?= $linePts ?>" fill="none" stroke="#4f6bed" stroke-width="2.5" stroke-linejoin="round"/>
              <circle cx="<?= round($cx(29), 1) ?>" cy="<?= round($cy($dayVals[29]), 1) ?>" r="4.5" fill="#4f6bed"/>
              <?php foreach ([0, 7, 14, 21, 29] as $i): ?>
                <text x="<?= round($cx($i), 1) ?>" y="<?= $ch - 8 ?>" text-anchor="<?= $i === 29 ? 'end' : 'middle' ?>" font-size="11" fill="#6b7280"><?= e(date('M j', strtotime($dayKeys[$i]))) ?></text>
              <?php endforeach; ?>
            </svg>
          <?php endif; ?>
        </div>

        <div class="panel">
          <div class="ph"><h3>Active vs. inactive users</h3><small>last 7 days</small></div>
          <?php if (!$quizTime || $donutTotal === 0): ?>
            <p class="muted">Not enough data yet.</p>
          <?php else:
              $offA = 0; $lenA = $circ * $activeN / $donutTotal;
              $offI = $lenA; $lenI = $circ * $inactiveN / $donutTotal;
              $offN = $lenA + $lenI; $lenN = $circ * $neverN / $donutTotal; ?>
            <div class="donutrow">
              <svg viewBox="0 0 140 140" width="140" height="140" role="img" aria-label="<?= $activePct ?>% of users active">
                <circle r="48" cx="70" cy="70" fill="none" stroke="#4f6bed" stroke-width="18" stroke-dasharray="<?= round($lenA, 1) ?> <?= round($circ, 1) ?>" stroke-dashoffset="<?= -round($offA, 1) ?>" transform="rotate(-90 70 70)"/>
                <circle r="48" cx="70" cy="70" fill="none" stroke="#f0b429" stroke-width="18" stroke-dasharray="<?= round($lenI, 1) ?> <?= round($circ, 1) ?>" stroke-dashoffset="<?= -round($offI, 1) ?>" transform="rotate(-90 70 70)"/>
                <circle r="48" cx="70" cy="70" fill="none" stroke="#c9ced9" stroke-width="18" stroke-dasharray="<?= round($lenN, 1) ?> <?= round($circ, 1) ?>" stroke-dashoffset="<?= -round($offN, 1) ?>" transform="rotate(-90 70 70)"/>
                <text x="70" y="68" text-anchor="middle" font-size="22" font-weight="700" fill="#1f2430"><?= $activePct ?>%</text>
                <text x="70" y="86" text-anchor="middle" font-size="11" fill="#6b7280">active</text>
              </svg>
              <div class="legend">
                <div><span class="dot" style="background:#4f6bed"></span>Active<b><?= $activeN ?></b></div>
                <div><span class="dot" style="background:#f0b429"></span>Inactive<b><?= $inactiveN ?></b></div>
                <div><span class="dot" style="background:#c9ced9"></span>Never took a quiz<b><?= $neverN ?></b></div>
              </div>
            </div>
            <p class="subtle center">&ldquo;Active&rdquo; = took a quiz in the last 7 days</p>
          <?php endif; ?>
        </div>
      </section>

      <!-- NEW: Recent activity + Admin activity log -->
      <section class="duo2">
        <div class="panel">
          <div class="ph"><h3>Recent activity</h3><small>newest first</small></div>
          <?php if (!$feed): ?>
            <p class="muted">Nothing yet.</p>
          <?php else: ?>
            <ul class="feed">
              <?php foreach ($feed as $f): ?>
                <li>
                  <?php if ($f['kind'] === 'quiz'): ?>
                    <span class="ico q">Q</span>
                    <div><b><?= e($f['who']) ?></b> took a quiz
                  <?php elseif ($f['kind'] === 'deck'): ?>
                    <span class="ico d">D</span>
                    <div><b><?= e($f['who']) ?></b> created the deck<?= $f['info'] !== '' ? ' &ldquo;' . e($f['info']) . '&rdquo;' : '' ?>
                  <?php else: ?>
                    <span class="ico">+</span>
                    <div><b><?= e($f['who']) ?></b> joined as a <?= e($f['info']) ?>
                  <?php endif; ?>
                    <div class="t"><?= e(time_ago((int)$f['secs'])) ?></div></div>
                </li>
              <?php endforeach; ?>
            </ul>
          <?php endif; ?>
        </div>

        <div class="panel" id="log">
          <div class="ph"><h3>Admin activity log</h3><small>who did what</small></div>
          <?php if (!$logs): ?>
            <p class="muted">No admin actions recorded yet.</p>
          <?php else: ?>
            <table class="mini">
              <thead><tr><th>When</th><th>Admin</th><th>Action</th></tr></thead>
              <tbody>
              <?php foreach ($logs as $l): ?>
                <tr>
                  <td><?= e(date('M j, H:i', (int)$l['ts'])) ?></td>
                  <td><?= e($l['admin_name']) ?></td>
                  <td><span class="act <?= logClass($l['action']) ?>"><?= e($l['action']) ?></span> <?= e($l['details']) ?></td>
                </tr>
              <?php endforeach; ?>
              </tbody>
            </table>
          <?php endif; ?>
        </div>
      </section>

      <!-- NEW: Announcements -->
      <section class="panel full" id="announcements">
        <div class="ph"><h3>Announcements</h3><small>shown to students on their dashboard</small></div>
        <form method="post" action="admin_dashboard.php">
          <input type="hidden" name="csrf" value="<?= e($_SESSION['csrf']) ?>">
          <input type="hidden" name="action" value="post_announcement">
          <textarea name="message" maxlength="500" required placeholder="Write an announcement for all students&hellip;"></textarea>
          <div class="row">
            <label class="pinlbl"><input type="checkbox" name="pin" value="1"> Pin to top</label>
            <button type="submit" class="post">Post announcement</button>
          </div>
        </form>
        <?php foreach ($announcements as $a): ?>
          <div class="ann">
            <div><?php if ($a['is_pinned']): ?><span class="pin">PINNED</span><?php endif; ?><?= e($a['message']) ?></div>
            <div class="t">
              Posted <?= e(date('M j, Y, g:i A', (int)$a['ts'])) ?> &middot;
              <form method="post" class="inline" onsubmit="return confirm('Delete this announcement?');">
                <input type="hidden" name="csrf" value="<?= e($_SESSION['csrf']) ?>">
                <input type="hidden" name="action" value="delete_announcement">
                <input type="hidden" name="announcement_id" value="<?= e($a['id']) ?>">
                <button type="submit" class="linkbtn">Delete</button>
              </form>
            </div>
          </div>
        <?php endforeach; ?>
        <?php if (!$announcements): ?><p class="muted" style="margin-top:12px">No announcements yet.</p><?php endif; ?>
      </section>

    <!-- Users -->
    <section class="panel users-card" id="users">
      <div class="users-head">
        <h3>Users <span class="count">(<?= (int)$matchCount ?>)</span></h3>
        <form method="get" action="admin_dashboard.php" class="search">
          <input type="search" name="q" value="<?= e($q) ?>" placeholder="Search username or email">
          <button type="submit">Search</button>
          <?php if ($q !== ''): ?><a href="admin_dashboard.php" class="clear">Clear</a><?php endif; ?>
        </form>
      </div>

      <div class="table-wrap">
        <table class="data">
          <thead>
            <tr>
              <th>User</th><th>Role</th><th>Joined</th>
              <th class="r">Decks</th><th class="r">Quizzes</th><th class="r">Actions</th>
            </tr>
          </thead>
          <tbody>
          <?php if (!$users): ?>
            <tr><td colspan="6" class="muted center">No users found.</td></tr>
          <?php endif; ?>
          <?php foreach ($users as $u):
              $isSelf = ((int)$u['user_id'] === $adminId); ?>
            <tr>
              <td>
                <div class="u-name"><?= e($u['username']) ?><?= $isSelf ? ' <span class="you">you</span>' : '' ?></div>
                <div class="u-mail"><?= e($u['email']) ?></div>
              </td>
              <td>
                <?php if ($isSelf): ?>
                  <span class="badge <?= $u['role'] === 'Admin' ? 'admin' : '' ?>"><?= e($u['role']) ?></span>
                <?php else: ?>
                  <form method="post" class="inline">
                    <input type="hidden" name="csrf" value="<?= e($_SESSION['csrf']) ?>">
                    <input type="hidden" name="action" value="set_role">
                    <input type="hidden" name="user_id" value="<?= (int)$u['user_id'] ?>">
                    <input type="hidden" name="q" value="<?= e($q) ?>">
                    <input type="hidden" name="page" value="<?= $page ?>">
                    <select name="role" aria-label="Role for <?= e($u['username']) ?>" onchange="this.form.submit()">
                      <?php
                        $opts = $roles;
                        if (!in_array($u['role'], $opts, true)) $opts[] = $u['role'];
                        foreach ($opts as $r): ?>
                        <option value="<?= e($r) ?>" <?= $r === $u['role'] ? 'selected' : '' ?> <?= in_array($r, $roles, true) ? '' : 'disabled' ?>><?= e($r) ?></option>
                      <?php endforeach; ?>
                    </select>
                  </form>
                <?php endif; ?>
              </td>
              <td><?= e(date('M j, Y', strtotime($u['created_at']))) ?></td>
              <td class="r"><?= (int)$u['decks'] ?></td>
              <td class="r"><?= (int)$u['quizzes'] ?></td>
              <td class="r">
                <?php if (!$isSelf): ?>
                  <form method="post" class="inline" onsubmit="return confirm('Delete <?= e(addslashes($u['username'])) ?>? This cannot be undone.');">
                    <input type="hidden" name="csrf" value="<?= e($_SESSION['csrf']) ?>">
                    <input type="hidden" name="action" value="delete_user">
                    <input type="hidden" name="user_id" value="<?= (int)$u['user_id'] ?>">
                    <input type="hidden" name="q" value="<?= e($q) ?>">
                    <input type="hidden" name="page" value="<?= $page ?>">
                    <button type="submit" class="btn-danger">Delete</button>
                  </form>
                <?php else: ?>
                  <span class="muted">&mdash;</span>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>

      <?php if ($pages > 1): ?>
        <nav class="pager" aria-label="Pagination">
          <?php if ($page > 1): ?><a href="<?= e(pageUrl($page - 1, $q)) ?>">&larr; Prev</a><?php endif; ?>
          <span>Page <?= $page ?> of <?= $pages ?></span>
          <?php if ($page < $pages): ?><a href="<?= e(pageUrl($page + 1, $q)) ?>">Next &rarr;</a><?php endif; ?>
        </nav>
      <?php endif; ?>
    </section>

    </div><!-- /.content -->
  </div>
</div>

<script>
  const menus = document.querySelectorAll('.menu');
  document.querySelectorAll('[data-toggle]').forEach(btn => {
    btn.addEventListener('click', e => {
      e.stopPropagation();
      const target = document.getElementById(btn.dataset.toggle);
      const wasOpen = target.classList.contains('open');
      menus.forEach(m => m.classList.remove('open'));
      if (!wasOpen) target.classList.add('open');
    });
  });
  document.addEventListener('click', e => {
    if (!e.target.closest('.menu')) menus.forEach(m => m.classList.remove('open'));
  });
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') menus.forEach(m => m.classList.remove('open'));
  });
</script>
<script>
  // If the browser restores this page from its back/forward cache, reload so the server re-checks the login
  window.addEventListener('pageshow', e => { if (e.persisted) location.reload(); });
</script>
</body>
</html>
