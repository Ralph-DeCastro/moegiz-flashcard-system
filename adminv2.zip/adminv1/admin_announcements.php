<?php
require __DIR__ . '/security.php';
require __DIR__ . '/db.php';
require __DIR__ . '/admin_helpers.php';
function e(string $s): string { return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }
if (empty($_SESSION['user_id'])) { header('Location: index.php'); exit; }
if (isset($_GET['logout'])) { do_logout(); header('Location: index.php'); exit; }
$adminId = (int)$_SESSION['user_id'];
$stmt = $db->prepare('SELECT username,email,role FROM users WHERE user_id=?');
$stmt->bind_param('i',$adminId); $stmt->execute(); $admin=$stmt->get_result()->fetch_assoc(); $stmt->close();
if (!$admin || $admin['role'] !== 'Admin') { http_response_code(403); exit('Admins only.'); }
$_SESSION['role']='Admin';
if (empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(32));
$flash='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
  if (!hash_equals($_SESSION['csrf'], $_POST['csrf'] ?? '')) { $flash='Invalid request. Please refresh and try again.'; }
  else {
    $action=$_POST['action'] ?? '';
    if ($action==='post_announcement') {
      $message=trim($_POST['message'] ?? '');
      if ($message==='') $flash='Please write an announcement.';
      elseif (strlen($message)>500) $flash='Announcement must be 500 characters or less.';
      else { add_announcement($adminId,$message,isset($_POST['pin'])); log_admin($adminId,$admin['username'],'Announcement','posted'); $flash='Announcement posted successfully.'; }
    } elseif ($action==='delete_announcement') {
      if (delete_announcement((string)($_POST['announcement_id'] ?? ''))) { log_admin($adminId,$admin['username'],'Announcement','deleted'); $flash='Announcement deleted.'; }
    } elseif ($action==='toggle_pin') {
      $id=(string)($_POST['announcement_id'] ?? '');
      $rows=store_read('announcements'); $found=false;
      foreach ($rows as &$row) if (($row['id'] ?? '')===$id) { $row['is_pinned']=empty($row['is_pinned'])?1:0; $found=true; }
      unset($row);
      if ($found) { store_update('announcements',fn($old)=>$rows); log_admin($adminId,$admin['username'],'Announcement','pin changed'); $flash='Pin setting updated.'; }
    }
  }
}
$announcements=list_announcements(100);
$newThisWeek=0; $nq=$db->query('SELECT COUNT(*) AS total FROM users WHERE created_at >= (NOW() - INTERVAL 7 DAY)'); if ($nq) { $newThisWeek=(int)$nq->fetch_assoc()['total']; $nq->free(); }
$initial=strtoupper(substr($admin['username'],0,1));
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>MoeGiz · Announcements</title><link rel="stylesheet" href="dashboard.css"><link rel="stylesheet" href="admin.css"></head><body>
<div class="layout"><aside class="sidebar"><h1 class="brand">Moe<span>Giz</span></h1><nav class="nav"><a href="admin_dashboard.php">Overview</a><a href="admin_users.php">Users</a><a class="active" href="admin_announcements.php">Announcements</a><a href="admin_activity_log.php">Activity log</a></nav><span class="role-pill">Admin</span></aside>
<main class="main"><header class="topbar topbar-right"><div></div><div class="actions">
<div class="dropdown"><button class="icon-btn" type="button" aria-label="Notifications" data-toggle="notif-menu"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.7 21a2 2 0 0 1-3.4 0"/></svg></button><div class="menu" id="notif-menu"><div class="empty"><?= $newThisWeek ?> new user<?= $newThisWeek === 1 ? '' : 's' ?> this week</div></div></div>
<div class="dropdown"><button class="icon-btn avatar" type="button" aria-label="Account menu" data-toggle="profile-menu"><?= e($initial) ?></button><div class="menu" id="profile-menu"><div class="who">Signed in as <strong><?= e($admin['username']) ?></strong><br><?= e($admin['email']) ?></div><hr><a href="admin_announcements.php?logout=1" class="logout">Logout</a></div></div>
</div></header>
<div class="content admin-page">
<?php if ($flash!==''): ?><div class="flash <?= str_contains($flash,'successfully')||str_contains($flash,'deleted')||str_contains($flash,'updated')?'ok':'error' ?>"><?= e($flash) ?></div><?php endif; ?>
<section class="panel announcement-compose"><div class="page-heading"><h2>New announcement</h2><span>shown to students on their home page</span></div>
<form method="post"><input type="hidden" name="csrf" value="<?= e($_SESSION['csrf']) ?>"><input type="hidden" name="action" value="post_announcement"><textarea name="message" maxlength="500" required placeholder="Write an announcement for all students..."></textarea><div class="compose-footer"><label class="pinlbl"><input type="checkbox" name="pin" value="1"> Pin to top</label><button type="submit" class="post">Post announcement</button></div></form></section>
<section class="panel announcement-list"><div class="page-heading"><h2>All announcements <span class="count">(<?= count($announcements) ?>)</span></h2><span>students see the top 3: pinned first, then newest</span></div>
<?php if (!$announcements): ?><p class="muted">No announcements yet.</p><?php endif; ?>
<?php foreach ($announcements as $a): ?><article class="announcement-item"><div class="announcement-message"><?php if (!empty($a['is_pinned'])): ?><span class="pin">PINNED</span><?php endif; ?><?= e($a['message'] ?? '') ?></div><div class="announcement-meta">Posted <?= e(date('M j, Y, g:i A',(int)($a['ts']??time()))) ?> · <span class="visible-label">visible to students</span> · <form method="post" class="inline"><input type="hidden" name="csrf" value="<?= e($_SESSION['csrf']) ?>"><input type="hidden" name="action" value="toggle_pin"><input type="hidden" name="announcement_id" value="<?= e($a['id'] ?? '') ?>"><button class="linkbtn blue-link" type="submit"><?= !empty($a['is_pinned'])?'Unpin':'Pin' ?></button></form> · <form method="post" class="inline" onsubmit="return confirm('Delete this announcement?')"><input type="hidden" name="csrf" value="<?= e($_SESSION['csrf']) ?>"><input type="hidden" name="action" value="delete_announcement"><input type="hidden" name="announcement_id" value="<?= e($a['id'] ?? '') ?>"><button class="linkbtn" type="submit">Delete</button></form></div></article><?php endforeach; ?>
</section></div></main></div>
<script>
const menus = document.querySelectorAll('.menu');
document.querySelectorAll('[data-toggle]').forEach(btn => btn.addEventListener('click', e => {
  e.stopPropagation(); const target=document.getElementById(btn.dataset.toggle); const wasOpen=target.classList.contains('open');
  menus.forEach(menu=>menu.classList.remove('open')); if(!wasOpen) target.classList.add('open');
}));
document.addEventListener('click', e=>{ if(!e.target.closest('.menu')) menus.forEach(menu=>menu.classList.remove('open')); });
document.addEventListener('keydown', e=>{ if(e.key==='Escape') menus.forEach(menu=>menu.classList.remove('open')); });
window.addEventListener('pageshow', e=>{ if(e.persisted) location.reload(); });
</script></body></html>