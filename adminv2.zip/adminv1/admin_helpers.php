<?php
// Helpers shared by the admin dashboard, login and student dashboard.
// Announcements and the admin activity log are kept in small JSON files inside ./data/
// so the database does not need any new tables.

const DATA_DIR = __DIR__ . '/data';

/** Make sure ./data exists and is blocked from direct web access (Apache). */
function data_dir(): string {
    if (!is_dir(DATA_DIR)) {
        @mkdir(DATA_DIR, 0775, true);
    }
    $ht = DATA_DIR . '/.htaccess';
    if (!is_file($ht)) {
        @file_put_contents($ht, "Require all denied\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n");
    }
    return DATA_DIR;
}

/** Read a JSON list file (returns [] if missing or broken). */
function store_read(string $name): array {
    $file = data_dir() . '/' . $name . '.json';
    if (!is_file($file)) return [];
    $data = json_decode((string)@file_get_contents($file), true);
    return is_array($data) ? $data : [];
}

/** Safely change a JSON list file: $change receives the current list and returns the new one. */
function store_update(string $name, callable $change): bool {
    $file = data_dir() . '/' . $name . '.json';
    $fh = @fopen($file, 'c+');
    if (!$fh) return false;
    flock($fh, LOCK_EX);
    $current = json_decode((string)stream_get_contents($fh), true);
    $new = $change(is_array($current) ? $current : []);
    ftruncate($fh, 0);
    rewind($fh);
    fwrite($fh, json_encode(array_values($new), JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    fflush($fh);
    flock($fh, LOCK_UN);
    fclose($fh);
    return true;
}

// ---------------- Admin activity log ----------------

/** Add one line to the admin activity log (keeps the newest 200). */
function log_admin(int $adminId, string $adminName, string $action, string $details = ''): void {
    store_update('admin_log', function (array $rows) use ($adminId, $adminName, $action, $details) {
        array_unshift($rows, [
            'admin_id'   => $adminId,
            'admin_name' => $adminName,
            'action'     => $action,
            'details'    => $details,
            'ts'         => time(),
        ]);
        return array_slice($rows, 0, 200);
    });
}

/** Newest-first log lines. */
function read_admin_log(int $limit = 8): array {
    return array_slice(store_read('admin_log'), 0, $limit);
}

// ---------------- Announcements ----------------

function add_announcement(int $adminId, string $message, bool $pinned): void {
    store_update('announcements', function (array $rows) use ($adminId, $message, $pinned) {
        array_unshift($rows, [
            'id'        => bin2hex(random_bytes(6)),
            'admin_id'  => $adminId,
            'message'   => $message,
            'is_pinned' => $pinned ? 1 : 0,
            'ts'        => time(),
        ]);
        return array_slice($rows, 0, 100);
    });
}

function delete_announcement(string $id): bool {
    $found = false;
    store_update('announcements', function (array $rows) use ($id, &$found) {
        $kept = array_filter($rows, function ($r) use ($id, &$found) {
            if (($r['id'] ?? '') === $id) { $found = true; return false; }
            return true;
        });
        return $kept;
    });
    return $found;
}

/** Pinned first, then newest. */
function list_announcements(int $limit = 5): array {
    $rows = store_read('announcements');
    usort($rows, function ($a, $b) {
        return [(int)($b['is_pinned'] ?? 0), (int)($b['ts'] ?? 0)] <=> [(int)($a['is_pinned'] ?? 0), (int)($a['ts'] ?? 0)];
    });
    return array_slice($rows, 0, $limit);
}

// ---------------- Misc ----------------

/** Return the first column in $candidates that really exists in $table, or null. */
function pick_column(mysqli $db, string $table, array $candidates): ?string {
    try {
        $res = $db->query("SHOW COLUMNS FROM `" . str_replace('`', '', $table) . "`");
    } catch (mysqli_sql_exception $e) {
        return null;
    }
    $cols = [];
    while ($r = $res->fetch_assoc()) {
        $cols[strtolower($r['Field'])] = $r['Field'];
    }
    foreach ($candidates as $c) {
        if (isset($cols[$c])) return $cols[$c];
    }
    return null;
}

function username_of(mysqli $db, int $userId): string {
    $stmt = $db->prepare('SELECT username FROM users WHERE user_id = ?');
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $row['username'] ?? ('#' . $userId);
}

/** "5 minutes ago" from a number of seconds. */
function time_ago(int $secs): string {
    if ($secs < 60)      return 'just now';
    if ($secs < 3600)    { $m = intdiv($secs, 60);    return $m . ' minute' . ($m === 1 ? '' : 's') . ' ago'; }
    if ($secs < 86400)   { $h = intdiv($secs, 3600);  return $h . ' hour'   . ($h === 1 ? '' : 's') . ' ago'; }
    if ($secs < 2592000) { $d = intdiv($secs, 86400); return $d . ' day'    . ($d === 1 ? '' : 's') . ' ago'; }
    return date('M j, Y', time() - $secs);
}
