<?php
require __DIR__ . '/security.php'; require __DIR__ . '/db.php'; require __DIR__ . '/admin_helpers.php';
function e(string $s): string { return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }
if (empty($_SESSION['user_id'])) { header('Location: index.php'); exit; }
if (isset($_GET['logout'])) { do_logout(); header('Location: index.php'); exit; }
$id=(int)$_SESSION['user_id']; $stmt=$db->prepare('SELECT username,email,role FROM users WHERE user_id=?'); $stmt->bind_param('i',$id); $stmt->execute(); $admin=$stmt->get_result()->fetch_assoc(); $stmt->close();
if (!$admin || $admin['role']!=='Admin') { http_response_code(403); exit('Admins only.'); }
$all=store_read('admin_log'); $q=trim($_GET['q']??''); $filter=$_GET['type']??'All';
if ($q!=='') $all=array_values(array_filter($all,fn($r)=>stripos(($r['admin_name']??'').' '.($r['details']??'').' '.($r['action']??''),$q)!==false));
if ($filter!=='All') $all=array_values(array_filter($all,fn($r)=>strcasecmp($r['action']??'',$filter)===0));
$counts=[]; foreach(store_read('admin_log') as $r) { $a=$r['action']??'Other'; $counts[$a]=($counts[$a]??0)+1; }
$total=count(store_read('admin_log')); $nq=$db->query('SELECT COUNT(*) AS total FROM users WHERE created_at >= (NOW() - INTERVAL 7 DAY)'); $newThisWeek=$nq?(int)$nq->fetch_assoc()['total']:0; if ($nq) $nq->free(); $initial=strtoupper(substr($admin['username'],0,1));
function action_class(string $a): string { return strtolower(preg_replace('/[^a-z]/i','',$a)); }
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>MoeGiz · Activity log</title><link rel="stylesheet" href="dashboard.css"><link rel="stylesheet" href="admin.css"></head><body><div class="layout"><aside class="sidebar"><h1 class="brand">Moe<span>Giz</span></h1><nav class="nav"><a href="admin_dashboard.php">Overview</a><a href="admin_users.php">Users</a><a href="admin_announcements.php">Announcements</a><a class="active" href="admin_activity_log.php">Activity log</a></nav><span class="role-pill">Admin</span></aside>
<main class="main"><header class="topbar topbar-right"><div></div><div class="actions">
<div class="dropdown"><button class="icon-btn" type="button" aria-label="Notifications" data-toggle="notif-menu"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.7 21a2 2 0 0 1-3.4 0"/></svg></button><div class="menu" id="notif-menu"><div class="empty"><?= $newThisWeek ?> new user<?= $newThisWeek === 1 ? '' : 's' ?> this week</div></div></div>
<div class="dropdown"><button class="icon-btn avatar" type="button" aria-label="Account menu" data-toggle="profile-menu"><?= e($initial) ?></button><div class="menu" id="profile-menu"><div class="who">Signed in as <strong><?= e($admin['username']) ?></strong><br><?= e($admin['email']) ?></div><hr><a href="admin_activity_log.php?logout=1" class="logout">Logout</a></div></div>
</div></header>
<div class="content admin-page"><section class="panel activity-panel"><div class="activity-heading"><div><h2>Admin activity log <span class="count">(<?= count($all) ?>)</span></h2><p>Who did what. The newest 200 entries are kept.</p></div><form method="get" class="activity-search"><input type="search" name="q" value="<?= e($q) ?>" placeholder="Search admin or details"><input type="hidden" name="type" value="<?= e($filter) ?>"><button type="submit">Search</button></form></div>
<div class="filter-pills"><?php foreach(['All','Announcement','Delete','Login','Role'] as $type): $n=$type==='All'?$total:($counts[$type]??0); ?><a class="<?= $filter===$type?'selected':'' ?>" href="?type=<?= urlencode($type) ?>&q=<?= urlencode($q) ?>"><?= e($type) ?> <span><?= $n ?></span></a><?php endforeach; ?></div>
<div class="activity-table-wrap"><table class="activity-table"><thead><tr><th>WHEN</th><th>ADMIN</th><th>ACTION</th><th>DETAILS</th></tr></thead><tbody>
<?php if (!$all): ?><tr><td colspan="4" class="muted">No activity found.</td></tr><?php endif; ?>
<?php foreach($all as $row): $ts=(int)($row['ts']??time()); $action=$row['action']??'Other'; ?><tr><td><div><?= e(date('M j, Y, g:i A',$ts)) ?></div><small><?= e(time_ago(max(0,time()-$ts))) ?></small></td><td><?= e($row['admin_name']??'admin') ?></td><td><span class="action-pill <?= e(action_class($action)) ?>"><?= e($action) ?></span></td><td><?= e($row['details']??'') ?></td></tr><?php endforeach; ?>
</tbody></table></div></section></div></main></div>
<script>
const menus = document.querySelectorAll('.menu');
document.querySelectorAll('[data-toggle]').forEach(btn => btn.addEventListener('click', e => {
  e.stopPropagation(); const target=document.getElementById(btn.dataset.toggle); const wasOpen=target.classList.contains('open');
  menus.forEach(menu=>menu.classList.remove('open')); if(!wasOpen) target.classList.add('open');
}));
document.addEventListener('click', e=>{ if(!e.target.closest('.menu')) menus.forEach(menu=>menu.classList.remove('open')); });
document.addEventListener('keydown', e=>{ if(e.key==='Escape') menus.forEach(menu=>menu.classList.remove('open')); });
window.addEventListener('pageshow', e=>{ if(e.persisted) location.reload(); });
</script></body></html>