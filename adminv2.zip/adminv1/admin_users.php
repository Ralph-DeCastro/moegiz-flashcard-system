<?php
require __DIR__ . '/security.php';
require __DIR__ . '/db.php';

function e(string $s): string {
    return htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
}

// Must be logged in
if (empty($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

// Logout
if (isset($_GET['logout'])) {
    do_logout();
    header('Location: index.php');
    exit;
}

// Admins only (role is re-checked against the database, not just the session)
$adminId = (int)$_SESSION['user_id'];
$stmt = $db->prepare('SELECT username, email, role FROM users WHERE user_id = ?');
$stmt->bind_param('i', $adminId);
$stmt->execute();
$admin = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$admin) { // account deleted while logged in
    do_logout();
    header('Location: index.php');
    exit;
}

if ($admin['role'] !== 'Admin') {
    http_response_code(403);
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Moegiz &middot; Access denied</title>
  <link rel="stylesheet" href="dashboard.css">
</head>
<body>
  <div class="denied">
    <h1>Admins only</h1>
    <p>This page is for administrator accounts.</p>
    <a href="dashboard.php">Go to student dashboard</a> &middot;
    <a href="admin_users.php?logout=1">Log out</a>
  </div>
</body>
</html>
    <?php
    exit;
}
$_SESSION['role'] = $admin['role'];

// ---------- Roles shown on this page (everything except Admin) ----------
$roleCounts = [];   // e.g. ['Student' => 12, 'Guest' => 3]
$res = $db->query("SELECT role, COUNT(*) AS n FROM users WHERE role <> 'Admin' GROUP BY role ORDER BY role");
while ($r = $res->fetch_assoc()) {
    $roleCounts[$r['role']] = (int)$r['n'];
}
$totalListed = array_sum($roleCounts);

// ---------- Filters (role + search) + pagination ----------
$q       = trim($_GET['q'] ?? '');
$role    = $_GET['role'] ?? '';
if (!isset($roleCounts[$role])) $role = '';        // ignore anything that isn't a listed role
$perPage = 15;
$page    = max(1, (int)($_GET['page'] ?? 1));

$where  = "WHERE u.role <> 'Admin'";
$params = [];
$types  = '';
if ($role !== '') {
    $where   .= ' AND u.role = ?';
    $params[] = $role;
    $types   .= 's';
}
if ($q !== '') {
    $where   .= ' AND (u.username LIKE ? OR u.email LIKE ?)';
    $like     = '%' . addcslashes($q, '%_\\') . '%';
    $params[] = $like;
    $params[] = $like;
    $types   .= 'ss';
}

$stmt = $db->prepare("SELECT COUNT(*) FROM users u $where");
if ($params) $stmt->bind_param($types, ...$params);
$stmt->execute();
$stmt->bind_result($matchCount);
$stmt->fetch();
$stmt->close();

$pages  = max(1, (int)ceil($matchCount / $perPage));
$page   = min($page, $pages);
$offset = ($page - 1) * $perPage;

$sql = "SELECT u.user_id, u.username, u.email, u.role, u.created_at,
               (SELECT COUNT(*) FROM decks d WHERE d.user_id = u.user_id)         AS decks,
               (SELECT COUNT(*) FROM quiz_attempts a WHERE a.user_id = u.user_id) AS quizzes
        FROM users u $where
        ORDER BY u.created_at DESC, u.user_id DESC
        LIMIT ? OFFSET ?";
$stmt = $db->prepare($sql);
$bindParams = array_merge($params, [$perPage, $offset]);
$stmt->bind_param($types . 'ii', ...$bindParams);
$stmt->execute();
$users = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$username = $admin['username'];
$initial  = mb_strtoupper(mb_substr($username, 0, 1));

function listUrl(array $over = []): string {
    global $q, $role, $page;
    $args = array_merge(['q' => $q, 'role' => $role, 'page' => $page], $over);
    return 'admin_users.php?' . http_build_query(array_filter($args, fn($v) => $v !== '' && $v !== null));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Moegiz &middot; Users</title>
  <link rel="stylesheet" href="dashboard.css">
  <link rel="stylesheet" href="admin.css">
</head>
<body>
<div class="layout">

  <!-- Sidebar -->
  <aside class="sidebar">
    <h1 class="brand">Moe<span>Giz</span></h1>
    <nav class="nav">
      <a href="admin_dashboard.php">Overview</a>
      <a href="admin_users.php" class="active">Users</a>
      <a href="admin_announcements.php">Announcements</a>
      <a href="admin_activity_log.php">Activity log</a>
    </nav>
    <span class="role-pill">Admin</span>
  </aside>

  <div class="main">

    <!-- Top bar -->
    <header class="topbar topbar-right">
      <div class="actions">
        <div class="dropdown">
          <button class="icon-btn avatar" type="button" aria-label="Account menu" data-toggle="profile-menu"><?= e($initial) ?></button>
          <div class="menu" id="profile-menu">
            <div class="who">Signed in as <strong><?= e($username) ?></strong><br><?= e($admin['email']) ?></div>
            <hr>
            <a href="admin_dashboard.php">Overview</a>
            <a href="admin_users.php?logout=1" class="logout">Logout</a>
          </div>
        </div>
      </div>
    </header>

    <div class="content">

      <section class="panel users-card users-wide">
        <div class="users-head">
          <div>
            <h3>Users <span class="count">(<?= (int)$matchCount ?>)</span></h3>
            <p class="subtle">Students and guests. Admin accounts are not listed.</p>
          </div>
          <form method="get" action="admin_users.php" class="search">
            <?php if ($role !== ''): ?><input type="hidden" name="role" value="<?= e($role) ?>"><?php endif; ?>
            <input type="search" name="q" value="<?= e($q) ?>" placeholder="Search username or email">
            <button type="submit">Search</button>
            <?php if ($q !== ''): ?><a href="<?= e(listUrl(['q' => '', 'page' => ''])) ?>" class="clear">Clear</a><?php endif; ?>
          </form>
        </div>

        <!-- Role filter chips -->
        <nav class="chips" aria-label="Filter by role">
          <a href="<?= e(listUrl(['role' => '', 'page' => ''])) ?>" class="chip <?= $role === '' ? 'on' : '' ?>">All <span><?= $totalListed ?></span></a>
          <?php foreach ($roleCounts as $r => $n): ?>
            <a href="<?= e(listUrl(['role' => $r, 'page' => ''])) ?>" class="chip <?= $role === $r ? 'on' : '' ?>"><?= e($r) ?> <span><?= $n ?></span></a>
          <?php endforeach; ?>
        </nav>

        <div class="table-wrap">
          <table class="data">
            <thead>
              <tr>
                <th>User</th><th>Role</th><th>Joined</th>
                <th class="r">Decks</th><th class="r">Quizzes</th>
              </tr>
            </thead>
            <tbody>
            <?php if (!$users): ?>
              <tr><td colspan="5" class="muted center">No users found.</td></tr>
            <?php endif; ?>
            <?php foreach ($users as $u): ?>
              <tr>
                <td>
                  <div class="u-name"><?= e($u['username']) ?></div>
                  <div class="u-mail"><?= e($u['email']) ?></div>
                </td>
                <td><span class="badge <?= strtolower($u['role']) === 'student' ? 'student' : 'guest' ?>"><?= e($u['role']) ?></span></td>
                <td><?= e(date('M j, Y', strtotime($u['created_at']))) ?></td>
                <td class="r"><?= (int)$u['decks'] ?></td>
                <td class="r"><?= (int)$u['quizzes'] ?></td>
              </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
        </div>

        <?php if ($pages > 1): ?>
          <nav class="pager" aria-label="Pagination">
            <?php if ($page > 1): ?><a href="<?= e(listUrl(['page' => $page - 1])) ?>">&larr; Prev</a><?php endif; ?>
            <span>Page <?= $page ?> of <?= $pages ?></span>
            <?php if ($page < $pages): ?><a href="<?= e(listUrl(['page' => $page + 1])) ?>">Next &rarr;</a><?php endif; ?>
          </nav>
        <?php endif; ?>
      </section>

    </div>
  </div>
</div>

<script>
  const menus = document.querySelectorAll('.menu');
  document.querySelectorAll('[data-toggle]').forEach(btn => {
    btn.addEventListener('click', e => {
      e.stopPropagation();
      const target = document.getElementById(btn.dataset.toggle);
      const wasOpen = target.classList.contains('open');
      menus.forEach(m => m.classList.remove('open'));
      if (!wasOpen) target.classList.add('open');
    });
  });
  document.addEventListener('click', e => {
    if (!e.target.closest('.menu')) menus.forEach(m => m.classList.remove('open'));
  });
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') menus.forEach(m => m.classList.remove('open'));
  });
  // Reload if restored from the back/forward cache so the server re-checks the login
  window.addEventListener('pageshow', e => { if (e.persisted) location.reload(); });
</script>
</body>
</html>
