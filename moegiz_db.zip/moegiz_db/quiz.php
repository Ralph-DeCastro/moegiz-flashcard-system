<?php
require __DIR__ . '/student_init.php';
$user = require_student($db);
$uid  = (int)$user['user_id'];

$attempts = fetch_all($db, 'SELECT q.attempt_id, q.quiz_mode, q.quiz_score, q.correct_answers, q.total_questions,
        q.game_points, q.completion_time_seconds, q.created_at, q.deck_id,
        u.user_id, u.username, d.name AS deck_name
    FROM quiz_attempts q
    JOIN users u ON u.user_id = q.user_id
    LEFT JOIN decks d ON d.deck_id = q.deck_id
    WHERE q.user_id = ?
    ORDER BY q.created_at DESC, q.attempt_id DESC LIMIT 20', 'i', [$uid]);

student_header('Quiz', 'quiz', $user);
?>
    <div class="page-head">
      <h2 class="page-title">Quiz</h2>
    </div>

    <section class="panel soon">
      <h3>Quizzes are coming soon</h3>
      <p>Soon you'll be able to pick a deck and test yourself here.</p>
      <a class="btn ghost" href="create_flashcard.php">Create flashcards meanwhile</a>
    </section>

    <section class="panel">
      <h3>Your recent attempts <span class="count"><?= count($attempts) ?></span></h3>
      <?php
      // render_attempts() lives in the admin layout, so show a compact version here
      if (!$attempts): ?>
        <p class="empty">No quiz attempts yet.</p>
      <?php else: ?>
        <div class="table-wrap">
          <table class="data">
            <thead><tr><th>Deck</th><th>Mode</th><th>Score</th><th>Correct</th><th>Time</th><th>Taken</th></tr></thead>
            <tbody>
            <?php foreach ($attempts as $r): ?>
              <tr>
                <td><?= $r['deck_name'] !== null ? '<a class="link" href="deck.php?id=' . (int)$r['deck_id'] . '">' . e($r['deck_name']) . '</a>' : '<span class="muted">(deleted deck)</span>' ?></td>
                <td><span class="badge <?= $r['quiz_mode'] === 'Gamified' ? 'badge-game' : 'badge-plain' ?>"><?= e($r['quiz_mode']) ?></span></td>
                <td><?= (int)$r['quiz_score'] ?></td>
                <td><?= (int)$r['correct_answers'] ?>/<?= (int)$r['total_questions'] ?></td>
                <td><?= e(fmt_time((int)$r['completion_time_seconds'])) ?></td>
                <td class="nowrap"><?= e(fmt_date($r['created_at'])) ?></td>
              </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </section>
<?php student_footer(); ?>
