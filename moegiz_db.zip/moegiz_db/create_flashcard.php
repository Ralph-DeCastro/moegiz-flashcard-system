<?php
require __DIR__ . '/student_init.php';
$user = require_student($db);
$uid  = (int)$user['user_id'];

$errors = [];

$subjects = fetch_all($db, 'SELECT subject_id, name FROM subjects ORDER BY name');
$topics   = fetch_all($db, 'SELECT topic_id, subject_id, name FROM topics ORDER BY name');
$myDecks  = fetch_all($db, 'SELECT deck_id, name,
        (SELECT COUNT(*) FROM deck_flashcards df WHERE df.deck_id = decks.deck_id) AS cards
    FROM decks WHERE user_id = ? ORDER BY name', 'i', [$uid]);
$myDeckIds = array_map(fn($d) => (int)$d['deck_id'], $myDecks);

// Form values (defaults, or repopulated after an error)
$form = [
    'subject'     => '',   // subject_id or 'new'
    'new_subject' => '',
    'topic'       => '',   // topic_id or 'new'
    'new_topic'   => '',
    'question'    => '',
    'answer'      => '',
    'hint'        => '',
    'decks'       => [],
];

// After a successful save we come back here with the same subject/topic preselected
$created = isset($_GET['created']);
if ($created) {
    $form['subject'] = (string)(int)($_GET['subject'] ?? 0);
    $form['topic']   = (string)(int)($_GET['topic'] ?? 0);
    $form['decks']   = array_values(array_intersect(array_map('intval', (array)($_GET['d'] ?? [])), $myDeckIds));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $form['subject']     = (string)($_POST['subject'] ?? '');
    $form['new_subject'] = trim($_POST['new_subject'] ?? '');
    $form['topic']       = (string)($_POST['topic'] ?? '');
    $form['new_topic']   = trim($_POST['new_topic'] ?? '');
    $form['question']    = trim($_POST['question'] ?? '');
    $form['answer']      = trim($_POST['answer'] ?? '');
    $form['hint']        = trim($_POST['hint'] ?? '');
    $postedDecks         = array_map('intval', (array)($_POST['decks'] ?? []));
    // Only decks that belong to this student are allowed
    $form['decks']       = array_values(array_unique(array_intersect($postedDecks, $myDeckIds)));

    if (!csrf_ok()) {
        $errors[] = 'Invalid request. Please refresh and try again.';
    } else {
        $newSubject = ($form['subject'] === 'new');
        $newTopic   = ($form['topic'] === 'new') || $newSubject;

        // ---- Validate subject ----
        $subjectId = 0;
        if ($newSubject) {
            $len = mb_strlen($form['new_subject']);
            if ($len < 1 || $len > 100) {
                $errors[] = 'Enter a subject name (up to 100 characters).';
            }
        } else {
            $subjectId = (int)$form['subject'];
            if (!fetch_one($db, 'SELECT 1 FROM subjects WHERE subject_id = ?', 'i', [$subjectId])) {
                $errors[] = 'Please choose a subject.';
            }
        }

        // ---- Validate topic ----
        $topicId = 0;
        if ($newTopic) {
            $len = mb_strlen($form['new_topic']);
            if ($len < 1 || $len > 100) {
                $errors[] = 'Enter a topic name (up to 100 characters).';
            }
        } else {
            $topicId = (int)$form['topic'];
            if ($subjectId > 0 && !fetch_one($db, 'SELECT 1 FROM topics WHERE topic_id = ? AND subject_id = ?', 'ii', [$topicId, $subjectId])) {
                $errors[] = 'Please choose a topic from the selected subject.';
            }
        }

        // ---- Validate card text ----
        $qLen = mb_strlen($form['question']);
        $aLen = mb_strlen($form['answer']);
        if ($qLen < 1 || $qLen > 255) $errors[] = 'The question is required (up to 255 characters).';
        if ($aLen < 1 || $aLen > 255) $errors[] = 'The answer is required (up to 255 characters).';
        if (mb_strlen($form['hint']) > 255) $errors[] = 'The hint can be up to 255 characters.';

        // ---- Save ----
        if (!$errors) {
            try {
                $db->begin_transaction();

                if ($newSubject) {
                    $row = fetch_one($db, 'SELECT subject_id FROM subjects WHERE name = ?', 's', [$form['new_subject']]);
                    if ($row) {
                        $subjectId = (int)$row['subject_id'];
                    } else {
                        $stmt = $db->prepare('INSERT INTO subjects (name) VALUES (?)');
                        $stmt->bind_param('s', $form['new_subject']);
                        $stmt->execute();
                        $subjectId = (int)$db->insert_id;
                        $stmt->close();
                    }
                }

                if ($newTopic) {
                    $row = fetch_one($db, 'SELECT topic_id FROM topics WHERE subject_id = ? AND name = ?', 'is', [$subjectId, $form['new_topic']]);
                    if ($row) {
                        $topicId = (int)$row['topic_id'];
                    } else {
                        $stmt = $db->prepare('INSERT INTO topics (subject_id, name) VALUES (?, ?)');
                        $stmt->bind_param('is', $subjectId, $form['new_topic']);
                        $stmt->execute();
                        $topicId = (int)$db->insert_id;
                        $stmt->close();
                    }
                }

                $hint = ($form['hint'] === '') ? null : $form['hint'];
                $stmt = $db->prepare('INSERT INTO flashcards (topic_id, created_by, question_text, answer_text, hint_text) VALUES (?, ?, ?, ?, ?)');
                $stmt->bind_param('iisss', $topicId, $uid, $form['question'], $form['answer'], $hint);
                $stmt->execute();
                $cardId = (int)$db->insert_id;
                $stmt->close();

                foreach ($form['decks'] as $deckId) {
                    $next = fetch_one($db, 'SELECT COALESCE(MAX(display_order), 0) + 1 AS n FROM deck_flashcards WHERE deck_id = ?', 'i', [$deckId]);
                    $order = min(65535, (int)$next['n']); // display_order is SMALLINT UNSIGNED
                    $stmt = $db->prepare('INSERT INTO deck_flashcards (deck_id, flashcard_id, display_order) VALUES (?, ?, ?)');
                    $stmt->bind_param('iii', $deckId, $cardId, $order);
                    $stmt->execute();
                    $stmt->close();
                }

                $db->commit();

                $qs = http_build_query(['created' => 1, 'subject' => $subjectId, 'topic' => $topicId, 'd' => $form['decks']]);
                header('Location: create_flashcard.php?' . $qs);
                exit;
            } catch (mysqli_sql_exception $ex) {
                $db->rollback();
                $errors[] = 'Could not save the flashcard. Please try again.';
            }
        }
    }
}

student_header('Create flashcard', 'flashcards', $user);
?>
    <div class="page-head">
      <div>
        <div class="crumb"><a class="link" href="flashcards.php">&larr; My flashcards</a></div>
        <h2 class="page-title">Create flashcard</h2>
      </div>
    </div>

    <?php if ($created): ?>
      <div class="notice ok">Flashcard saved! Add another below, or <a class="link" href="flashcards.php">view all your flashcards</a>.</div>
    <?php endif; ?>
    <?php if ($errors): ?>
      <div class="notice error">
        <?php foreach ($errors as $err): ?><div><?= e($err) ?></div><?php endforeach; ?>
      </div>
    <?php endif; ?>

    <section class="panel">
      <form class="form" method="post" action="create_flashcard.php" id="fc-form">
        <?= csrf_field() ?>

        <div class="row">
          <div>
            <label for="subject">Subject</label>
            <select id="subject" name="subject" required>
              <option value="">Choose a subject…</option>
              <?php foreach ($subjects as $s): ?>
                <option value="<?= (int)$s['subject_id'] ?>" <?= $form['subject'] === (string)$s['subject_id'] ? 'selected' : '' ?>><?= e($s['name']) ?></option>
              <?php endforeach; ?>
              <option value="new" <?= $form['subject'] === 'new' ? 'selected' : '' ?>>+ New subject…</option>
            </select>
            <input type="text" id="new_subject" name="new_subject" value="<?= e($form['new_subject']) ?>"
                   maxlength="100" placeholder="New subject name" class="hidden" style="margin-top:8px">
          </div>
          <div>
            <label for="topic">Topic</label>
            <select id="topic" name="topic" required data-selected="<?= e($form['topic']) ?>">
              <option value="">Choose a topic…</option>
            </select>
            <input type="text" id="new_topic" name="new_topic" value="<?= e($form['new_topic']) ?>"
                   maxlength="100" placeholder="New topic name" class="hidden" style="margin-top:8px">
          </div>
        </div>

        <label for="question">Question</label>
        <textarea id="question" name="question" maxlength="255" required placeholder="e.g. What is the powerhouse of the cell?"><?= e($form['question']) ?></textarea>

        <label for="answer">Answer</label>
        <textarea id="answer" name="answer" maxlength="255" required placeholder="e.g. The mitochondria"><?= e($form['answer']) ?></textarea>

        <label for="hint">Hint <span class="opt">(optional)</span></label>
        <input type="text" id="hint" name="hint" maxlength="255" value="<?= e($form['hint']) ?>" placeholder="A small clue to jog your memory">

        <label>Add to deck <span class="opt">(optional)</span></label>
        <?php if (!$myDecks): ?>
          <p class="hint">You don't have any decks yet. Deck creation is coming soon; flashcards you make now can be added to decks later.</p>
        <?php else: ?>
          <div class="checks">
            <?php foreach ($myDecks as $d): ?>
              <label class="check">
                <input type="checkbox" name="decks[]" value="<?= (int)$d['deck_id'] ?>" <?= in_array((int)$d['deck_id'], $form['decks'], true) ? 'checked' : '' ?>>
                <?= e($d['name']) ?>
                <span class="muted"><?= (int)$d['cards'] ?> cards</span>
              </label>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>

        <div class="actions-row">
          <button class="btn" type="submit">Save flashcard</button>
          <a class="btn ghost" href="flashcards.php">Cancel</a>
        </div>
      </form>
    </section>

<script>
  // Topics grouped by subject, for the dependent dropdown
  const TOPICS = <?= json_encode(array_map(fn($t) => ['id' => (int)$t['topic_id'], 'subject' => (int)$t['subject_id'], 'name' => $t['name']], $topics), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;

  const subjectSel = document.getElementById('subject');
  const topicSel   = document.getElementById('topic');
  const newSubject = document.getElementById('new_subject');
  const newTopic   = document.getElementById('new_topic');

  function option(value, text) {
    const o = document.createElement('option');
    o.value = value;
    o.textContent = text;
    return o;
  }

  function refresh(keepTopic) {
    const subj = subjectSel.value;
    const isNewSubject = (subj === 'new');

    newSubject.classList.toggle('hidden', !isNewSubject);
    newSubject.required = isNewSubject;

    // Rebuild the topic list for the chosen subject
    topicSel.innerHTML = '';
    topicSel.appendChild(option('', subj === '' ? 'Choose a subject first…' : 'Choose a topic…'));
    if (subj !== '' && !isNewSubject) {
      TOPICS.filter(t => String(t.subject) === subj).forEach(t => topicSel.appendChild(option(String(t.id), t.name)));
    }
    topicSel.appendChild(option('new', '+ New topic…'));

    if (isNewSubject) {
      // A brand-new subject can only have a brand-new topic
      topicSel.value = 'new';
      topicSel.disabled = true;
    } else {
      topicSel.disabled = false;
      if (keepTopic && [...topicSel.options].some(o => o.value === keepTopic)) {
        topicSel.value = keepTopic;
      }
    }

    const isNewTopic = (topicSel.value === 'new');
    newTopic.classList.toggle('hidden', !isNewTopic);
    newTopic.required = isNewTopic;
  }

  subjectSel.addEventListener('change', () => refresh(''));
  topicSel.addEventListener('change', () => refresh(topicSel.value));

  // A disabled select isn't submitted, so make sure 'new' still goes through
  document.getElementById('fc-form').addEventListener('submit', () => { topicSel.disabled = false; });

  refresh(topicSel.dataset.selected || '');
</script>
<?php student_footer(); ?>
