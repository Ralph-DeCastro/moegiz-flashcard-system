<?php
require __DIR__ . '/student_init.php';
$user = require_student($db);

$q = trim($_GET['q'] ?? '');
$where  = 'd.is_public = 1';
$types  = '';
$params = [];
if ($q !== '') {
    $where .= ' AND (d.name LIKE ? OR u.username LIKE ?)';
    $like = '%' . $q . '%';
    $types = 'ss';
    $params = [$like, $like];
}

$decks = fetch_all($db, 'SELECT d.deck_id, d.name, d.is_public, d.created_at, u.username,
        (SELECT COUNT(*) FROM deck_flashcards df WHERE df.deck_id = d.deck_id) AS cards
    FROM decks d JOIN users u ON u.user_id = d.user_id
    WHERE ' . $where . ' ORDER BY d.created_at DESC, d.deck_id DESC LIMIT 100', $types, $params);

student_header('Public decks', 'public', $user);
?>
    <div class="page-head">
      <h2 class="page-title">Public decks</h2>
    </div>

    <form class="toolbar" method="get" action="public_decks.php">
      <input type="text" name="q" value="<?= e($q) ?>" placeholder="Search deck name or owner">
      <button class="btn" type="submit">Search</button>
      <?php if ($q !== ''): ?><a class="btn ghost" href="public_decks.php">Clear</a><?php endif; ?>
    </form>

    <section class="panel">
      <h3>Shared by students <span class="count"><?= count($decks) ?></span></h3>
      <?php if (!$decks): ?>
        <p class="empty"><?= $q !== '' ? 'No public decks match your search.' : 'No public decks yet.' ?></p>
      <?php else: ?>
        <?php render_deck_table($decks, true); ?>
      <?php endif; ?>
    </section>
<?php student_footer(); ?>
