<?php
require __DIR__ . '/student_init.php';
$user = require_student($db);
$uid  = (int)$user['user_id'];
$id   = (int)($_GET['id'] ?? 0);

// Visible if it's yours or it's public
$deck = fetch_one($db, 'SELECT d.deck_id, d.name, d.is_public, d.user_id, d.created_at, u.username
    FROM decks d JOIN users u ON u.user_id = d.user_id
    WHERE d.deck_id = ? AND (d.user_id = ? OR d.is_public = 1)', 'ii', [$id, $uid]);

if (!$deck) {
    http_response_code(404);
    student_header('Deck not found', 'decks', $user);
    echo '<div class="panel"><p class="empty">Deck not found, or it is private.</p>'
       . '<a class="link" href="my_decks.php">&larr; My decks</a> &middot; <a class="link" href="public_decks.php">Public decks</a></div>';
    student_footer();
    exit;
}

$mine = ((int)$deck['user_id'] === $uid);

$cards = fetch_all($db, 'SELECT f.question_text, f.answer_text, f.hint_text, t.name AS topic, s.name AS subject
    FROM deck_flashcards df
    JOIN flashcards f ON f.flashcard_id = df.flashcard_id
    JOIN topics t ON t.topic_id = f.topic_id
    JOIN subjects s ON s.subject_id = t.subject_id
    WHERE df.deck_id = ?
    ORDER BY df.display_order, f.flashcard_id', 'i', [$id]);

student_header($deck['name'], $mine ? 'decks' : 'public', $user);
?>
    <div class="page-head">
      <div>
        <div class="crumb">
          <?php if ($mine): ?><a class="link" href="my_decks.php">&larr; My decks</a>
          <?php else: ?><a class="link" href="public_decks.php">&larr; Public decks</a><?php endif; ?>
        </div>
        <h2 class="page-title"><?= e($deck['name']) ?></h2>
      </div>
    </div>

    <section class="panel">
      <p style="margin:0 0 6px">
        By <strong><?= e($mine ? 'you' : $deck['username']) ?></strong>
        &middot; <span class="badge <?= $deck['is_public'] ? 'badge-public' : 'badge-private' ?>"><?= $deck['is_public'] ? 'Public' : 'Private' ?></span>
      </p>
      <p class="muted" style="margin:0">Created <?= e(fmt_date($deck['created_at'])) ?></p>
    </section>

    <section class="panel">
      <h3>Flashcards <span class="count"><?= count($cards) ?></span></h3>
      <?php if (!$cards): ?>
        <p class="empty">This deck has no flashcards yet.<?= $mine ? ' <a class="link" href="create_flashcard.php">Create one</a>.' : '' ?></p>
      <?php else: ?>
        <div class="fc-list">
          <?php foreach ($cards as $i => $f): ?>
            <div class="fc">
              <div class="meta">#<?= $i + 1 ?> &middot; <?= e($f['subject']) ?> &rsaquo; <?= e($f['topic']) ?></div>
              <div class="q">Q: <?= e($f['question_text']) ?></div>
              <div class="a">A: <?= e($f['answer_text']) ?></div>
              <?php if ($f['hint_text'] !== null && $f['hint_text'] !== ''): ?>
                <div class="h">Hint: <?= e($f['hint_text']) ?></div>
              <?php endif; ?>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </section>
<?php student_footer(); ?>
