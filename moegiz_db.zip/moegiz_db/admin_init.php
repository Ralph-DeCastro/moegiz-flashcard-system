<?php
// Shared bootstrap + layout for all admin pages.
require __DIR__ . '/common.php';

/**
 * Only Admin accounts may pass. The role is re-checked in the database on
 * every request, so a demoted or deleted account loses access immediately.
 */
function require_admin(mysqli $db): array {
    $admin = current_user($db);
    if ($admin['role'] !== 'Admin') {
        access_denied('Admins only', "You don't have permission to view this page.", 'dashboard.php', 'Go to my dashboard');
    }
    return $admin;
}

// Reusable quiz attempts table
function render_attempts(array $rows, bool $showUser = true, bool $showDeck = true): void {
    if (!$rows) {
        echo '<p class="empty">No quiz attempts yet.</p>';
        return;
    }
    ?>
    <div class="table-wrap">
      <table class="data">
        <thead>
          <tr>
            <?php if ($showUser): ?><th>Student</th><?php endif; ?>
            <?php if ($showDeck): ?><th>Deck</th><?php endif; ?>
            <th>Mode</th><th>Score</th><th>Correct</th><th>Points</th><th>Time</th><th>Taken</th>
          </tr>
        </thead>
        <tbody>
        <?php foreach ($rows as $r): ?>
          <tr>
            <?php if ($showUser): ?>
              <td><a class="link" href="admin_user.php?id=<?= (int)$r['user_id'] ?>"><?= e($r['username']) ?></a></td>
            <?php endif; ?>
            <?php if ($showDeck): ?>
              <td>
                <?php if ($r['deck_id'] !== null && $r['deck_name'] !== null): ?>
                  <a class="link" href="admin_deck.php?id=<?= (int)$r['deck_id'] ?>"><?= e($r['deck_name']) ?></a>
                <?php else: ?>
                  <span class="muted">(deleted deck)</span>
                <?php endif; ?>
              </td>
            <?php endif; ?>
            <td><span class="badge <?= $r['quiz_mode'] === 'Gamified' ? 'badge-game' : 'badge-plain' ?>"><?= e($r['quiz_mode']) ?></span></td>
            <td><?= (int)$r['quiz_score'] ?></td>
            <td><?= (int)$r['correct_answers'] ?>/<?= (int)$r['total_questions'] ?></td>
            <td><?= $r['quiz_mode'] === 'Gamified' ? (int)$r['game_points'] : '<span class="muted">—</span>' ?></td>
            <td><?= e(fmt_time((int)$r['completion_time_seconds'])) ?></td>
            <td class="nowrap"><?= e(fmt_date($r['created_at'])) ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php
}

// Page chrome
function admin_header(string $title, string $active, array $admin): void {
    $nav = [
        'overview' => ['admin.php', 'Overview'],
        'users'    => ['admin_users.php', 'Users'],
        'decks'    => ['admin_decks.php', 'Decks'],
        'flashcards' => ['admin_flashcards.php', 'Flashcards'],
        'quizzes'  => ['admin_quizzes.php', 'Quiz attempts'],
    ];
    $initial = mb_strtoupper(mb_substr($admin['username'], 0, 1));
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Moegiz Admin &middot; <?= e($title) ?></title>
  <link rel="stylesheet" href="dashboard.css">
  <link rel="stylesheet" href="admin.css">
</head>
<body>
<div class="layout">
  <aside class="sidebar">
    <h1 class="brand"><a href="admin.php">Moe<span>Giz</span></a> <small class="tag">Admin</small></h1>
    <nav class="nav">
      <?php foreach ($nav as $key => [$href, $label]): ?>
        <a href="<?= e($href) ?>" class="<?= $key === $active ? 'active' : '' ?>"><?= e($label) ?></a>
      <?php endforeach; ?>
    </nav>
  </aside>

  <div class="main">
    <header class="topbar">
      <div class="user-info">
        <span class="avatar"><?= e($initial) ?></span>
        <div class="meta">
          <div class="name"><?= e($admin['username']) ?></div>
          <div class="sub">Administrator &middot; <?= e($admin['email']) ?></div>
        </div>
      </div>
      <div class="actions">
        <div class="dropdown">
          <button class="icon-btn avatar" type="button" aria-label="Account menu" data-toggle="profile-menu"><?= e($initial) ?></button>
          <div class="menu" id="profile-menu">
            <div class="who">Signed in as <strong><?= e($admin['username']) ?></strong></div>
            <hr>
            <a href="admin.php?logout=1" class="logout">Logout</a>
          </div>
        </div>
      </div>
    </header>
    <?php
}

function admin_footer(): void {
    ?>
  </div>
</div>
<script>
  const menus = document.querySelectorAll('.menu');
  document.querySelectorAll('[data-toggle]').forEach(btn => {
    btn.addEventListener('click', e => {
      e.stopPropagation();
      const target = document.getElementById(btn.dataset.toggle);
      const wasOpen = target.classList.contains('open');
      menus.forEach(m => m.classList.remove('open'));
      if (!wasOpen) target.classList.add('open');
    });
  });
  document.addEventListener('click', e => {
    if (!e.target.closest('.menu')) menus.forEach(m => m.classList.remove('open'));
  });
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') menus.forEach(m => m.classList.remove('open'));
  });
</script>
</body>
</html>
    <?php
}
