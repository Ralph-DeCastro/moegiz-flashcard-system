<?php
require __DIR__ . '/student_init.php';
$user = require_student($db);
$uid  = (int)$user['user_id'];

$decks = fetch_all($db, 'SELECT d.deck_id, d.name, d.is_public, d.created_at,
        (SELECT COUNT(*) FROM deck_flashcards df WHERE df.deck_id = d.deck_id) AS cards
    FROM decks d WHERE d.user_id = ? ORDER BY d.created_at DESC, d.deck_id DESC', 'i', [$uid]);

student_header('My decks', 'decks', $user);
?>
    <div class="page-head">
      <h2 class="page-title">My decks</h2>
    </div>

    <section class="panel">
      <h3>Your decks <span class="count"><?= count($decks) ?></span></h3>
      <?php if (!$decks): ?>
        <p class="empty">You don't have any decks yet. Deck creation is coming soon. In the meantime you can
          <a class="link" href="create_flashcard.php">create flashcards</a>.</p>
      <?php else: ?>
        <?php render_deck_table($decks); ?>
      <?php endif; ?>
    </section>
<?php student_footer(); ?>
