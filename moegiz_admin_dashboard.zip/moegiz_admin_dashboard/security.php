<?php
// Shared security bootstrap. Include this instead of calling session_start().

// ---- Session hardening ----
ini_set('session.use_strict_mode', '1');   // reject unknown session IDs
ini_set('session.use_only_cookies', '1');  // never accept IDs from the URL
session_set_cookie_params([
    'lifetime' => 0,                        // cookie dies when the browser closes
    'path'     => '/',
    'httponly' => true,                     // JavaScript cannot read the cookie
    'samesite' => 'Lax',                    // blocks most cross-site request forgery
    'secure'   => !empty($_SERVER['HTTPS']), // HTTPS-only when the site uses HTTPS
]);
session_start();

// ---- Stop browsers caching pages (fixes back/forward showing a logged-out user the old page) ----
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');

// ---- Extra headers ----
header('X-Frame-Options: DENY');             // no clickjacking via iframes
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: same-origin');

// ---- Fully log out: clear data, delete the cookie, destroy the session ----
function do_logout(): void {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    session_destroy();
}

// ---- Auto logout after 30 minutes of inactivity ----
const SESSION_IDLE_LIMIT = 1800;
if (!empty($_SESSION['user_id'])) {
    if (isset($_SESSION['last_activity']) && time() - $_SESSION['last_activity'] > SESSION_IDLE_LIMIT) {
        do_logout();
        header('Location: index.php');
        exit;
    }
    $_SESSION['last_activity'] = time();
}
