<?php
require __DIR__ . '/student_init.php';
$user = require_student($db);
$uid  = (int)$user['user_id'];

// ---------------------------------------------------------------- leaderboard data
// One row per student who has taken at least one quiz (admins are never ranked).
$board = fetch_all($db, "SELECT u.user_id, u.username,
        COUNT(q.attempt_id)                  AS attempts,
        AVG(q.quiz_score)                    AS avg_score,
        MAX(q.quiz_score)                    AS best_score,
        COALESCE(SUM(q.correct_answers), 0)  AS correct,
        COALESCE(SUM(q.game_points), 0)      AS points
    FROM users u
    JOIN quiz_attempts q ON q.user_id = u.user_id
    WHERE u.role = 'Student'
    GROUP BY u.user_id, u.username");

/**
 * Competition ranking ("1, 2, 2, 4"): equal results share a rank.
 * $key is the main column; $tie lists tie-breakers (all higher = better).
 */
function assign_ranks(array &$rows, string $field, string $key, array $tie = []): void {
    usort($rows, function ($a, $b) use ($key, $tie) {
        foreach (array_merge([$key], $tie) as $k) {
            if ($a[$k] != $b[$k]) return $b[$k] <=> $a[$k];
        }
        return strcmp($a['username'], $b['username']);
    });
    $prev = null; $rank = 0;
    foreach ($rows as $i => &$r) {
        $sig = $r[$key] . '|' . implode('|', array_map(fn($k) => $r[$k], $tie));
        if ($sig !== $prev) { $rank = $i + 1; $prev = $sig; }
        $r[$field] = $rank;
    }
    unset($r);
}

foreach ($board as &$b) {
    $b['avg_score'] = round((float)$b['avg_score'], 1);
    $b['points']    = (int)$b['points'];
    $b['attempts']  = (int)$b['attempts'];
    $b['correct']   = (int)$b['correct'];
}
unset($b);

// Ranking by average score (ties: more correct answers, then more quizzes)
$byScore = $board;
assign_ranks($byScore, 'rank', 'avg_score', ['correct', 'attempts']);

// Ranking by game points (only students who have actually earned points)
$byPoints = array_values(array_filter($board, fn($r) => $r['points'] > 0));
assign_ranks($byPoints, 'rank', 'points', ['attempts']);

function find_me(array $rows, int $uid): ?array {
    foreach ($rows as $r) if ((int)$r['user_id'] === $uid) return $r;
    return null;
}
$meScore  = find_me($byScore, $uid);
$mePoints = find_me($byPoints, $uid);

// Which leaderboard is shown
$by    = (($_GET['by'] ?? '') === 'points') ? 'points' : 'score';
$rows  = $by === 'points' ? $byPoints : $byScore;
$me    = $by === 'points' ? $mePoints : $meScore;
$top   = array_slice($rows, 0, 10);
$meInTop = $me && $me['rank'] <= ($top ? end($top)['rank'] : 0) && in_array($uid, array_column($top, 'user_id'));

// ---------------------------------------------------------------- my own history
$history = fetch_all($db, 'SELECT q.attempt_id, q.quiz_score, q.correct_answers, q.total_questions,
        q.game_points, q.completion_time_seconds, q.quiz_mode, q.created_at, q.deck_id, d.name AS deck_name
    FROM quiz_attempts q LEFT JOIN decks d ON d.deck_id = q.deck_id
    WHERE q.user_id = ?
    ORDER BY q.created_at DESC, q.attempt_id DESC LIMIT 10', 'i', [$uid]);
$trend = array_reverse($history); // oldest -> newest for the bars

$totalStudents = count($byScore);
function ordinal_rank(?array $r, int $of): string {
    return $r ? '#' . (int)$r['rank'] . ' <span class="of">of ' . $of . '</span>' : '—';
}

student_header('Analytics', 'analytics', $user);
?>
    <h2 class="page-title">Analytics</h2>

<?php if (!$meScore): ?>
    <section class="panel">
      <p class="empty" style="text-align:center">You haven't taken a quiz yet. Finish one to see your scores and ranking here.</p>
      <p style="text-align:center;margin:10px 0 0"><a class="btn" href="quiz.php">Take a quiz</a></p>
    </section>
<?php else: ?>

    <section class="stat-grid stat-grid-3">
      <div class="tile rank-tile">
        <div class="num"><?= ordinal_rank($meScore, $totalStudents) ?></div>
        <div class="lbl">Score ranking</div>
      </div>
      <div class="tile rank-tile">
        <div class="num"><?= $mePoints ? ordinal_rank($mePoints, count($byPoints)) : '—' ?></div>
        <div class="lbl"><?= $mePoints ? 'Points ranking' : 'Points ranking (play Gamified)' ?></div>
      </div>
      <div class="tile"><div class="num"><?= e(rtrim(rtrim(number_format($meScore['avg_score'], 1), '0'), '.')) ?>%</div><div class="lbl">Average score</div></div>
      <div class="tile"><div class="num"><?= (int)$meScore['best_score'] ?>%</div><div class="lbl">Best score</div></div>
      <div class="tile"><div class="num"><?= (int)$meScore['attempts'] ?></div><div class="lbl">Quizzes taken</div></div>
      <div class="tile"><div class="num"><?= (int)$meScore['points'] ?></div><div class="lbl">Total points</div></div>
    </section>

    <section class="panel">
      <h3>Recent scores <span class="count">last <?= count($trend) ?> quizzes</span></h3>
      <div class="bars" role="img" aria-label="Scores of your last <?= count($trend) ?> quizzes">
        <?php foreach ($trend as $t): $s = (int)$t['quiz_score']; ?>
          <a class="bar-col" href="quiz_result.php?id=<?= (int)$t['attempt_id'] ?>"
             title="<?= e(($t['deck_name'] ?? '(deleted deck)') . ' · ' . $s . '% · ' . fmt_date($t['created_at'])) ?>">
            <span class="bar-val"><?= $s ?>%</span>
            <span class="bar-track"><span class="bar-fill <?= $t['quiz_mode'] === 'Gamified' ? 'game' : '' ?>" style="height:<?= max(2, $s) ?>%"></span></span>
          </a>
        <?php endforeach; ?>
      </div>
      <p class="muted legend"><span class="dot"></span> Standard &nbsp; <span class="dot game"></span> Gamified &middot; oldest to newest</p>
    </section>

    <section class="panel">
      <h3>
        Leaderboard
        <span class="seg">
          <a class="<?= $by === 'score' ? 'on' : '' ?>" href="analytics.php">Average score</a>
          <a class="<?= $by === 'points' ? 'on' : '' ?>" href="analytics.php?by=points">Game points</a>
        </span>
      </h3>

      <?php if (!$top): ?>
        <p class="empty">Nobody has earned game points yet. Play a quiz in Gamified mode to get on the board.</p>
      <?php else: ?>
      <div class="table-wrap">
        <table class="data">
          <thead>
            <tr>
              <th>Rank</th><th>Student</th>
              <th><?= $by === 'points' ? 'Points' : 'Avg score' ?></th>
              <th>Best</th>
              <th>Quizzes</th>
            </tr>
          </thead>
          <tbody>
          <?php
            $render = function (array $r) use ($by, $uid) {
                $mine = (int)$r['user_id'] === $uid;
                $medal = [1 => '🥇', 2 => '🥈', 3 => '🥉'][$r['rank']] ?? '';
                ?>
            <tr class="<?= $mine ? 'me' : '' ?>">
              <td class="nowrap"><strong>#<?= (int)$r['rank'] ?></strong> <?= $medal ?></td>
              <td><?= e($r['username']) ?><?= $mine ? ' <span class="badge badge-student">You</span>' : '' ?></td>
              <?php if ($by === 'points'): ?>
                <td><strong><?= (int)$r['points'] ?></strong></td>
                <td><?= (int)$r['best_score'] ?>%</td>
              <?php else: ?>
                <td><strong><?= e(rtrim(rtrim(number_format($r['avg_score'], 1), '0'), '.')) ?>%</strong></td>
                <td><?= (int)$r['best_score'] ?>%</td>
              <?php endif; ?>
              <td><?= (int)$r['attempts'] ?></td>
            </tr>
          <?php };
            foreach ($top as $r) $render($r);
            if ($me && !$meInTop): ?>
            <tr><td colspan="5" class="muted" style="text-align:center;padding:4px">&hellip;</td></tr>
            <?php $render($me); endif; ?>
          </tbody>
        </table>
      </div>
      <p class="muted legend">
        <?= $by === 'points'
            ? 'Ranked by total points from Gamified quizzes.'
            : 'Ranked by average quiz score. Ties are broken by total correct answers.' ?>
        Only student accounts are listed.
      </p>
      <?php endif; ?>
    </section>

    <section class="panel">
      <h3>Recent quizzes <span class="count">latest <?= count($history) ?></span></h3>
      <div class="table-wrap">
        <table class="data">
          <thead><tr><th>Deck</th><th>Mode</th><th>Score</th><th>Correct</th><th>Points</th><th>Time</th><th>Taken</th></tr></thead>
          <tbody>
          <?php foreach ($history as $h): ?>
            <tr>
              <td>
                <?php if ($h['deck_name'] !== null): ?>
                  <a class="link" href="quiz_result.php?id=<?= (int)$h['attempt_id'] ?>"><?= e($h['deck_name']) ?></a>
                <?php else: ?>
                  <a class="link" href="quiz_result.php?id=<?= (int)$h['attempt_id'] ?>"><span class="muted">(deleted deck)</span></a>
                <?php endif; ?>
              </td>
              <td><span class="badge <?= $h['quiz_mode'] === 'Gamified' ? 'badge-game' : 'badge-plain' ?>"><?= e($h['quiz_mode']) ?></span></td>
              <td><strong><?= (int)$h['quiz_score'] ?>%</strong></td>
              <td><?= (int)$h['correct_answers'] ?>/<?= (int)$h['total_questions'] ?></td>
              <td><?= $h['quiz_mode'] === 'Gamified' ? (int)$h['game_points'] : '<span class="muted">—</span>' ?></td>
              <td><?= e(fmt_time((int)$h['completion_time_seconds'])) ?></td>
              <td class="nowrap"><?= e(fmt_date($h['created_at'])) ?></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </section>

<?php endif; ?>
<?php student_footer(); ?>
