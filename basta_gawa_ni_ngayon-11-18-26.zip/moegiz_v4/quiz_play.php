<?php
require __DIR__ . '/student_init.php';
$user = require_student($db);
$uid  = (int)$user['user_id'];

const GAME_SECONDS    = 15;   // time per question in Gamified mode
const GRACE_SECONDS   = 3;    // network slack before an answer counts as timed out
const MAX_QUESTIONS   = 50;
const START_HEARTS    = 3;    // Gamified: lives
const HP_PER_QUESTION = 8;    // Gamified: monster HP = questions x this
const WIN_BONUS       = 200;  // Gamified: points for beating the monster
const HEART_BONUS     = 50;   // Gamified: extra points per heart left on a win

const MONSTERS = [
    ['Quizzly Bear',   '🐻'],
    ['Gloomy Ghost',   '👻'],
    ['Dread Dragon',   '🐲'],
    ['Zombie Zed',     '🧟'],
    ['Kraken Quiz',    '🐙'],
    ['Tester Rex',     '🦖'],
    ['Alien Examiner', '👽'],
    ['Robo Grader',    '🤖'],
    ['Pop Quiz Goblin','👺'],
];

function norm(string $s): string {
    return mb_strtolower(trim(preg_replace('/\s+/u', ' ', $s)));
}

// ================================================================== POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_ok()) {
        header('Location: quiz.php?err=invalid');
        exit;
    }
    $action = $_POST['action'] ?? '';

    // ---------------------------------------------------------- start a quiz
    if ($action === 'start') {
        $deckId = (int)($_POST['deck_id'] ?? 0);
        $mode   = $_POST['mode'] ?? '';
        $count  = (int)($_POST['count'] ?? 10);
        if (!in_array($mode, ['Standard', 'Gamified'], true) || !in_array($count, [0, 5, 10, 20], true)) {
            header('Location: quiz.php?err=invalid');
            exit;
        }

        // Only your own decks or public ones
        $deck = fetch_one($db, 'SELECT deck_id, name FROM decks WHERE deck_id = ? AND (user_id = ? OR is_public = 1)', 'ii', [$deckId, $uid]);
        if (!$deck) {
            header('Location: quiz.php?err=invalid');
            exit;
        }

        $cards = fetch_all($db, 'SELECT f.flashcard_id, f.question_text, f.answer_text, f.hint_text
            FROM deck_flashcards df JOIN flashcards f ON f.flashcard_id = df.flashcard_id
            WHERE df.deck_id = ?', 'i', [$deckId]);

        // Pool of distinct answers (used for the multiple-choice options)
        $pool = [];
        foreach ($cards as $c) {
            $pool[norm($c['answer_text'])] = $c['answer_text'];
        }
        if (count($cards) < 2 || count($pool) < 2) {
            header('Location: quiz.php?err=few');
            exit;
        }

        shuffle($cards);
        $limit = ($count === 0) ? MAX_QUESTIONS : min($count, MAX_QUESTIONS);
        $cards = array_slice($cards, 0, $limit);

        $questions = [];
        foreach ($cards as $c) {
            $correctKey = norm($c['answer_text']);
            $wrong = [];
            foreach ($pool as $k => $text) {
                if ($k !== $correctKey) $wrong[] = $text;
            }
            shuffle($wrong);
            $options = array_merge([$c['answer_text']], array_slice($wrong, 0, 3));
            shuffle($options);
            $questions[] = [
                'q'       => $c['question_text'],
                'hint'    => $c['hint_text'],
                'options' => $options,
                'correct' => array_search($c['answer_text'], $options, true),
            ];
        }

        $quiz = [
            'deck_id'     => (int)$deck['deck_id'],
            'deck_name'   => $deck['name'],
            'mode'        => $mode,
            'questions'   => $questions,
            'idx'         => 0,
            'correct'     => 0,
            'points'      => 0,
            'streak'      => 0,
            'best_streak' => 0,
            'time_spent'  => 0,
            'q_started'   => time(),
            'phase'       => 'asking',   // 'asking' or 'feedback'
            'feedback'    => null,
            'review'      => [],
        ];

        if ($mode === 'Gamified') {
            // Monster battle: a random monster, 3 hearts and a couple of power-ups
            $m     = MONSTERS[array_rand(MONSTERS)];
            $hpMax = count($questions) * HP_PER_QUESTION;
            $quiz['monster'] = ['name' => $m[0], 'emoji' => $m[1], 'hp' => $hpMax, 'max' => $hpMax];
            $quiz['hearts']  = START_HEARTS;
            $quiz['fifty']   = 2;      // 50/50 charges
            $quiz['skip']    = 1;      // skip charges
            $quiz['removed'] = [];     // options removed by 50/50 on the current question
            $quiz['over']    = null;   // null | 'win' | 'lose' | 'escaped'
        }

        $_SESSION['quiz'] = $quiz;
        header('Location: quiz_play.php');
        exit;
    }

    // Everything below needs a quiz in progress
    $quiz = $_SESSION['quiz'] ?? null;
    if (!$quiz || ($quiz['mode'] === 'Gamified' && !isset($quiz['monster']))) {
        unset($_SESSION['quiz']);   // also drops a half-finished quiz from an older version
        header('Location: quiz.php');
        exit;
    }
    $isGame = ($quiz['mode'] === 'Gamified');

    // ---------------------------------------------------------- quit
    if ($action === 'quit') {
        unset($_SESSION['quiz']);
        header('Location: quiz.php');
        exit;
    }

    // ---------------------------------------------------------- power-up: 50/50
    if ($action === 'fifty' && $isGame && $quiz['phase'] === 'asking') {
        $q = $quiz['questions'][$quiz['idx']];
        $n = min(2, count($q['options']) - 2);
        if ($quiz['fifty'] > 0 && empty($quiz['removed']) && $n > 0) {
            $wrong = [];
            foreach ($q['options'] as $i => $opt) {
                if ($i !== $q['correct']) $wrong[] = $i;
            }
            shuffle($wrong);
            $quiz['removed'] = array_slice($wrong, 0, $n);
            $quiz['fifty']--;
            $_SESSION['quiz'] = $quiz;
        }
        header('Location: quiz_play.php');
        exit;
    }

    // ---------------------------------------------------------- power-up: skip
    if ($action === 'skip' && $isGame && $quiz['phase'] === 'asking') {
        // Not allowed on the last question (it would end the battle without a fight)
        if ($quiz['skip'] > 0 && $quiz['idx'] < count($quiz['questions']) - 1) {
            $quiz['skip']--;
            $quiz['idx']++;
            $quiz['removed']   = [];
            $quiz['q_started'] = time();
            $_SESSION['quiz']  = $quiz;
        }
        header('Location: quiz_play.php');
        exit;
    }

    // ---------------------------------------------------------- answer
    if ($action === 'answer' && $quiz['phase'] === 'asking') {
        $q       = $quiz['questions'][$quiz['idx']];
        $elapsed = max(0, time() - (int)$quiz['q_started']);
        $choice  = (isset($_POST['choice']) && $_POST['choice'] !== '') ? (int)$_POST['choice'] : -1;

        $timedOut = false;
        if ($isGame && $elapsed > GAME_SECONDS + GRACE_SECONDS) {
            $choice   = -1;      // too slow: counts as wrong
            $timedOut = true;
        }
        if ($choice < 0 || $choice >= count($q['options'])) {
            $choice = -1;
        }
        if ($isGame && in_array($choice, $quiz['removed'] ?? [], true)) {
            $choice = -1;        // an option taken away by 50/50 can't be picked
        }

        $isCorrect   = ($choice === $q['correct']);
        $remaining   = max(0, GAME_SECONDS - $elapsed);
        $earned      = 0;
        $speedBonus  = 0;
        $streakBonus = 0;
        $lostStreak  = 0;
        $damage      = 0;
        $crit        = false;
        $healed      = false;
        $heartLost   = false;
        $hpBefore    = $isGame ? (int)$quiz['monster']['hp'] : 0;

        if ($isCorrect) {
            $quiz['correct']++;
            $quiz['streak']++;
            $quiz['best_streak'] = max((int)($quiz['best_streak'] ?? 0), $quiz['streak']);
            if ($isGame) {
                $speedBonus  = (int)floor(50 * $remaining / GAME_SECONDS);   // faster = more points
                $streakBonus = min(50, ($quiz['streak'] - 1) * 10);          // +10 per answer in a row (max +50)
                $earned      = 100 + $speedBonus + $streakBonus;

                $crit   = ($remaining >= 10);                                // answered within 5 seconds
                $damage = 10 + ($crit ? 5 : 0) + min(10, ($quiz['streak'] - 1) * 2);
                $quiz['monster']['hp'] = max(0, $quiz['monster']['hp'] - $damage);

                // every 4th correct answer in a row heals a heart
                if ($quiz['streak'] % 4 === 0 && $quiz['hearts'] < START_HEARTS) {
                    $quiz['hearts']++;
                    $healed = true;
                }
            }
        } else {
            $lostStreak     = $quiz['streak'];
            $quiz['streak'] = 0;
            if ($isGame) {
                $quiz['hearts'] = max(0, $quiz['hearts'] - 1);
                $heartLost = true;
            }
        }

        if ($isGame) {
            $quiz['removed'] = [];
            if ($quiz['monster']['hp'] <= 0)                          $quiz['over'] = 'win';
            elseif ($quiz['hearts'] <= 0)                             $quiz['over'] = 'lose';
            elseif ($quiz['idx'] >= count($quiz['questions']) - 1)    $quiz['over'] = 'escaped';
        }

        $quiz['points']     += $earned;
        $quiz['time_spent'] += min($elapsed, 3600);

        $noAnswer = $timedOut || ($choice === -1 && $isGame);
        $quiz['review'][] = [
            'q'        => $q['q'],
            'chosen'   => $choice >= 0 ? $q['options'][$choice] : null,
            'correct'  => $q['options'][$q['correct']],
            'ok'       => $isCorrect,
            'timedOut' => $noAnswer,
        ];
        $quiz['phase']    = 'feedback';
        $quiz['feedback'] = [
            'ok'          => $isCorrect,
            'chosen'      => $choice >= 0 ? $q['options'][$choice] : null,
            'correct'     => $q['options'][$q['correct']],
            'earned'      => $earned,
            'speed'       => $speedBonus,
            'streakBonus' => $streakBonus,
            'lostStreak'  => $lostStreak,
            'damage'      => $damage,
            'crit'        => $crit,
            'healed'      => $healed,
            'heartLost'   => $heartLost,
            'hpBefore'    => $hpBefore,
            'timedOut'    => $noAnswer,
        ];
        $_SESSION['quiz'] = $quiz;
        header('Location: quiz_play.php');
        exit;
    }

    // ---------------------------------------------------------- next question / finish
    if ($action === 'next' && $quiz['phase'] === 'feedback') {
        $battleOver = $isGame && !empty($quiz['over']);
        $quiz['idx']++;

        if ($battleOver || $quiz['idx'] >= count($quiz['questions'])) {
            // In a battle the fight can end early, so only count the questions actually answered
            $total   = max(1, count($quiz['review']));
            $correct = (int)$quiz['correct'];
            $score   = (int)round(100 * $correct / $total);
            $points  = (int)$quiz['points'];
            $time    = (int)min($quiz['time_spent'], 16777215);
            $mode    = $quiz['mode'];
            $deckId  = (int)$quiz['deck_id'];

            $game = null;
            if ($isGame) {
                $outcome  = $quiz['over'] ?? 'escaped';
                $bonus    = ($outcome === 'win') ? WIN_BONUS + HEART_BONUS * (int)$quiz['hearts'] : 0;
                $points  += $bonus;
                $game = [
                    'outcome' => $outcome,
                    'bonus'   => $bonus,
                    'hearts'  => (int)$quiz['hearts'],
                    'monster' => $quiz['monster'],
                ];
            }

            $sql = 'INSERT INTO quiz_attempts
                (user_id, deck_id, quiz_score, correct_answers, total_questions, game_points, completion_time_seconds, quiz_mode)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)';
            try {
                $stmt = $db->prepare($sql);
                $stmt->bind_param('iiiiiiis', $uid, $deckId, $score, $correct, $total, $points, $time, $mode);
                $stmt->execute();
            } catch (mysqli_sql_exception $ex) {
                // The deck was deleted while the quiz was running: save the attempt without a deck link
                $deckId = null;
                $stmt = $db->prepare($sql);
                $stmt->bind_param('iiiiiiis', $uid, $deckId, $score, $correct, $total, $points, $time, $mode);
                $stmt->execute();
            }
            $attemptId = (int)$db->insert_id;
            $stmt->close();

            // Keep the details for the results page (this session only)
            $_SESSION['quiz_review'] = [
                'attempt_id'  => $attemptId,
                'items'       => $quiz['review'],
                'best_streak' => (int)($quiz['best_streak'] ?? 0),
                'game'        => $game,
            ];
            unset($_SESSION['quiz']);
            header('Location: quiz_result.php?id=' . $attemptId);
            exit;
        }

        $quiz['phase']     = 'asking';
        $quiz['feedback']  = null;
        $quiz['q_started'] = time();
        $_SESSION['quiz']  = $quiz;
        header('Location: quiz_play.php');
        exit;
    }

    header('Location: quiz_play.php');
    exit;
}

// ================================================================== GET: show the quiz
$quiz = $_SESSION['quiz'] ?? null;
if (!$quiz || ($quiz['mode'] === 'Gamified' && !isset($quiz['monster']))) {
    unset($_SESSION['quiz']);
    header('Location: quiz.php');
    exit;
}

$total      = count($quiz['questions']);
$idx        = (int)$quiz['idx'];
$q          = $quiz['questions'][$idx];
$gamified   = ($quiz['mode'] === 'Gamified');
$isFeedback = ($quiz['phase'] === 'feedback');
$isLast     = ($idx === $total - 1);
$fb         = $quiz['feedback'];
$over       = $gamified ? ($quiz['over'] ?? null) : null;
$removed    = $quiz['removed'] ?? [];
$remaining  = $gamified ? max(0, GAME_SECONDS - (time() - (int)$quiz['q_started'])) : null;
$progress   = (int)round(100 * ($idx + ($isFeedback ? 1 : 0)) / $total);

// Which sound to play when the feedback screen opens
$sfx = '';
if ($gamified && $isFeedback && $fb) {
    if ($over === 'win')        $sfx = 'win';
    elseif ($over === 'lose')   $sfx = 'lose';
    elseif ($fb['ok'])          $sfx = $fb['crit'] ? 'crit' : 'hit';
    else                        $sfx = 'miss';
}

student_header('Quiz', 'quiz', $user);
?>
    <div class="page-head">
      <div>
        <div class="crumb"><?= e($quiz['deck_name']) ?> &middot; <span class="badge <?= $gamified ? 'badge-game' : 'badge-plain' ?>"><?= $gamified ? 'Gamified &middot; Monster Battle' : 'Standard' ?></span></div>
        <h2 class="page-title"><?= $gamified ? 'Round' : 'Question' ?> <?= $idx + 1 ?> of <?= $total ?></h2>
      </div>
      <div class="head-actions">
        <?php if ($gamified): ?><button class="btn ghost sm" type="button" id="sound-btn" title="Sound on/off">🔊</button><?php endif; ?>
        <form method="post" action="quiz_play.php" onsubmit="return confirm('Quit this quiz? Your progress will not be saved.');">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="quit">
          <button class="btn ghost sm" type="submit">Quit</button>
        </form>
      </div>
    </div>

    <div class="progress"><div class="bar" style="width: <?= $progress ?>%"></div></div>

<?php if ($gamified):
    $mon     = $quiz['monster'];
    $hpPct   = $mon['max'] > 0 ? (int)round(100 * $mon['hp'] / $mon['max']) : 0;
    $fromPct = ($isFeedback && $fb && $mon['max'] > 0) ? (int)round(100 * $fb['hpBefore'] / $mon['max']) : $hpPct;
    $hpClass = $hpPct > 50 ? 'ok' : ($hpPct > 25 ? 'mid' : 'low');
    $hearts  = (int)$quiz['hearts'];
    $monClass = '';
    $arenaClass = '';
    if ($isFeedback && $fb) {
        if ($fb['ok']) {
            $monClass = ($over === 'win') ? 'dead' : 'hit';
        } else {
            $monClass = 'taunt';
            if ($fb['heartLost']) $arenaClass = 'hurt';
        }
    }
?>
    <section class="arena <?= $arenaClass ?>">
      <div class="arena-top">
        <div class="monster-wrap">
          <div class="monster <?= $monClass ?>"><?= e($mon['emoji']) ?></div>
          <?php if ($isFeedback && $fb && $fb['ok']): ?>
            <div class="dmg<?= $fb['crit'] ? ' crit' : '' ?>">-<?= (int)$fb['damage'] ?><?= $fb['crit'] ? ' CRIT!' : '' ?></div>
          <?php endif; ?>
        </div>
        <div class="arena-info">
          <div class="monster-name"><?= e($mon['name']) ?></div>
          <div class="hp"><div class="hp-fill <?= $hpClass ?><?= $isFeedback ? ' drop' : '' ?>" style="width: <?= $hpPct ?>%; --from: <?= $fromPct ?>%; --to: <?= $hpPct ?>%"></div></div>
          <div class="hp-text"><?= (int)$mon['hp'] ?> / <?= (int)$mon['max'] ?> HP</div>
        </div>
      </div>
      <div class="hero-row">
        <div class="hearts" aria-label="<?= $hearts ?> hearts left">
          <?php for ($h = 0; $h < START_HEARTS; $h++):
              if ($h < $hearts): ?>
                <span class="heart<?= ($isFeedback && $fb && $fb['healed'] && $h === $hearts - 1) ? ' pop' : '' ?>">❤️</span>
              <?php elseif ($isFeedback && $fb && $fb['heartLost'] && $h === $hearts): ?>
                <span class="heart lost">💔</span>
              <?php else: ?>
                <span class="heart empty">🖤</span>
              <?php endif;
          endfor; ?>
        </div>
        <div class="pills">
          <?php if ($quiz['streak'] >= 2): ?><span class="pill streak">🔥 <?= (int)$quiz['streak'] ?> streak</span><?php endif; ?>
          <span class="pill"><strong><?= (int)$quiz['points'] ?></strong> pts</span>
        </div>
      </div>
    </section>

    <script>
      // Tiny sound effects (WebAudio, no files). The mute choice is remembered in this browser.
      window.Sfx = (function () {
        var ctx = null, KEY = 'moegiz_mute';
        function enabled() { try { return localStorage.getItem(KEY) !== '1'; } catch (e) { return true; } }
        function tone(freq, start, dur, type, vol) {
          try {
            ctx = ctx || new (window.AudioContext || window.webkitAudioContext)();
            if (ctx.state === 'suspended') ctx.resume();
            var o = ctx.createOscillator(), g = ctx.createGain(), t0 = ctx.currentTime + start;
            o.type = type || 'square'; o.frequency.value = freq;
            g.gain.setValueAtTime(0.0001, t0);
            g.gain.exponentialRampToValueAtTime(vol || 0.08, t0 + 0.01);
            g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
            o.connect(g); g.connect(ctx.destination);
            o.start(t0); o.stop(t0 + dur + 0.03);
          } catch (e) {}
        }
        var sounds = {
          tick: function () { tone(520, 0, 0.05, 'square', 0.05); },
          hit:  function () { tone(440, 0, 0.09); tone(660, 0.09, 0.14); },
          crit: function () { tone(523, 0, 0.07); tone(659, 0.07, 0.07); tone(784, 0.14, 0.2); },
          miss: function () { tone(200, 0, 0.22, 'sawtooth', 0.1); tone(140, 0.12, 0.3, 'sawtooth', 0.1); },
          win:  function () { [523, 659, 784, 1047].forEach(function (f, i) { tone(f, i * 0.12, 0.25, 'triangle', 0.14); }); },
          lose: function () { [392, 330, 262, 196].forEach(function (f, i) { tone(f, i * 0.2, 0.32, 'sawtooth', 0.09); }); }
        };
        return {
          enabled: enabled,
          play: function (k) { if (enabled() && sounds[k]) sounds[k](); },
          toggle: function () { try { localStorage.setItem(KEY, enabled() ? '1' : '0'); } catch (e) {} return enabled(); }
        };
      })();
      (function () {
        var btn = document.getElementById('sound-btn');
        function paint() { btn.textContent = Sfx.enabled() ? '🔊' : '🔇'; }
        paint();
        btn.addEventListener('click', function () { Sfx.toggle(); paint(); Sfx.play('tick'); });
        <?php if ($sfx !== ''): ?>Sfx.play(<?= json_encode($sfx) ?>);<?php endif; ?>
      })();
    </script>
<?php endif; ?>

    <section class="panel quiz-card<?= $gamified ? ' game' : '' ?>">
      <?php if (!$gamified): ?>
        <div class="quiz-meta"><span><?= (int)$quiz['correct'] ?> correct so far</span></div>
      <?php endif; ?>

      <p class="q-text"><?= e($q['q']) ?></p>

      <?php if (!$isFeedback): ?>

        <?php if ($gamified): ?>
          <div class="timer"><div class="timer-bar" id="timer-bar"></div></div>
          <div class="timer-text"><span id="timer-num"><?= (int)$remaining ?></span>s left &middot; answer in the first 5 s for a critical hit</div>
        <?php endif; ?>

        <?php if ($q['hint'] !== null && $q['hint'] !== ''): ?>
          <details class="hint-box"><summary>Show hint</summary><?= e($q['hint']) ?></details>
        <?php endif; ?>

        <form class="quiz-form" method="post" action="quiz_play.php" id="answer-form">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="answer">
          <div class="options">
            <?php foreach ($q['options'] as $i => $opt): $gone = in_array($i, $removed, true); ?>
              <label class="opt<?= $gone ? ' gone' : '' ?>">
                <input type="radio" name="choice" value="<?= (int)$i ?>" <?= $gone ? 'disabled' : ($gamified ? '' : 'required') ?>>
                <span><?= e($opt) ?></span>
              </label>
            <?php endforeach; ?>
          </div>
          <?php if (!$gamified): ?>
            <div class="actions-row"><button class="btn" type="submit">Check answer</button></div>
          <?php endif; ?>
        </form>

        <?php if ($gamified):
            $canFifty = $quiz['fifty'] > 0 && empty($removed) && count($q['options']) > 2;
            $canSkip  = $quiz['skip'] > 0 && !$isLast;
        ?>
          <div class="powerups">
            <span class="powerups-label">Power-ups</span>
            <form method="post" action="quiz_play.php">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="fifty">
              <button class="power" type="submit" <?= $canFifty ? '' : 'disabled' ?> title="Remove two wrong answers">✂️ 50/50 <span class="charges">×<?= (int)$quiz['fifty'] ?></span></button>
            </form>
            <form method="post" action="quiz_play.php">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="skip">
              <button class="power" type="submit" <?= $canSkip ? '' : 'disabled' ?> title="Skip this question, no penalty">⏭️ Skip <span class="charges">×<?= (int)$quiz['skip'] ?></span></button>
            </form>
          </div>
        <?php endif; ?>

        <script>
          (function () {
            const form   = document.getElementById('answer-form');
            const radios = Array.prototype.slice.call(form.querySelectorAll('input[name="choice"]'));

            // Keyboard: press 1-4 or A-D to pick an answer
            document.addEventListener('keydown', function (ev) {
              if (ev.ctrlKey || ev.metaKey || ev.altKey || ev.key.length !== 1) return;
              const k = ev.key.toLowerCase();
              let i = '1234'.indexOf(k);
              if (i < 0) i = 'abcd'.indexOf(k);
              if (i < 0 || i >= radios.length || radios[i].disabled) return;
              radios[i].checked = true;
              radios[i].dispatchEvent(new Event('change', { bubbles: true }));
            });

            <?php if ($gamified): ?>
            // ---- Gamified: countdown bar, picking an answer attacks straight away
            const total = <?= GAME_SECONDS ?>;
            let left = <?= (int)$remaining ?>;
            const num = document.getElementById('timer-num');
            const bar = document.getElementById('timer-bar');
            let sent = false;
            function send() {
              if (sent) return;
              sent = true;
              form.classList.add('locked');
              if (window.Sfx) Sfx.play('tick');
              form.submit();
            }
            radios.forEach(function (r) { r.addEventListener('change', send); });

            num.textContent = left;
            bar.style.width = (100 * left / total) + '%';
            bar.classList.toggle('low', left <= 5);
            if (left <= 0) { send(); return; }

            // let the bar shrink smoothly for the time that is left
            void bar.offsetWidth;
            bar.style.transition = 'width ' + left + 's linear';
            bar.style.width = '0%';

            const t = setInterval(function () {
              left--;
              num.textContent = Math.max(left, 0);
              bar.classList.toggle('low', left <= 5);
              if (left <= 0) { clearInterval(t); send(); }
            }, 1000);
            <?php endif; ?>
          })();
        </script>

      <?php else: /* feedback */ ?>

        <div class="options">
          <?php foreach ($q['options'] as $i => $opt):
              $cls = '';
              if ($i === $q['correct']) $cls = 'right';
              elseif ($fb['chosen'] !== null && $opt === $fb['chosen']) $cls = 'wrong';
          ?>
            <div class="opt static <?= $cls ?>"><span><?= e($opt) ?></span>
              <?php if ($cls === 'right'): ?><em>Correct answer</em><?php elseif ($cls === 'wrong'): ?><em>Your answer</em><?php endif; ?>
            </div>
          <?php endforeach; ?>
        </div>

        <div class="notice <?= $fb['ok'] ? 'ok' : 'error' ?>" style="margin-top:16px">
          <?php if ($fb['ok']): ?>
            <?php if ($gamified): ?>
              <?= $fb['crit'] ? '⚡ Critical hit!' : '⚔️ Direct hit!' ?> -<?= (int)$fb['damage'] ?> HP &middot; +<?= (int)$fb['earned'] ?> points
              <div class="breakdown">100 base
                <?= ($fb['speed'] ?? 0) > 0 ? '+ ' . (int)$fb['speed'] . ' speed' : '' ?>
                <?= ($fb['streakBonus'] ?? 0) > 0 ? '+ ' . (int)$fb['streakBonus'] . ' streak' : '' ?></div>
              <?php if (!empty($fb['healed'])): ?><div class="breakdown">❤️ 4 in a row! You healed a heart.</div><?php endif; ?>
            <?php else: ?>
              Correct!
            <?php endif; ?>
          <?php elseif ($fb['timedOut'] && $fb['chosen'] === null): ?>
            <?= $gamified ? '⏰ ' : '' ?>Time's up! The answer was: <?= e($fb['correct']) ?>
          <?php else: ?>
            <?= $gamified ? '💥 Ouch! ' : '' ?>Not quite. The answer was: <?= e($fb['correct']) ?>
          <?php endif; ?>
          <?php if ($gamified && !$fb['ok']): ?>
            <div class="breakdown">You lose a heart.<?= ($fb['lostStreak'] ?? 0) >= 2 ? ' Streak of ' . (int)$fb['lostStreak'] . ' lost.' : '' ?></div>
          <?php endif; ?>
        </div>

        <?php if ($over): ?>
          <div class="banner <?= e($over) ?>">
            <?php if ($over === 'win'): ?>
              🎉 You defeated <?= e($quiz['monster']['name']) ?>!
            <?php elseif ($over === 'lose'): ?>
              💀 You ran out of hearts. <?= e($quiz['monster']['name']) ?> wins this time.
            <?php else: ?>
              🏃 <?= e($quiz['monster']['name']) ?> escaped with <?= (int)$quiz['monster']['hp'] ?> HP left.
            <?php endif; ?>
          </div>
        <?php endif; ?>

        <form method="post" action="quiz_play.php">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="next">
          <div class="actions-row"><button class="btn" type="submit" autofocus><?= ($isLast || $over) ? 'See results' : ($gamified ? 'Next round' : 'Next question') ?></button></div>
        </form>

      <?php endif; ?>
    </section>
<?php student_footer(); ?>
